cmake_minimum_required(VERSION 3.10)

project(lorp CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()

set(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS_RELEASE} -O3")

set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR})

set(SOURCES
    crossover.cpp
    Individual.cpp
    initialsol.cpp
    LS.cpp
    mutation.cpp
    popManager.cpp
    read_data.cpp
    RepairProcedure.cpp
    solution.cpp
    main.cpp
)

add_executable(lorp ${SOURCES})
