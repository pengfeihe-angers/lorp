﻿#include "LS.h"
#include "basic.h"
#include "Individual.h"
LS::LS(read_data * data, RepairProcedure *repair) {
	this->data=data;
	this->repair = repair;
	this->numV = data->numV;
	this->numC = data->numC;
	this->numL = data->numL;
	cumLoad = std::vector<int>(numL);
	isInsertToEjectionList = new bool [numV];
}
LS::~LS() {
	delete [] isInsertToEjectionList;
}
double LS::compute(bool istrue, double value){
	if (istrue)	return 0.;
	else return value;
}
void LS::srun(){
	random_shuffle(orderNodes.begin(),orderNodes.end());
	for (int i=0; i<numV; i++)
		if (rand()%data->alpha==0)
			random_shuffle(data->edgeNode[i].begin(),data->edgeNode[i].end());
	searchComplete=false;
	int maxLocalSearchPasses = std::max(50, 5 * numV);
	int maxLocalSearchMoves = std::max(1000, 20 * numV);
	for (loopID=0;!searchComplete;loopID++){
		if (data->stopCondition(s->fit)) return;
		if (loopID > maxLocalSearchPasses || nbMoves > maxLocalSearchMoves) return;
		int movesAtPassStart = nbMoves;
		searchComplete=true;
		for (int posU=0;posU<(int)orderNodes.size();posU++){// only num_v-1 clients
			if (data->stopCondition(s->fit)) return;
			nodeU=&s->client[orderNodes[posU]];
			int lastTestRINodeU = nodeU->whenLastTestedRI;
			nodeU->whenLastTestedRI=nbMoves;
			for (int posV = 0; posV<(int)data->edgeNode[nodeU->cour].size(); posV++){
				if (data->edgeNode[nodeU->cour][posV] >= numV)continue;// not consider locations
				if (s->client[data->edgeNode[nodeU->cour][posV]].covered_loc != NULL)// if the node is not included by routes
					continue;
				nodeV=&s->client[data->edgeNode[nodeU->cour][posV]];
				if (loopID==0 || std::max<int>(nodeU->route->whenLastModified,nodeV->route->whenLastModified) > lastTestRINodeU){
					setLocalVariableRouteU();
					setLocalVariableRouteV();
					//
					ejection_list.clear();
					if (Relocate_one())continue;//10 insert operator
					if (Relocate_two())continue;//20 insert operator
					if (Relocate_three())continue;//02 insert operator
					if (nodeUIndex < nodeVIndex && Relocate_four())continue;//11 swap operator
					if (Relocate_five())continue;//21 swap
					if (nodeUIndex <= nodeVIndex && Relocate_six()) continue; // SWAP 22
					if (nodeUIndex <= nodeVIndex && Relocate_seven()) continue;; // SWAP 2-2 reverse
					if (routeU == routeV && Relocate_eight()) continue; // 2-OPT
					if (two_opt_star())continue;
					if (two_opt_starR())continue;///////////
					if (nodeV->pre->isDepot){
						nodeV = nodeV->pre;
						setLocalVariableRouteV();
						if (Relocate_one()) continue; // RELOCATE
						if (Relocate_two()) continue; // RELOCATE
						if (Relocate_three()) continue; // RELOCATE
						if (routeU != routeV && Relocate_nine()) continue; // 2-OPT*
						if (routeU != routeV && Relocate_ten()) continue; // 2-OPT*
					}
				}
			}
			if (loopID > 0){
				for (int posV = 0; posV < (int)data->customerToLoc[nodeU->cour].size();posV++){
					if (!s->location[data->customerToLoc[nodeU->cour][posV] - numV].used)continue;
					if (!s->location[data->customerToLoc[nodeU->cour][posV] - numV].emptyRoutes.empty()){
						nodeV = s->route[s->location[data->customerToLoc[nodeU->cour][posV] - numV].emptyRoutes[0]].depot;
						setLocalVariableRouteU();
						setLocalVariableRouteV();
						ejection_list.clear();
						if (Relocate_one()) continue; // RELOCATE
						if (Relocate_two()) continue; // RELOCATE
						if (Relocate_nine()) continue; // RELOCATE
						if (Relocate_ten()) continue; // 2-OPT*
					}
				}
			}
		}/// end the CVRP neighborhoods search
		if (!searchComplete && nbMoves == movesAtPassStart) return;
	}
}
bool LS::Relocate_one(){
	if (nodeUIndex == nodeYIndex)return false;
	if (data->D[nodeVIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex] + routeV->dis > data->maxLength)return false; // the constraint of length

	if (data->useMoveEjection && data->Range > 0){
		if (locU != locV && !ejection_move(nodeU->dem, 0))// operation the customers
			return false;
	}
	else{
		if (locV->remainInven + nodeU->dem > locV->inventory)
			return false;
	}
	if(nodeV->route != nodeU->route && nodeV->route->load + nodeU->dem > data->vehCap)return false;// route feasible

	moveGain = compute(nodeV->route->whichLocation->used, data->openCostLoc[nodeV->route->whichLocation->cour])
			+ compute(!(nodeV->isDepot && nodeY->isDepot), data->usingCostVeh)
			- compute(!((nodeU->route->whichLocation->splitTime == 1 && nodeU->route->whichLocation->in_range.size() == 0)  && nodeU->route->nbClients == 1 && nodeU->route->whichLocation != nodeV->route->whichLocation), data->openCostLoc[nodeU->route->whichLocation->cour])
			- compute(nodeU->route->nbClients != 1, data->usingCostVeh)
			+ data->D[nodeUPrevIndex][nodeXIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeUIndex][nodeXIndex]
			+ data->D[nodeVIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	//


	if (moveGain > -Min)return false;
	insertNode(nodeU,nodeV);
	move_ejection_list();

	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);

	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_two(){
	if (nodeUIndex == nodeYIndex || nodeXIndex == nodeVIndex || nodeX->isDepot) return false;

	if (data->D[nodeVIndex][nodeUIndex] + data->D[nodeXIndex][nodeUIndex] + data->D[nodeXIndex][nodeYIndex] - data->D[nodeVIndex][nodeYIndex] + routeV->dis > data->maxLength)
		return false;

	if (data->useMoveEjection && data->Range > 0){
		if (locU != locV && !ejection_move(nodeU->dem + nodeX->dem, 0))// operation the customers
			return false;
	}
	else{
		if (!(nodeV->route->whichLocation->remainInven + nodeU->dem + nodeX->dem <= nodeV->route->whichLocation->inventory))// depot feasible
			return false;
	}
	if(nodeV->route != nodeU->route && nodeV->route->load + nodeU->dem + nodeX->dem > data->vehCap)return false;// route feasible


	//
	moveGain = compute(nodeV->route->whichLocation->used, data->openCostLoc[nodeV->route->whichLocation->cour])
			+ compute(!(nodeV->isDepot && nodeY->isDepot), data->usingCostVeh)
			- compute(!((nodeU->route->whichLocation->splitTime == 1 && nodeU->route->whichLocation->in_range.size() == 0) && nodeU->route->nbClients == 2 && nodeU->route->whichLocation != nodeV->route->whichLocation), data->openCostLoc[nodeU->route->whichLocation->cour])
			- compute(nodeU->route->nbClients != 2, data->usingCostVeh)
			+ data->D[nodeUPrevIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex]
			+ data->D[nodeVIndex][nodeUIndex]+data->D[nodeXIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	//
	if (moveGain>-Min)return false;
	insertNode(nodeU,nodeV);
	insertNode(nodeX,nodeU);
	move_ejection_list();

	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_three(){
	if (nodeUIndex == nodeYIndex || nodeXIndex == nodeVIndex || nodeX->isDepot) return false;

	if (data->useMoveEjection && data->Range > 0){
		if (locU != locV && !ejection_move(nodeU->dem + nodeX->dem, 0))// operation the customers
			return false;
	}
	else{
		if (!(nodeV->route->whichLocation->remainInven + nodeU->dem + nodeX->dem <= nodeV->route->whichLocation->inventory))// depot feasible
			return false;
	}

	if (data->D[nodeVIndex][nodeXIndex] + data->D[nodeXIndex][nodeUIndex] + data->D[nodeUIndex][nodeYIndex] - data->D[nodeVIndex][nodeYIndex] + routeV->dis > data->maxLength)
		return false;
	if(nodeV->route != nodeU->route && nodeV->route->load + nodeU->dem + nodeX->dem > data->vehCap)return false;// route feasible
	//
	if ((nodeU->route->whichLocation->splitTime == 1 && nodeU->route->whichLocation->in_range.size() == 0) && nodeU->route->nbClients == 1){//a depot is removed and a route is also removed.
		moveGain = -data->openCostLoc[nodeU->route->whichLocation->cour] - data->usingCostVeh;
		moveGain += data->D[nodeUPrevIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex];
		moveGain += data->D[nodeVIndex][nodeXIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	}
	else if (nodeU->route->nbClients == 2){
		moveGain = -data->usingCostVeh;
		moveGain += data->D[nodeUPrevIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex];
		moveGain += data->D[nodeVIndex][nodeXIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	}
	else{
		moveGain = 0;
		moveGain += data->D[nodeUPrevIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex];
		moveGain += data->D[nodeVIndex][nodeXIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	}
	if (moveGain>-Min)return false;
	insertNode(nodeX,nodeV);
	insertNode(nodeU,nodeX);
	move_ejection_list();

	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_four(){//
	if (nodeUIndex == nodeVPrevIndex || nodeUIndex == nodeYIndex)return false;
	if (routeU->dis + data->D[nodeUPrevIndex][nodeVIndex] + data->D[nodeVIndex][nodeXIndex] - data->D[nodeUPrevIndex][nodeUIndex] - data->D[nodeUIndex][nodeXIndex] > data->maxLength)
		return false;
	if (routeV->dis + data->D[nodeVPrevIndex][nodeUIndex] + data->D[nodeUIndex][nodeYIndex] - data->D[nodeVPrevIndex][nodeVIndex] - data->D[nodeVIndex][nodeYIndex] > data->maxLength)
		return false;
	if (data->useMoveEjection && data->Range > 0){
		if ( locU != locV && !ejection_move(nodeU->dem, nodeV->dem))// operation the customers
			return false;
	}
	else{
		if (nodeU->route->whichLocation != nodeV->route->whichLocation)
			if ((nodeV->route->whichLocation->remainInven + nodeU->dem - nodeV->dem > nodeV->route->whichLocation->inventory) || (nodeU->route->whichLocation->remainInven + nodeV->dem - nodeU->dem > nodeU->route->whichLocation->inventory))
				return false;
	}

	if (nodeU->route->load - nodeU->dem + nodeV->dem > data->vehCap || nodeV->route->load - nodeV->dem + nodeU->dem > data->vehCap)return false;

	moveGain=data->D[nodeUPrevIndex][nodeVIndex]+data->D[nodeVIndex][nodeXIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeUIndex][nodeXIndex];
	moveGain+=data->D[nodeVPrevIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVPrevIndex][nodeVIndex]-data->D[nodeVIndex][nodeYIndex];
	//
	if (moveGain > -Min)return false;
	swapNode(nodeU,nodeV);
	move_ejection_list();

	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_five(){
	if (nodeU == nodeV->pre || nodeX == nodeV->pre || nodeU == nodeY || nodeX->isDepot) return false;

	if (data->useMoveEjection && data->Range > 0){
		if ( locU != locV && !ejection_move(nodeU->dem+nodeX->dem, nodeV->dem))// operation the customers
			return false;
	}
	else{
		if (nodeU->route->whichLocation != nodeV->route->whichLocation){
			if (nodeU->route->whichLocation->remainInven + nodeV->dem - nodeU->dem - nodeX->dem > nodeU->route->whichLocation->inventory)return false;
			if (nodeV->route->whichLocation->remainInven + nodeU->dem + nodeX->dem - nodeV->dem >nodeV->route->whichLocation->inventory)return false;
		}
	}

	if (nodeU->route->load - nodeU->dem - nodeX->dem + nodeV->dem > data->vehCap || nodeV->route->load + nodeU->dem + nodeX->dem - nodeV->dem > data->vehCap)return false;

	//the distance constraints for routes
	if (routeU->dis + data->D[nodeUPrevIndex][nodeVIndex] + data->D[nodeVIndex][nodeXNextIndex] - data->D[nodeUPrevIndex][nodeUIndex] - data->D[nodeUIndex][nodeXIndex] -
			-data->D[nodeXIndex][nodeXNextIndex] > data->maxLength)
		return false;
	if (routeV->dis + data->D[nodeVPrevIndex][nodeUIndex] + data->D[nodeUIndex][nodeXIndex] + data->D[nodeXIndex][nodeYIndex]
			- data->D[nodeVPrevIndex][nodeVIndex] - data->D[nodeVIndex][nodeYIndex] > data->maxLength)
		return false;
	//
	moveGain=data->D[nodeUPrevIndex][nodeVIndex]+data->D[nodeVIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex];
	moveGain+=data->D[nodeVPrevIndex][nodeUIndex]+data->D[nodeXIndex][nodeYIndex]-data->D[nodeVPrevIndex][nodeVIndex]-data->D[nodeVIndex][nodeYIndex];

	if (moveGain >-Min)return false;

	swapNode(nodeU, nodeV);
	insertNode(nodeX, nodeU);
	move_ejection_list();

	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_six(){
	if (nodeX->isDepot || nodeY->isDepot || nodeY == nodeU->pre || nodeU == nodeY || nodeX == nodeV || nodeV == nodeX->next) return false;
	//
	if (data->useMoveEjection && data->Range > 0){
		if (locU != locV && !ejection_move(nodeU->dem+nodeX->dem, nodeV->dem+nodeY->dem))// operation the customers
			return false;
	}
	else{
		if (nodeU->route->whichLocation != nodeV->route->whichLocation){
			if (nodeU->route->whichLocation->remainInven + nodeV->dem + nodeY->dem - nodeU->dem - nodeX->dem > nodeU->route->whichLocation->inventory)return false;
			if (nodeV->route->whichLocation->remainInven + nodeU->dem + nodeX->dem - nodeV->dem - nodeY->dem > nodeV->route->whichLocation->inventory)return false;
		}
	}
	//
	if (nodeU->route->load - nodeU->dem - nodeX->dem + nodeV->dem + nodeY->dem > data->vehCap || nodeV->route->load - nodeV->dem - nodeY->dem + nodeU->dem + nodeX->dem > data->vehCap)return false;
	////the distance constraints for routes
	if (routeU->dis + data->D[nodeUPrevIndex][nodeVIndex] + data->D[nodeVIndex][nodeYIndex] + data->D[nodeYIndex][nodeXNextIndex]
		- data->D[nodeUPrevIndex][nodeUIndex] - data->D[nodeUIndex][nodeXIndex] - data->D[nodeXIndex][nodeXNextIndex] > data->maxLength)
		return false;
	if (routeV->dis + data->D[nodeVPrevIndex][nodeUIndex] + data->D[nodeUIndex][nodeXIndex] + data->D[nodeXIndex][nodeYNextIndex]
	    - data->D[nodeVPrevIndex][nodeVIndex] - data->D[nodeVIndex][nodeYIndex] - data->D[nodeYIndex][nodeYNextIndex] > data->maxLength)
		return false;
	//
	moveGain=data->D[nodeUPrevIndex][nodeVIndex]+data->D[nodeYIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex];
	moveGain+=data->D[nodeVPrevIndex][nodeUIndex]+data->D[nodeXIndex][nodeYNextIndex]-data->D[nodeVPrevIndex][nodeVIndex]-data->D[nodeYIndex][nodeYNextIndex];

	if (moveGain > -Min)return false;
	swapNode(nodeU,nodeV);
	swapNode(nodeX,nodeY);
	move_ejection_list();

	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_seven(){
	if (nodeX->isDepot || nodeY->isDepot || nodeY == nodeU->pre || nodeU == nodeY || nodeX == nodeV || nodeV == nodeX->next) return false;
	//
	if (data->useMoveEjection && data->Range > 0){
		if ( locU != locV && !ejection_move(nodeU->dem+nodeX->dem, nodeV->dem+nodeY->dem))// operation the customers
			return false;
	}
	else{
		if (nodeU->route->whichLocation != nodeV->route->whichLocation){
			if (nodeU->route->whichLocation->remainInven + nodeV->dem + nodeY->dem - nodeU->dem - nodeX->dem > nodeU->route->whichLocation->inventory)return false;
			if (nodeV->route->whichLocation->remainInven + nodeU->dem + nodeX->dem - nodeV->dem - nodeY->dem > nodeV->route->whichLocation->inventory)return false;
		}
	}
	//
	if (nodeU->route->load - nodeU->dem - nodeX->dem + nodeV->dem + nodeY->dem > data->vehCap || nodeV->route->load - nodeV->dem - nodeY->dem + nodeU->dem + nodeX->dem > data->vehCap)return false;
	// the distances constraints for two routes
	if (routeU->dis + data->D[nodeUPrevIndex][nodeYIndex] + data->D[nodeYIndex][nodeVIndex] + data->D[nodeVIndex][nodeXNextIndex]
		- data->D[nodeUPrevIndex][nodeUIndex] - data->D[nodeUIndex][nodeXIndex] - data->D[nodeXIndex][nodeXNextIndex] > data->maxLength)
		return false;
	if (routeV->dis + data->D[nodeVPrevIndex][nodeXIndex] + data->D[nodeXIndex][nodeUIndex] + data->D[nodeUIndex][nodeYNextIndex]
		- data->D[nodeVPrevIndex][nodeVIndex] - data->D[nodeVIndex][nodeYIndex] - data->D[nodeYIndex][nodeYNextIndex] > data->maxLength)
		return false;
	//
	moveGain=data->D[nodeUPrevIndex][nodeYIndex]+data->D[nodeVIndex][nodeXNextIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeXIndex][nodeXNextIndex];
	moveGain+=data->D[nodeVPrevIndex][nodeXIndex]+data->D[nodeUIndex][nodeYNextIndex]-data->D[nodeVPrevIndex][nodeVIndex]-data->D[nodeYIndex][nodeYNextIndex];

	if (moveGain > -Min)return false;

	swapNode(nodeX,nodeV);
	swapNode(nodeU,nodeY);
	move_ejection_list();
	//
	nbMoves++;
	searchComplete=false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	if (routeU != routeV) s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS:: Relocate_eight(){
	if (nodeU->position >nodeV->position)return false;
	if (nodeU->next == nodeV)return false;
	moveGain=data->D[nodeUIndex][nodeVIndex]+data->D[nodeYIndex][nodeXIndex]-data->D[nodeUIndex][nodeXIndex]-data->D[nodeVIndex][nodeYIndex];
	if (moveGain > -Min)return false;
	Node * nodeNum = nodeX->next;
	nodeX->pre = nodeNum;
	nodeX->next = nodeY;

	while (nodeNum != nodeV){
		Node * temp = nodeNum->next;
		nodeNum->next = nodeNum->pre;
		nodeNum->pre = temp;
		nodeNum = temp;
	}

	nodeV->next = nodeV->pre;
	nodeV->pre = nodeU;
	nodeU->next = nodeV;
	nodeY->pre = nodeX;

	nbMoves++; // Increment move counter before updating route data
	searchComplete = false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_nine(){

	if (data->useMoveEjection && data->Range > 0){
		if ( locU != locV && !ejection_move(routeU->load - nodeU->cumulatedLoad, nodeV->cumulatedLoad))// operation the customers
			return false;
	}
	else{
		if (routeU->whichLocation != routeV->whichLocation){
			if (routeU->whichLocation->remainInven + nodeV->cumulatedLoad - (routeU->load - nodeU->cumulatedLoad) > routeU->whichLocation->inventory)
				return false;
			if (routeV->whichLocation->remainInven + (routeU->load - nodeU->cumulatedLoad) - nodeV->cumulatedLoad > routeV->whichLocation->inventory)
				return false;
		}
	}


	if (nodeU->cumulatedLoad + nodeV->cumulatedLoad >= data->vehCap)return false;
	if (routeU->load - nodeU->cumulatedLoad + routeV->load - nodeV->cumulatedLoad >= data->vehCap)return false;
	//
	Node *lastU = nodeU->route->endDepot->pre;
	Node *beginV =nodeV->route->depot->next;
	if (!nodeY->isDepot){
		if (routeU->dis - nodeX->cumulatedDis - data->D[lastU->cour][routeU->depot->cour]
			+ routeV->dis - nodeY->cumulatedDis + data->D[nodeXIndex][nodeYIndex] + data->D[lastU->cour][routeV->depot->cour] > data->maxLength )
			return false;
	}
	else{
		if (routeU->dis - nodeX->cumulatedDis - data->D[lastU->cour][routeU->depot->cour]
		    + data->D[nodeXIndex][nodeYIndex] + data->D[lastU->cour][routeV->depot->cour] > data->maxLength )
			return false;
	}
	if (!nodeV->isDepot){
		if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] + nodeV->cumulatedDis - data->D[beginV->cour][nodeV->route->whichLocation->cour]
			+ data->D[beginV->cour][nodeU->route->endDepot->cour] > data->maxLength)
			return false;
	}
	else{
		if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeU->route->endDepot->cour] > data->maxLength)
			return false;
	}
	//
//	if (nodeX->isDepot && nodeV->isDepot)return false;

	moveGain = compute(nodeV->route->whichLocation->used, data->openCostLoc[nodeV->route->whichLocation->cour])
			- compute(!(((nodeV->route->whichLocation->splitTime == 1 && nodeV->route->whichLocation->in_range.size() == 0) && nodeV->route->whichLocation->in_range.size() == 0) &&routeU->whichLocation != routeV->whichLocation&& nodeY->isDepot && nodeX->isDepot), data->openCostLoc[nodeV->route->whichLocation->cour])
			+ compute(!(nodeV->isDepot && nodeY->isDepot && !nodeX->isDepot), data->usingCostVeh)
			- compute(!(nodeX->isDepot && nodeY->isDepot), data->usingCostVeh);
	double distanceMoveGain = 0;
	if (nodeV->isDepot){
		distanceMoveGain += data->D[nodeUIndex][nodeU->route->endDepot->cour];
		if (nodeX->isDepot)
			distanceMoveGain += data->D[routeV->depot->cour][nodeYIndex];
		else{
			distanceMoveGain += data->D[nodeX->cour][nodeYIndex];
			distanceMoveGain += data->D[lastU->cour][routeV->depot->cour];
			distanceMoveGain = distanceMoveGain - data->D[lastU->cour][routeU->depot->cour];
		}
	}
	else{
		distanceMoveGain += data->D[nodeUIndex][nodeVIndex];
		distanceMoveGain += data->D[routeU->depot->cour][beginV->cour];
		distanceMoveGain = distanceMoveGain - data->D[routeV->depot->cour][beginV->cour];
		if (nodeX->isDepot)
			distanceMoveGain += data->D[routeV->depot->cour][nodeYIndex];
		else{
			distanceMoveGain += data->D[nodeX->cour][nodeYIndex];
			distanceMoveGain += data->D[lastU->cour][routeV->depot->cour];
			distanceMoveGain = distanceMoveGain - data->D[lastU->cour][routeU->depot->cour];
		}
	}
	distanceMoveGain = distanceMoveGain - data->D[nodeUIndex][nodeXIndex] - data->D[nodeVIndex][nodeYIndex];

	moveGain += distanceMoveGain;

	if (moveGain > -Min)return false;

	move_ejection_list();

	Node * depotV = routeV->depot;

	Node * temp;
	Node * xx = nodeX;
	Node * vv = nodeV;

	while (!xx->isDepot){
		temp = xx->next;
		xx->next = xx->pre;
		xx->pre = temp;
		xx->route = routeV;
		xx = temp;
	}

	while (!vv->isDepot){
		temp = vv->pre;
		vv->pre = vv->next;
		vv->next = temp;
		vv->route = routeU;
		vv = temp;
	}

	if (nodeV->isDepot){
		nodeU->next = routeU->endDepot;
		routeU->endDepot->pre = nodeU;
		if (nodeX->isDepot){
			nodeY->pre = depotV;
			depotV->next = nodeY;
		}
		else{
			nodeY->pre = nodeX;
			nodeX->next = nodeY;
			lastU->pre = depotV;
			depotV->next = lastU;
		}
	}
	else{
		nodeU->next= nodeV;
		nodeV->pre = nodeU;
		beginV->next = routeU->endDepot;
		routeU->endDepot->pre = beginV;
		if (nodeX->isDepot){
			nodeY->pre = depotV;
			depotV->next = nodeY;
		}
		else{
			nodeY->pre = nodeX;
			nodeX->next = nodeY;
			lastU->pre = depotV;
			depotV->next = lastU;
		}
	}

	nbMoves++; // Increment move counter before updating route data
	searchComplete = false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::Relocate_ten(){
	if (data->useMoveEjection && data->Range > 0){
		if ( locU != locV && !ejection_move(routeU->load - nodeU->cumulatedLoad, routeV->load - nodeV->cumulatedLoad))// operation the customers
			return false;
	}
	else{
		if (routeU->whichLocation != routeV->whichLocation){
			if (routeU->whichLocation->remainInven + (routeV->load - nodeV->cumulatedLoad) - (routeU->load - nodeU->cumulatedLoad) > routeU->whichLocation->inventory)
				return false;
			if (routeV->whichLocation->remainInven + (routeU->load - nodeU->cumulatedLoad) - (routeV->load - nodeV->cumulatedLoad) > routeV->whichLocation->inventory)
				return false;
		}
	}

	if (!nodeY->isDepot){
		if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeYIndex] + routeV->dis - nodeY->cumulatedDis
			- data->D[nodeV->route->endDepot->pre->cour][nodeV->route->endDepot->cour] + data->D[nodeV->route->endDepot->pre->cour][nodeU->route->endDepot->cour] > data->maxLength)
			return false;
	}
	else{
		if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeU->route->endDepot->cour] > data->maxLength)
			return false;
	}
	if (!nodeX->isDepot){
		if (nodeV->cumulatedDis + data->D[nodeVIndex][nodeXIndex] + routeU->dis - nodeX->cumulatedDis
			- data->D[nodeU->route->endDepot->pre->cour][nodeU->route->endDepot->cour] + data->D[nodeU->route->endDepot->pre->cour][nodeV->route->endDepot->cour] > data->maxLength)
			return false;
	}
	else{
		if (nodeV->cumulatedDis + data->D[nodeVIndex][nodeV->route->endDepot->cour] > data->maxLength)
			return false;
	}

//	if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeYIndex] + routeV->dis - nodeY->cumulatedDis > data->maxLength)
//		return false;
//	if (nodeV->cumulatedDis + data->D[nodeVIndex][nodeXIndex] + routeU->dis - nodeX->cumulatedDis > data->maxLength)
//		return false;


	if (nodeU->cumulatedLoad + routeV->load - nodeV->cumulatedLoad > data->vehCap)return false;
	if (routeU->load - nodeU->cumulatedLoad + nodeV->cumulatedLoad > data->vehCap)return false;
//	if (nodeX->isDepot && nodeY->isDepot)return false;
	moveGain = compute(nodeV->route->whichLocation->used, data->openCostLoc[nodeV->route->whichLocation->cour])
			- compute(!((nodeV->route->whichLocation->splitTime == 1 && nodeV->route->whichLocation->in_range.size() == 0) &&routeU->whichLocation != routeV->whichLocation && nodeV->isDepot && nodeX->isDepot), data->openCostLoc[nodeV->route->whichLocation->cour])
			+ compute(!(nodeV->isDepot && nodeY->isDepot && !nodeX->isDepot), data->usingCostVeh)
			- compute(!(nodeX->isDepot && nodeV->isDepot), data->usingCostVeh);
	double distanceMoveGain = 0;
	Node *lastU = nodeU->route->endDepot->pre;
	Node *lastV =nodeV->route->endDepot->pre;
	if (nodeY->isDepot){
		distanceMoveGain += data->D[nodeUIndex][routeU->endDepot->cour];
		if (nodeX->isDepot)
			distanceMoveGain += data->D[routeV->depot->cour][nodeVIndex];
		else{
			distanceMoveGain += data->D[nodeX->cour][nodeVIndex];
			distanceMoveGain += data->D[routeV->depot->cour][lastU->cour];
			distanceMoveGain = distanceMoveGain - data->D[routeU->depot->cour][lastU->cour];
		}
	}
	else{
		distanceMoveGain += data->D[nodeUIndex][nodeYIndex];
		distanceMoveGain += data->D[routeU->depot->cour][lastV->cour];
		distanceMoveGain = distanceMoveGain - data->D[routeV->depot->cour][lastV->cour];
		if (nodeX->isDepot)
			distanceMoveGain += data->D[routeV->depot->cour][nodeVIndex];
		else{
			distanceMoveGain += data->D[nodeX->cour][nodeVIndex];
			distanceMoveGain += data->D[routeV->depot->cour][lastU->cour];
			distanceMoveGain = distanceMoveGain - data->D[routeU->depot->cour][lastU->cour];
		}
	}
	distanceMoveGain = distanceMoveGain - data->D[nodeUIndex][nodeXIndex] - data->D[nodeVIndex][nodeYIndex];

	moveGain += distanceMoveGain;
	if (moveGain > -Min)return false;

	move_ejection_list();

	Node * count = nodeY;
	while (!count->isDepot){
		count->route = routeU;
		count = count->next;
	}

	count = nodeX;
	while (!count->isDepot){
		count->route = routeV;
		count = count->next;
	}

	if (nodeY->isDepot){
		nodeU->next = routeU->endDepot;
		routeU->endDepot->pre = nodeU;
		if (nodeX->isDepot){
			nodeV->next = routeV->endDepot;
			routeV->endDepot->pre = nodeV;
		}
		else{
			lastU->next = routeV->endDepot;
			routeV->endDepot->pre = lastU;
			nodeV->next = nodeX;
			nodeX->pre = nodeV;
		}
	}
	else{
		nodeU->next = nodeY;
		nodeY->pre = nodeU;
		lastV->next = routeU->endDepot;
		routeU->endDepot->pre = lastV;
		if (nodeX->isDepot){
			nodeV->next = routeV->endDepot;
			routeV->endDepot->pre = nodeV;
		}
		else{
			lastU->next = routeV->endDepot;
			routeV->endDepot->pre = lastU;
			nodeV->next = nodeX;
			nodeX->pre = nodeV;
		}
	}

	nbMoves++; // Increment move counter before updating route data
	searchComplete = false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);

	s->evaluationDis();
	s->isRight();

	return true;
}
bool LS::two_opt_starR(){// distinguish all cases
	if (routeU == routeV) return false;
	locU = routeU->whichLocation;
	locV = routeV->whichLocation;
	moveGain = Max;

//	s->outputSolution();

	if (locU == locV){// two routes come from the same location
		double c1 = data->D[nodeXIndex][nodeYIndex] - data->D[nodeUIndex][nodeXIndex];
	//	if (c1 > 0 && (!nodeX->isDepot && !nodeY->isDepot)) return false;// the second condition is used to decide whether a route is eliminated
		if (routeU->load + nodeV->cumulatedLoad - (routeU->load - nodeU->cumulatedLoad) > data->vehCap) return false;
		if (routeV->load - nodeV->cumulatedLoad + (routeU->load - nodeU->cumulatedLoad) > data->vehCap) return false;

		if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] + nodeV->cumulatedDis > data->maxLength)
			return false;
		if (routeU->dis - nodeX->cumulatedDis + data->D[nodeXIndex][nodeYIndex] + routeV->dis - nodeY->cumulatedDis > data->maxLength)
			return false;

		double c2 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeVIndex][nodeYIndex];
		if (nodeX->isDepot && nodeY->isDepot)
			c2 = c2 - data->usingCostVeh;// a route is removed
		moveGain = c1 + c2;
		if (moveGain < 0){
			if (nodeV->isDepot){
				Node * temp;
				Node * xx = nodeX;
				Node * vv = nodeV;
				Node * endU = routeU->endDepot->pre;
				while (!xx->isDepot){
					temp = xx->next;
					xx->next = xx->pre;
					xx->pre = temp;
					xx->route = routeV;
					xx = temp;
				}
				nodeU->next = routeU->endDepot;
				//
				if (!nodeX->isDepot){// two cases
					routeV->depot->next = endU;
					endU->pre = routeV->depot;
					nodeX->next = nodeY;
					nodeY->pre = nodeX;
				}
				else{
					routeV->depot->next = nodeY;
					nodeY->pre = routeV->depot;
				}
			}
			else{
				Node * temp;
				Node * xx = nodeX;
				Node * vv = nodeV;
				Node * endU = routeU->endDepot->pre;
				Node * beginV = routeV->depot->next;// there is definitely a beginV;
				while (!xx->isDepot){
					temp = xx->next;
					xx->next = xx->pre;
					xx->pre = temp;
					xx->route = routeV;
					xx = temp;
				}
				while (!vv->isDepot){
					temp = vv->pre;
					vv->pre = vv->next;
					vv->next = temp;
					vv->route = routeU;
					vv = temp;
				}
				nodeU->next = nodeV;
				nodeV->pre = nodeU;
				beginV->next = routeU->endDepot;
				routeU->endDepot->pre = beginV;
				//
				if (!nodeX->isDepot){// two cases
					routeV->depot->next = endU;
					endU->pre = routeV->depot;
					nodeX->next = nodeY;
					nodeY->pre = nodeX;
				}
				else{
					routeV->depot->next = nodeY;
					nodeY->pre = routeV->depot;
				}
			}
		}
		else return false;
	}
	else{
		Node * nodeVPre = nodeV->pre;
		while(1){
			if (!nodeX->isDepot && !nodeV->isDepot){
				Node *nodeUE = routeU->endDepot->pre;
				Node *nodeVB = routeV->depot->next;
				double c1 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeUIndex][nodeXIndex]
					+ data->D[nodeVB->cour][routeU->depot->cour] - data->D[routeV->depot->cour][nodeVB->cour];
	//			if (c1 > 0) return false;
				if (nodeU->cumulatedLoad + nodeV->cumulatedLoad > data->vehCap)return false;
				if (routeU->load - nodeU->cumulatedLoad + routeV->load - nodeV->cumulatedLoad > data->vehCap)return false;

				if (data->useMoveEjection && data->Range > 0){
					if ( locU != locV && !ejection_move(routeU->load - nodeU->cumulatedLoad, nodeV->cumulatedLoad))// operation the customers
						return false;
				}
				else{
					if (locU->remainInven + nodeV->cumulatedLoad - (routeU->load - nodeU->cumulatedLoad) > locU->inventory)return false;
					if (locV->remainInven + (routeU->load - nodeU->cumulatedLoad) - nodeV->cumulatedLoad > locV->inventory) return false;
				}
				//
				/********************************************/
				if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] + data->D[routeU->endDepot->cour][nodeVB->cour]
					+ nodeV->cumulatedDis - data->D[routeV->depot->cour][nodeVB->cour] > data->maxLength)
					return false;
				if (routeU->dis - nodeX->cumulatedDis - data->D[nodeUE->cour][routeU->depot->cour] + data->D[nodeXIndex][nodeYIndex]
					+ routeV->dis - nodeY->cumulatedDis + data->D[routeV->depot->cour][nodeUE->cour] > data->maxLength)
					return false;
				//
				double c2 = data->D[nodeXIndex][nodeYIndex] - data->D[nodeVIndex][nodeYIndex]
					+ data->D[nodeUE->cour][routeV->depot->cour] - data->D[nodeUE->cour][routeU->depot->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){
					move_ejection_list();
					Node * temp;
					Node * xx = nodeX;
					Node * vv = nodeV;

					while (!xx->isDepot){
						temp = xx->next;
						xx->next = xx->pre;
						xx->pre = temp;
						xx->route = routeV;
						xx = temp;
					}
					while (!vv->isDepot){
						temp = vv->pre;
						vv->pre = vv->next;
						vv->next = temp;
						vv->route = routeU;
						vv = temp;
					}
					nodeU->next = nodeV;
					nodeV->pre = nodeU;
					nodeX->next = nodeY;
					nodeY->pre = nodeX;
					routeV->depot->next = nodeUE;
					nodeUE->pre = routeV->depot;
					nodeVB->next = routeU->endDepot;
					routeU->endDepot->pre = nodeVB;
				}
				break;
			}
			if (!nodeU->isDepot && !nodeY->isDepot){
				Node * nodeVE = routeV->endDepot->pre;
				Node * nodeUB = routeU->depot->next;
				double c1 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeUIndex][nodeXIndex]
					+ data->D[nodeUB->cour][routeV->depot->cour] - data->D[nodeVE->cour][routeV->depot->cour];
	//			if (c1 > 0) return false;
				if (nodeU->cumulatedLoad + nodeV->cumulatedLoad > data->vehCap)return false;
				if (routeU->load - nodeU->cumulatedLoad + routeV->load - nodeV->cumulatedLoad > data->vehCap)return false;
				if (data->useMoveEjection && data->Range > 0){
					if ( locU != locV && !ejection_move(nodeU->cumulatedLoad, routeV->load - nodeV->cumulatedLoad))// operation the customers
						return false;
				}
				else{
					if (locU->remainInven + routeV->load - nodeV->cumulatedLoad - nodeU->cumulatedLoad > locU->inventory)return false;
					if (locV->remainInven + nodeU->cumulatedLoad -(routeV->load - nodeV->cumulatedLoad) > locV->inventory) return false;
				}

				/********************************************/
				if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] - data->D[nodeUB->cour][routeU->depot->cour] + nodeV->cumulatedDis + data->D[nodeUB->cour][routeV->depot->cour] > data->maxLength)
					return false;
				if (routeU->dis - nodeX->cumulatedDis + data->D[nodeVE->cour][routeU->depot->cour] + data->D[nodeXIndex][nodeYIndex]+routeV->dis - nodeY->cumulatedDis - data->D[routeV->depot->cour][nodeVE->cour] > data->maxLength)
					return false;


				double c2 = data->D[nodeXIndex][nodeYIndex] - data->D[nodeVIndex][nodeYIndex]
					+ data->D[nodeVE->cour][routeU->depot->cour] - data->D[nodeUB->cour][routeU->depot->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();

					Node * temp;
					Node * xx = nodeX;
					Node * vv = nodeU;
					//
					while (!xx->isDepot){
						temp = xx->next;
						xx->next = xx->pre;
						xx->pre = temp;
						xx = temp;
					}
					xx = nodeY;
					while(!xx->isDepot){
						xx->route = routeU;
						xx = xx->next;
					}
					while (!vv->isDepot){
						temp = vv->pre;
						vv->pre = vv->next;
						vv->next = temp;
						vv->route = routeV;
						vv = temp;
					}
					if (nodeX->isDepot)
						nodeX = routeU->depot;

					nodeU->pre = nodeV;
					nodeV->next = nodeU;
					nodeUB->next = routeV->endDepot;
					routeV->endDepot->pre = nodeUB;


					nodeX->next = nodeY;
					nodeY->pre = nodeX;
					nodeVE->next = routeU->endDepot;
					routeU->endDepot->pre = nodeVE;
				}
				break;
			}
			if (nodeY->isDepot && !nodeU->isDepot){
				Node *nodeUB = routeU->depot->next;
				//
				if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] - data->D[nodeUB->cour][routeU->depot->cour] + nodeV->cumulatedDis + data->D[nodeUB->cour][routeV->depot->cour] > data->maxLength)
					return false;

				//
				double c1 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeUIndex][nodeXIndex]
					+ data->D[routeU->depot->cour][nodeXIndex] - data->D[routeU->depot->cour][nodeUB->cour];
				if (c1 > 0 && !nodeX->isDepot)return false;
				if (routeV->load + nodeU->cumulatedLoad > data->vehCap)return false;
	//
				if (data->useMoveEjection && data->Range > 0){
					if ( locU != locV && !ejection_move(nodeU->cumulatedLoad, 0))// operation the customers
						return false;
				}
				else{
					if (locV->remainInven + nodeU->cumulatedLoad > locV->inventory)return false;
				}

				double c2 = data->D[nodeUB->cour][routeV->depot->cour] - data->D[nodeV->cour][routeV->depot->cour];
				if (nodeX->isDepot)
					c2 = c2 - data->usingCostVeh;
				if (locU->splitTime == 1 && locU->in_range.size() == 0 && nodeX->isDepot)
					c2 = c2 - data->openCostLoc[locU->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();

					Node * temp;
					Node * vv = nodeU;
					while (!vv->isDepot){
						temp = vv->pre;
						vv->pre = vv->next;
						vv->next = temp;
						vv->route = routeV;
						vv = temp;
					}
					nodeV->next = nodeU;
					nodeU->pre = nodeV;
					nodeUB->next = routeV->endDepot;
					routeV->endDepot->pre = nodeUB;
					routeU->depot->next = nodeX;
					nodeX->pre = routeU->depot;
				}
				break;
			}
			if (nodeVPre->isDepot && !nodeU->isDepot){
				Node *nodeUE = routeU->endDepot->pre;

				if (routeU->dis - nodeU->cumulatedDis - data->D[nodeUE->cour][routeU->depot->cour] + data->D[nodeUE->cour][routeV->depot->cour] + routeV->dis - nodeV->cumulatedDis > data->maxLength)
					return false;

				double c1 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeUIndex][nodeUPrevIndex]
					+ data->D[routeU->depot->cour][nodeU->pre->cour] - data->D[routeU->depot->cour][nodeUE->cour];
				if (c1 > 0 && !nodeU->pre->isDepot)return false;
				if (routeV->load + routeU->load - nodeU->pre->cumulatedLoad > data->vehCap)return false;
				//
				if (data->useMoveEjection && data->Range > 0){
					if (locU != locV && !ejection_move(routeU->load - nodeU->pre->cumulatedLoad, 0))// operation the customers
						return false;
				}
				else{
					if (locV->remainInven + routeU->load - nodeU->pre->cumulatedLoad > locV->inventory)return false;
				}
				//
				double c2 = data->D[nodeUE->cour][routeV->depot->cour] - data->D[nodeV->cour][routeV->depot->cour];
				if (nodeU->pre->isDepot)
					c2 = c2 - data->usingCostVeh;
				if (locU->splitTime == 1 && locU->in_range.size() == 0 && nodeU->pre->isDepot)
					c2 = c2 - data->openCostLoc[locU->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();

					Node * temp;
					Node * vv = nodeU;
					while (!vv->isDepot){
						temp = vv->next;
						vv->pre = vv->next;
						vv->next = temp;
						vv->route = routeV;
						vv = temp;
					}
					Node * nodeUPre = nodeU->pre;
					nodeU->next = nodeV;
					nodeV->pre = nodeU;
					nodeUPre->next = routeU->endDepot;
					routeU->endDepot->pre = nodeUPre;
					routeV->depot->next = nodeUE;
					nodeUE->pre = routeV->depot;
				}
				break;
			}
		}
	}
	if (moveGain >= 0)return false;
	//
	move_ejection_list();
	nbMoves++; // Increment move counter before updating route data
	searchComplete = false;
	s->updateRouteInfor(routeU->cour,nbMoves);
	s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (locU->cour != locV->cour)
		s->updateLocationInfor(routeV->whichLocation->cour);
//	s->outputSolution();
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::two_opt_star(){// distinguish all cases, there are four cases.
	if (routeU == routeV || (nodeX->isDepot && nodeY->isDepot))return false;
	locU = routeU->whichLocation;
	locV = routeV->whichLocation;
	moveGain = Max;
	if (locU == locV){// two routes come from the same location
		double c1 = data->D[nodeVPrevIndex][nodeXIndex] - data->D[nodeUIndex][nodeXIndex];
	//	if (c1 > 0 && (!nodeX->isDepot || !nodeV->pre->isDepot))return false;// if there is no route eliminated
		// decide the feasibility
		if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] + routeV->dis - nodeV->cumulatedDis > data->maxLength)
			return false;
		if (nodeV->pre->cumulatedDis + data->D[nodeVPrevIndex][nodeXIndex] + routeU->dis - nodeX->cumulatedDis > data->maxLength)
			return false;

		if (routeU->load - (routeU->load - nodeU->cumulatedLoad) + (routeV->load - nodeV->pre->cumulatedLoad) > data->vehCap)return false;
		if (routeV->load - (routeV->load - nodeV->pre->cumulatedLoad) + (routeU->load - nodeU->cumulatedLoad) > data->vehCap)return false;
		double c2 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeVPrevIndex][nodeVIndex];
		if (nodeX->isDepot && nodeV->pre->isDepot)
			c2 = c2 - data->usingCostVeh;// a route is removed
		moveGain = c1 + c2;
		if (moveGain < 0){// to exchange two substrings


			Node * nodeVP = nodeV->pre;
			nodeU->next = nodeV;
			nodeV->pre = nodeU;
			Node *Uend = routeU->endDepot->pre;
			Node *Vend = routeV->endDepot->pre;
			if (nodeX->isDepot){
				nodeVP->next = routeV->endDepot;
				routeV->endDepot->pre = nodeVP;
			}
			else{
				nodeVP->next = nodeX;
				nodeX->pre = nodeVP;
				Uend->next = routeV->endDepot;
				routeV->endDepot->pre = Uend;
			}
			Vend->next = routeU->endDepot;
			routeU->endDepot->pre = Vend;
			//
			Node *p = nodeX;
			while(!p->isDepot){
				p->route = routeV;
				p = p->next;
			}
			p = nodeV;
			while(!p->isDepot){
				p->route = routeU;
				p = p->next;
			}
		}
		else return false;
	}
	else{// two opt and there are two many cases and we can list it,,,,,,,,,,the costs of routes and locations
		Node * nodeVPre = nodeV->pre;
		while(1){
			if (!nodeU->isDepot && !nodeVPre->isDepot && !nodeX->isDepot){//the first case
				Node * nodeUB = routeU->depot->next;// the begin node in route U
				Node * nodeVB = routeV->depot->next;// the begin node in route V
				double c1 = data->D[nodeXIndex][nodeVPrevIndex] - data->D[nodeUIndex][nodeXIndex]
					+ data->D[routeV->depot->cour][nodeUB->cour] - data->D[routeU->depot->cour][nodeUB->cour];
				//
				if (nodeU->cumulatedDis - data->D[nodeUB->cour][routeU->depot->cour] + data->D[nodeUIndex][nodeVIndex] + routeV->dis - nodeV->cumulatedDis + data->D[nodeUB->cour][routeV->depot->cour] > data->maxLength)
					return false;
				if (nodeVPre->cumulatedDis - data->D[nodeVB->cour][routeV->depot->cour] + data->D[nodeVPre->cour][nodeXIndex] + routeU->dis - nodeX->cumulatedDis + data->D[nodeVB->cour][routeU->depot->cour] > data->maxLength)
					return false;
				if (routeU->load + nodeV->pre->cumulatedLoad - nodeU->cumulatedLoad > data->vehCap) return false;// route capacity
				if (routeV->load - nodeV->pre->cumulatedLoad + nodeU->cumulatedLoad > data->vehCap) return false;// location capacity
				//
				if (data->useMoveEjection && data->Range > 0){
					if ( locU != locV && !ejection_move(nodeU->cumulatedLoad, nodeV->pre->cumulatedLoad))// operation the customers
						return false;
				}
				else{
					if (locU->remainInven + nodeV->pre->cumulatedLoad - nodeU->cumulatedLoad > locU->inventory) return false;
					if (locV->remainInven - nodeV->pre->cumulatedLoad + nodeU->cumulatedLoad > locV->inventory) return false;
				}
				//
				double c2 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeVPrevIndex][nodeVIndex]
					+ data->D[routeU->depot->cour][nodeVB->cour] - data->D[routeV->depot->cour][nodeVB->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();

					Node *p = nodeUB;
					while (p != nodeX){
						p->route = routeV;
						p = p->next;
					}
					p = nodeVB;
					while (p != nodeV){
						p->route = routeU;
						p = p->next;
					}
					//
					routeU->depot->next = nodeVB;
					nodeVB->pre = routeU->depot;
					routeV->depot->next = nodeUB;
					nodeUB->pre = routeV->depot;
					nodeU->next = nodeV;
					nodeV->pre = nodeU;
					nodeX->pre = nodeVPre;
					nodeVPre->next = nodeX;
				}
				break;
			}
			if (!nodeX->isDepot && !nodeV->isDepot && !nodeVPre->isDepot){
				Node * nodeUE = routeU->endDepot->pre;// the end node in route U
				Node * nodeVE = routeV->endDepot->pre;// the end node in route V
				//
				if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] + routeV->dis - nodeV->cumulatedDis - data->D[nodeVE->cour][routeV->depot->cour] + data->D[nodeVE->cour][routeU->depot->cour] > data->maxLength)
					return false;
				if (nodeVPre->cumulatedDis + data->D[nodeVPre->cour][nodeXIndex] + routeU->dis - nodeX->cumulatedDis - data->D[nodeUE->cour][routeU->depot->cour] + data->D[nodeUE->cour][routeV->depot->cour] > data->maxLength)
					return false;

				double c1 = data->D[nodeXIndex][nodeVPrevIndex] - data->D[nodeUIndex][nodeXIndex]
					+ data->D[nodeUE->cour][routeV->depot->cour] - data->D[nodeUE->cour][routeU->depot->cour];
	//			if (c1 > 0)return false;// refuse the operation
				if (routeU->load + (routeV->load - nodeV->pre->cumulatedLoad) - (routeU->load - nodeU->cumulatedLoad) > data->vehCap) return false;// route capacity
				if (routeV->load - (routeV->load - nodeV->pre->cumulatedLoad) + (routeU->load - nodeU->cumulatedLoad) > data->vehCap) return false;// location capacity
				if (data->useMoveEjection && data->Range > 0){
					if ( locU != locV && !ejection_move(routeU->load - nodeU->cumulatedLoad, routeV->load - nodeV->pre->cumulatedLoad))// operation the customers
						return false;
				}
				else{
					if (locU->remainInven + (routeV->load - nodeV->pre->cumulatedLoad) - (routeU->load - nodeU->cumulatedLoad) > locU->inventory) return false;
					if (locV->remainInven - (routeV->load - nodeV->pre->cumulatedLoad) + (routeU->load - nodeU->cumulatedLoad) > locV->inventory) return false;
				}

				double c2 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeVPrevIndex][nodeVIndex]
					+ data->D[routeU->depot->cour][nodeVE->cour] - data->D[routeV->depot->cour][nodeVE->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();

					Node *p = nodeX;
					while (!p->isDepot){
						p->route = routeV;
						p = p->next;
					}
					p = nodeV;
					while (!p->isDepot){
						p->route = routeU;
						p = p->next;
					}
					routeU->endDepot->pre = nodeVE;
					nodeVE->pre = routeU->depot;
					routeV->depot->next = nodeUE;
					nodeUE->pre = routeV->depot;
					nodeU->next = nodeV;
					nodeV->pre = nodeU;
					nodeX->pre = nodeVPre;
					nodeVPre->next = nodeX;
				}
				break;
			}
			if (!nodeU->isDepot && nodeVPre->isDepot){
				Node * nodeUB = routeU->depot->next;// the begin node in route V

				if (nodeU->cumulatedDis - data->D[nodeUB->cour][routeU->depot->cour] + data->D[nodeUIndex][nodeVIndex] + routeV->dis - nodeV->cumulatedDis + data->D[nodeUB->cour][routeV->depot->cour] > data->maxLength)
					return false;

				double c1 = data->D[nodeUIndex][nodeVIndex] - data->D[nodeUIndex][nodeXIndex];
				if (c1 > 0 && !nodeX->isDepot)return false;// refuse the operation
				if (routeV->load + nodeU->cumulatedLoad > data->vehCap) return false;// location capacity
				//
				if (data->useMoveEjection && data->Range > 0){
					if ( locU != locV && !ejection_move(nodeU->cumulatedLoad, 0))// operation the customers
						return false;
				}
				else{
					if (locV->remainInven + nodeU->cumulatedLoad > locV->inventory)return false;
				}
				//
				double c2 = data->D[routeU->depot->cour][nodeXIndex] - data->D[routeU->depot->cour][nodeUB->cour]
					+ data->D[routeV->depot->cour][nodeUB->cour] - data->D[routeV->depot->cour][nodeV->cour];
				if (nodeX->isDepot)
					c2 = c2 - data->usingCostVeh;
				if (locU->splitTime == 1 && locU->in_range.size() == 0 && nodeX->isDepot)
					c2 = c2 - data->openCostLoc[locU->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();

					routeU->depot->next = nodeX;
					nodeX->pre = routeU->depot;
					routeV->depot->next = nodeUB;
					nodeUB->pre = routeV->depot;
					nodeU->next = nodeV;
					nodeV->pre = nodeU;
					//
					Node *p = nodeUB;
					while (p != nodeV){
						p->route = routeV;
						p = p->next;
					}
				}
				break;
			}
			if (nodeX->isDepot && !nodeV->isDepot){
				Node * nodeVE = routeV->endDepot->pre;// the begin node in route V

				if (nodeU->cumulatedDis + data->D[nodeUIndex][nodeVIndex] + routeV->dis - nodeV->cumulatedDis - data->D[nodeVE->cour][routeV->depot->cour] + data->D[nodeVE->cour][routeU->depot->cour] > data->maxLength)
					return false;

				double c1 = data->D[nodeVIndex][nodeUIndex] - data->D[nodeVPrevIndex][nodeVIndex];
				if (c1 > 0 && !nodeV->pre->isDepot)return false;// refuse the operation
				if (routeU->load + routeV->load - nodeVPre->cumulatedLoad > data->vehCap) return false;// location capacity
				//
				if (data->useMoveEjection && data->Range > 0){
					if (locU != locV && !ejection_move(0, routeV->load - nodeVPre->cumulatedLoad))// operation the customers
						return false;
				}
				else{
					if (locU->remainInven + routeV->load - nodeVPre->cumulatedLoad > locU->inventory) return false;
				}
				//
				double c2 = data->D[nodeVPrevIndex][routeV->depot->cour] - data->D[routeV->depot->cour][nodeVE->cour]
					+ data->D[nodeVE->cour][routeU->depot->cour] - data->D[nodeUIndex][routeU->depot->cour];
				if (nodeV->pre->isDepot)
					c2 = c2 - data->usingCostVeh;
				if (locU->splitTime == 1 && locU->in_range.size() == 0 && nodeV->pre->isDepot)
					c2 = c2 - data->openCostLoc[locU->cour];
				moveGain = c1 + c2;
				if (moveGain < 0){

					move_ejection_list();
		//			s->outputSolution();
					nodeVPre->next = routeV->endDepot;
					routeV->endDepot->pre = nodeVPre;
					nodeU->next = nodeV;
					nodeV->pre = nodeU;
					nodeVE->next = routeU->endDepot;
					routeU->endDepot->pre = nodeVE;
					//
					Node *p = nodeV;
					while (!p->isDepot){
						p->route = routeU;
						p = p->next;
					}
		//			s->outputSolution();
				}
				break;
			}
		}
	}
	if (moveGain >= 0)return false;
	//
	move_ejection_list();
	s->updateRouteInfor(routeU->cour,nbMoves);
	s->updateRouteInfor(routeV->cour,nbMoves);
	s->updateLocationInfor(locU->cour);
	if (locV != locU)
		s->updateLocationInfor(locV->cour);
	nbMoves++;
	searchComplete=false;
//	s->outputSolution();
	s->evaluationDis();
	s->isRight();
	return true;
}
bool LS::ejection_move(int dem_locU_out, int dem_locV_out){
	ejection_list.clear();
	Node *p;NodeDepot *loc;
	bool indicate = true;
	// for the out out source
	if (locU->remainInven - dem_locU_out + dem_locV_out > locU->inventory){
		for (int i=0;i<numL;i++)cumLoad[i] = 0;
		indicate = false;
		int infeasibleCap = locU->remainInven - dem_locU_out + dem_locV_out - locU->inventory;
		for (int i=0;i<numL;i++){
			if (s->location[i].used && i != locU->cour - numV){
				for (int j=0;j<(int)data->overlap_cus[i][locU->cour - numV].size();j++){
					p = &s->client[data->overlap_cus[i][locU->cour - numV][j]];
					if (p->isEjection)continue;
					if (p->covered_loc == locU){
						if (locV->cour == i+numV){
							if (locV->remainInven + dem_locU_out - dem_locV_out + p->dem + cumLoad[locV->cour-numV] <= locV->inventory){
								ejection_list.push_back({p, locV});
								p->isEjection = true;
								infeasibleCap = infeasibleCap - p->dem;
								cumLoad[locV->cour-numV] += p->dem;
							}
						}
						else{
							loc = &s->location[i];
							if (loc->remainInven + p->dem + cumLoad[loc->cour - numV] < loc->inventory){
								ejection_list.push_back({p, loc});
								p->isEjection = true;
								infeasibleCap = infeasibleCap - p->dem;
								cumLoad[loc->cour - numV] += p->dem;
							}
						}
					}
					if (infeasibleCap < 0)
						break;
				}
				if (infeasibleCap < 0)
					break;
			}
		}
		if (infeasibleCap < 0){
			emptyEjectionList();
			return true;
		}
	}
	// for the in source
	if (locV->remainInven - dem_locV_out + dem_locU_out > locV->inventory){
		for (int i=0;i<numL;i++)cumLoad[i] = 0;
		indicate = false;
		int infeasibleCap = locV->remainInven - dem_locV_out + dem_locU_out - locV->inventory;
		for (int i=0;i<numL;i++){
			if (s->location[i].used && i != locV->cour - numV){
				for (int j=0;j<(int)data->overlap_cus[i][locV->cour - numV].size();j++){
					p = &s->client[data->overlap_cus[i][locV->cour - numV][j]];
					if (p->isEjection)continue;
					if (p->covered_loc == locV){
						if (locU->cour == i+numV){
							if (locU->remainInven + dem_locV_out - dem_locU_out + p->dem + cumLoad[locU->cour-numV] <= locU->inventory){
								ejection_list.push_back({p, locU});
								p->isEjection = true;
								infeasibleCap = infeasibleCap - p->dem;
								cumLoad[locU->cour - numV] += p->dem;
							}
						}
						else{
							loc = &s->location[i];
							if (loc->remainInven + p->dem + cumLoad[loc->cour-numV] < loc->inventory){
								ejection_list.push_back({p, loc});
								p->isEjection = true;
								infeasibleCap = infeasibleCap - p->dem;
								cumLoad[loc->cour-numV] += p->dem;
							}
						}
					}
					if (infeasibleCap < 0)
						break;
				}
				if (infeasibleCap < 0)
					break;
			}
		}
		if (infeasibleCap < 0){
			emptyEjectionList();
			return true;
		}
	}
	if (!indicate){
		emptyEjectionList();
		return false;
	}
	else{
		emptyEjectionList();
		return true;
	}
}
void LS::emptyEjectionList(){
	Node *p;
	for (int i=0;i<(int)ejection_list.size();i++){
		p = ejection_list[i].first;
		p->isEjection = false;
	}
}
void LS::move_ejection_list(){
	Node *p;
	NodeDepot *loc_in, *loc_out;
	for (int i=0;i<(int)ejection_list.size();i++){
		p = ejection_list[i].first;
		loc_in = ejection_list[i].second;
		loc_out = p->covered_loc;
		if ((int)loc_out->in_range.size() == 0)std::cout<<"The ejection move is wrong"<<std::endl;
		for (int j=0;j<(int)loc_out->in_range.size();j++){
			if (loc_out->in_range[j].second == p){
				loc_out->in_range.erase(loc_out->in_range.begin()+j);
				loc_out->remainInven = loc_out->remainInven - p->dem;
				break;
			}
		}
		p->covered_loc = loc_in;
		loc_in->in_range.push_back({data->D[p->cour][loc_in->cour],p});
		loc_in->remainInven += p->dem;
		s->updateCoveredInfor(loc_in->cour);
		p->isEjection = false;
	}
}
void LS::setLocalVariableRouteU(){
	routeU=nodeU->route;
	locU = routeU->whichLocation;
	nodeX=nodeU->next;
	nodeXNextIndex=nodeX->next->cour;
	nodeUIndex = nodeU->cour;
	nodeUPrevIndex = nodeU->pre->cour;
	nodeXIndex = nodeX->cour;
	loadU=nodeU->dem;
	loadX=nodeX->dem;
}
void LS::setLocalVariableRouteV(){
	routeV=nodeV->route;
	locV = routeV->whichLocation;
	nodeY=nodeV->next;
	nodeYNextIndex=nodeY->next->cour;//the next two city.  U-X-this
	nodeVIndex=nodeV->cour;
	nodeVPrevIndex=nodeV->pre->cour;
	nodeYIndex=nodeY->cour;
	loadV=nodeV->dem;
	loadY=nodeY->dem;
}
void LS::insertNode(Node *U, Node *V){
	U->pre->next = U->next;
	U->next->pre = U->pre;
	V->next->pre = U;
	U->pre = V;
	U->next = V->next;
	V->next = U;
	U->route = V->route;
	U->isUsed = true;
}
void LS::swapNode(Node *U, Node *V){
	Node * myVPred = V->pre;
	Node * myVSuiv = V->next;
	Node * myUPred = U->pre;
	Node * myUSuiv = U->next;
	Route * myRouteU = U->route;
	Route * myRouteV = V->route;

	myUPred->next = V;
	myUSuiv->pre = V;
	myVPred->next = U;
	myVSuiv->pre = U;

	U->pre = myVPred;
	U->next = myVSuiv;
	V->pre = myUPred;
	V->next = myUSuiv;

	U->route = myRouteV;
	V->route = myRouteU;
}
void LS::loadSolution(){
	nbMoves = 0;
	orderNodes.clear();
	for (int i=0;i<numV;i++){
		s->client[i].whenLastTestedRI = -1;
		if (s->client[i].covered_loc == NULL)
			orderNodes.push_back(i);
	}
	for (int i=numV;i<numC;i++){
		for (int j=0;j<s->location[i-numV].maxVisit; j++){
			s->location[i-numV].depots[j].route->whenLastModified = -1;
		}
	}
}
void LS::eliminate_empty_routes(){
	// rearrange all routes obey the order
	for (int l=0;l<numL;l++){
		std::vector<int>order_route;
		for (int i=0;i<s->location[l].maxVisit;i++){
			if (s->location[l].depots[i].route->load > 0){
				order_route.push_back(i);
			}
		}
		if (order_route.size() > 0 && (int)order_route.size()-1 != order_route[(int)order_route.size()-1]){
			Node *start_route, *end_route;
	//		s->outputSolution();
			int ccc = (int)order_route.size();
			for (int i=0;i<(int)order_route.size();i++){
				if (order_route[i] != i){
					start_route = s->location[l].depots[order_route[i]].next;
					end_route = s->location[l].endDepots[order_route[i]].pre;
					s->location[l].depots[i].next = start_route;
					start_route->pre = &s->location[l].depots[i];
					s->location[l].endDepots[i].pre = end_route;
					end_route->next = &s->location[l].endDepots[i];
					s->updateRouteInfor(s->location[l].depots[i].route->cour, -1);
				}
			}
			for (int i=ccc;i<s->location[l].maxVisit;i++){
				s->location[l].depots[i].next = &s->location[l].endDepots[i];
				s->location[l].endDepots[i].pre = &s->location[l].depots[i];
				s->updateRouteInfor(s->location[l].depots[i].route->cour, -1);
			}
		}
		int ccc = l+numV;
		s->updateLocationInfor(ccc);
	}
//	s->outputSolution();
}
void LS::local_search_run(Individual *s){
	this->s=s;
	if (!s->isFeasible)return;
	loadSolution();
	srun();
	eliminate_empty_routes();
	s->evaluationDis();
	s->isRight();
}
