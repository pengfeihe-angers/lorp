﻿/*
 * RepairProcedure.cpp
 *
 *  Created on: Aug 25, 2021
 *      Author: pengfei
 */

#include "RepairProcedure.h"

RepairProcedure::RepairProcedure(read_data *data, popManager * popman) {
	// TODO Auto-generated constructor stub
	this->data = data;
	this->numV = data->numV;
	this->numL = data->numL;
	this->numC = data->numC;
	tabuTable = new int *[data->maxVnum * data->numL];
	for (int i=0;i<data->maxVnum * data->numL; i++)
		tabuTable[i] = new int [numC];
	checkCus = new int [numV];
	cumLoad = std::vector<int>(numL);
	overCap = std::vector<int>(numL);

	this->popman = popman;
}
RepairProcedure::~RepairProcedure(){
	// TODO Auto-generated destructor stub
	for (int i=0;i<data->maxVnum * data->numL;i++)
		delete [] tabuTable[i];
	delete [] tabuTable;
	delete [] checkCus;
}
bool RepairProcedure::checkInfeasible(){
	for (int i=0;i<numL;i++){
		if (s->location[i].used){
			for (int j=0; j<s->location[i].maxVisit; j++){
				if (s->location[i].depots[j].route->used){
					if (s->location[i].depots[j].route->load > data->vehCap)
						return false;
					if (s->location[i].depots[j].route->dis > data->maxLength)
						return false;
				}
			}
			if (s->location[i].remainInven > s->location[i].inventory)
				return false;
		}
	}
	return true;
}

double RepairProcedure::penaltyExcessRoute(int load){
	return (std::max<double>(0.,load - data->vehCap) * penaltyVeh * (data->normalizaPara * s->dis));
}
double RepairProcedure::penaltyExcessDuration(double dis){
	return(std::max<double>(0, dis- data->maxLength) * penaltyDis * (data->normalizaPara * s->dis));
}
bool RepairProcedure::updateThePenalty(int iden, Route *rou){
	bool isFeasible = true;
	if (iden < 0){
		for (int i=0;i<numL;i++){
			for (int j=0; j<s->location[i].maxVisit; j++){
				s->location[i].depots[j].route->penaltyDis = penaltyExcessDuration(s->location[i].depots[j].route->dis);
				s->location[i].depots[j].route->penalty = penaltyExcessRoute(s->location[i].depots[j].route->load);
				if(s->location[i].depots[j].route->penaltyDis > 0 || s->location[i].depots[j].route->penalty > 0)
					isFeasible = false;
			}
		}
	}
	else{
		rou->penaltyDis = penaltyExcessDuration(rou->dis);
		rou->penalty = penaltyExcessRoute(rou->load);
		if(rou->penaltyDis > 0 || rou->penalty > 0)
			isFeasible = false;
	}
	return isFeasible;
}
void RepairProcedure::loadInventory(){
	s->inventory = 0;
	int numRoute = 0;
	for (int i=0;i<numL;i++){// check the total inventory
		if (s->location[i].used){
			s->inventory += s->location[i].inventory;
			numRoute += s->location[i].splitTime;
		}
		s->inventoryVeh = numRoute * data->vehCap;
	}
}
void RepairProcedure::move_ejection_list(){
	Node *p;
	NodeDepot *loc_in, *loc_out;
	for (int i=0;i<(int)ejection_list_best.size();i++){
		p = ejection_list_best[i].first;
		loc_in = ejection_list_best[i].second;
		loc_out = p->covered_loc;
		if ((int)loc_out->in_range.size() == 0)std::cout<<"The ejection move is wrong"<<std::endl;
		for (int j=0;j<(int)loc_out->in_range.size();j++){
			if (loc_out->in_range[j].second == p){
				loc_out->in_range.erase(loc_out->in_range.begin()+j);
				loc_out->remainInven = loc_out->remainInven - p->dem;
				break;
			}
		}
		p->covered_loc = loc_in;
		loc_in->in_range.push_back({data->D[p->cour][loc_in->cour],p});
		loc_in->remainInven += p->dem;
		s->updateCoveredInfor(loc_in->cour);
		p->isEjection = false;
	}
	ejection_list_best.clear();
}
void RepairProcedure::updateTheMove(){
	nodeU=nodeUb;
	nodeV=nodeVb;
	setLocalVariableRouteU();
	setLocalVariableRouteV();


	move_ejection_list();
	if (whichMove == 1){
		tabuTable[routeU->cour][nodeU->cour] = iteration + tabu_length + rand()%tabu_length;
		insertNode(nodeU,nodeV);
	}
	else if (whichMove == 4){
		tabuTable[routeU->cour][nodeU->cour] = iteration + tabu_length + rand()%tabu_length;
		tabuTable[routeV->cour][nodeV->cour] = iteration + tabu_length + rand()%tabu_length;
		swapNode(nodeU,nodeV);
	}
	else if (whichMove == 9){
		tabuTable[routeU->cour][nodeU->cour] = iteration + tabu_length + rand()%tabu_length;
		tabuTable[routeV->cour][nodeV->cour] = iteration + tabu_length + rand()%tabu_length;
		Node * depotV = routeV->depot;
		Node * temp = NULL;
		Node * xx = nodeX;
		Node * vv = nodeV;
		Node * lastU = nodeU->route->endDepot->pre;
		Node * beginV =nodeV->route->depot->next;

		while (!xx->isDepot){
			temp = xx->next;
			xx->next = xx->pre;
			xx->pre = temp;
			xx->route = routeV;
			xx = temp;
		}
		while (!vv->isDepot){
			temp = vv->pre;
			vv->pre = vv->next;
			vv->next = temp;
			vv->route = routeU;
			vv = temp;
		}
		if (nodeV->isDepot){
			nodeU->next = routeU->endDepot;
			routeU->endDepot->pre = nodeU;
			if (nodeX->isDepot){
				nodeY->pre = depotV;
				depotV->next = nodeY;
			}
			else{
				nodeY->pre = nodeX;
				nodeX->next = nodeY;
				lastU->pre = depotV;
				depotV->next = lastU;
			}
		}
		else{
			nodeU->next= nodeV;
			nodeV->pre = nodeU;
			beginV->next = routeU->endDepot;
			routeU->endDepot->pre = beginV;
			if (nodeX->isDepot){
				nodeY->pre = depotV;
				depotV->next = nodeY;
			}
			else{
				nodeY->pre = nodeX;
				nodeX->next = nodeY;
				lastU->pre = depotV;
				depotV->next = lastU;
			}
		}
	}
	else if (whichMove == 10){
		tabuTable[routeU->cour][nodeU->cour] = iteration + tabu_length + rand()%tabu_length;
		tabuTable[routeV->cour][nodeV->cour] = iteration + tabu_length + rand()%tabu_length;
		Node *lastU = nodeU->route->endDepot->pre;
		Node *lastV =nodeV->route->endDepot->pre;
		Node * count = nodeY;
		while (!count->isDepot){
			count->route = routeU;
			count = count->next;
		}
		count = nodeX;
		while (!count->isDepot){
			count->route = routeV;
			count = count->next;
		}

		if (nodeY->isDepot){
			nodeU->next = routeU->endDepot;
			routeU->endDepot->pre = nodeU;
			if (nodeX->isDepot){
				nodeV->next = routeV->endDepot;
				routeV->endDepot->pre = nodeV;
			}
			else{
				lastU->next = routeV->endDepot;
				routeV->endDepot->pre = lastU;
				nodeV->next = nodeX;
				nodeX->pre = nodeV;
			}
		}
		else{
			nodeU->next = nodeY;
			nodeY->pre = nodeU;
			lastV->next = routeU->endDepot;
			routeU->endDepot->pre = lastV;
			if (nodeX->isDepot){
				nodeV->next = routeV->endDepot;
				routeV->endDepot->pre = nodeV;
			}
			else{
				lastU->next = routeV->endDepot;
				routeV->endDepot->pre = lastU;
				nodeV->next = nodeX;
				nodeX->pre = nodeV;
			}
		}
	}
	//
	s->updateRouteInfor(routeU->cour,-1);
	s->updateRouteInfor(routeV->cour,-1);
	s->updateLocationInfor(routeU->whichLocation->cour);
	if (routeU->whichLocation != routeV->whichLocation)
		s->updateLocationInfor(routeV->whichLocation->cour);
	updateThePenalty(routeU->whichLocation->cour-numV, routeU);
	updateThePenalty(routeV->whichLocation->cour-numV, routeV);
	loadInventory();
}
void RepairProcedure::insertNode(Node *U, Node *V){
	U->pre->next = U->next;
	U->next->pre = U->pre;
	V->next->pre = U;
	U->pre = V;
	U->next = V->next;
	V->next = U;
	U->route = V->route;
	U->isUsed = true;
}
void RepairProcedure::swapNode(Node *U, Node *V){
	Node * myVPred = V->pre;
	Node * myVSuiv = V->next;
	Node * myUPred = U->pre;
	Node * myUSuiv = U->next;
	Route * myRouteU = U->route;
	Route * myRouteV = V->route;

	myUPred->next = V;
	myUSuiv->pre = V;
	myVPred->next = U;
	myVSuiv->pre = U;

	U->pre = myVPred;
	U->next = myVSuiv;
	V->pre = myUPred;
	V->next = myUSuiv;

	U->route = myRouteV;
	V->route = myRouteU;
}
double RepairProcedure::compute(bool istrue, double value){
	if (istrue)	return 0.;
	else return value;
}
void RepairProcedure::Relocate_one(){
	if ((nodeU->route->whichLocation->splitTime == 1 && nodeU->route->whichLocation->in_range.size() == 0) && nodeU->route->nbClients == 1 && s->inventory - nodeU->route->whichLocation->inventory < data->totalDemand)return;
	if (nodeV->route->whichLocation != nodeU->route->whichLocation && nodeV->route->whichLocation->remainInven + nodeU->dem > nodeV->route->whichLocation->inventory)
		return;
//	if (nodeV->route->load + nodeU->dem > data->vehCap)
//		return;
	//
	if (tabuTable[routeV->cour][nodeU->cour] > iteration) return;
	delta = compute(nodeV->route->whichLocation->used, data->openCostLoc[nodeV->route->whichLocation->cour])
			+ compute(!(nodeV->isDepot && nodeY->isDepot), data->usingCostVeh)
			- compute(!((nodeU->route->whichLocation->splitTime == 1 && nodeU->route->whichLocation->in_range.size() == 0) && nodeU->route->nbClients == 1 && nodeU->route->whichLocation != nodeV->route->whichLocation), data->openCostLoc[nodeU->route->whichLocation->cour])
			- compute(nodeU->route->nbClients != 1, data->usingCostVeh);
	double changeRouteU = data->D[nodeUPrevIndex][nodeXIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeUIndex][nodeXIndex];
	double changeRouteV = data->D[nodeVIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	delta += changeRouteU + changeRouteV;
	delta += penaltyExcessDuration(routeU->dis + changeRouteU) - routeU->penaltyDis
			+ penaltyExcessDuration(routeV->dis + changeRouteV) - routeV->penaltyDis
			+ penaltyExcessRoute(routeU->load - nodeU->dem ) - routeU->penalty
			+ penaltyExcessRoute(routeV->load + nodeU->dem ) - routeV->penalty
			+ penaltyExcessLocation(routeU->whichLocation->cour-numV, routeU->whichLocation->remainInven - nodeU->dem ) - routeU->whichLocation->penalty
			+ penaltyExcessLocation(routeV->whichLocation->cour-numV, routeV->whichLocation->remainInven + nodeU->dem ) - routeV->whichLocation->penalty;
	//
	if (delta < min_delta){
		whichMove = 1;
		nodeUb = nodeU;
		nodeVb = nodeV;
		min_delta = delta;
	}
}
void RepairProcedure::Relocate_four(){//
	if (tabuTable[routeV->cour][nodeU->cour] > iteration && tabuTable[routeU->cour][nodeV->cour] > iteration) return;
	if (nodeU->route->whichLocation->remainInven + nodeV->dem - nodeU->dem > nodeU->route->whichLocation->inventory)return;
	if (nodeV->route->whichLocation->remainInven + nodeU->dem - nodeV->dem > nodeV->route->whichLocation->inventory)return;
//	if (nodeU->route->load + nodeV->dem - nodeU->dem > data->vehCap)return;
//	if (nodeV->route->load + nodeU->dem - nodeV->dem > data->vehCap)return;

	double changeRouteU = data->D[nodeUPrevIndex][nodeVIndex]+data->D[nodeVIndex][nodeXIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeUIndex][nodeXIndex];
	double changeRouteV = data->D[nodeVPrevIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVPrevIndex][nodeVIndex]-data->D[nodeVIndex][nodeYIndex];
	delta = changeRouteU
			+ changeRouteV
			+ penaltyExcessLocation(routeU->whichLocation->cour-numV, routeU->whichLocation->remainInven - nodeU->dem + nodeV->dem) - routeU->whichLocation->penalty
			+ penaltyExcessLocation(routeV->whichLocation->cour-numV, routeV->whichLocation->remainInven + nodeU->dem - nodeV->dem) - routeV->whichLocation->penalty
			+ penaltyExcessRoute(routeU->load - nodeU->dem + nodeV->dem) - routeU->penalty
			+ penaltyExcessRoute(routeV->load + nodeU->dem - nodeV->dem) - routeV->penalty
			+ penaltyExcessDuration(routeU->dis + changeRouteU) - routeU->penaltyDis
			+ penaltyExcessDuration(routeV->dis + changeRouteV) - routeV->penaltyDis;
	//
	if (delta < min_delta){
		whichMove = 4;
		min_delta = delta;
		nodeUb = nodeU;
		nodeVb = nodeV;
	}
}
void RepairProcedure::setLocalVariableRouteU(){
	routeU=nodeU->route;
	nodeX=nodeU->next;
	nodeXNextIndex=nodeX->next->cour;
	nodeUIndex = nodeU->cour;
	nodeUPrevIndex = nodeU->pre->cour;
	nodeXIndex = nodeX->cour;
	loadU=nodeU->dem;
	loadX=nodeX->dem;
	locU = routeU->whichLocation;
}
void RepairProcedure::setLocalVariableRouteV(){
	routeV=nodeV->route;
	nodeY=nodeV->next;
	nodeYNextIndex=nodeY->next->cour;//the next two city.  U-X-this
	nodeVIndex=nodeV->cour;
	nodeVPrevIndex=nodeV->pre->cour;
	nodeYIndex=nodeY->cour;
	loadV=nodeV->dem;
	loadY=nodeY->dem;
	locV = routeV->whichLocation;
}
void RepairProcedure::loadSolution(){
	for (int i=0; i<numL;i++){
		for (int j=0;j<s->location[i].maxVisit; j++)
			s->updateRouteInfor(s->location[i].depots[j].route->cour, -1);
		int tem = i+numV;
	//	s->updateLocationInfor(tem);
	}
}
/***************************************************************************************************************/
/***************************************************************************************************************/
/***************************************************************************************************************/
/***************************************************************************************************************/
// the first way is to repair location inventory
bool RepairProcedure::selectedLocationInventoryInfeasible(){
	for (int i=0;i<numL;i++){
		if (s->location[i].remainInven > s->location[i].inventory)
			return true;
	}
	return false;
}
double RepairProcedure::penaltyLocationFunction(Node *p, int loc){
	double penalty = 0.;
	penalty += penaltyExcessLocation(loc-numV, s->location[loc-numV].remainInven + p->route->load) - s->location[loc-numV].penalty
			+ penaltyExcessLocation(p->route->whichLocation->cour-numV, p->route->whichLocation->remainInven - p->route->load) - p->route->whichLocation->penalty;
	return penalty;
}
double RepairProcedure::penaltyExcessLocation(int loc, int inventory){
	return (std::max<double>(0.,inventory - s->location[loc].inventory) * penaltyDepot * (data->normalizaPara * s->dis));
}
void RepairProcedure::repairLocation(){
	for (int i=0;i<data->maxVnum * data->numL;i++)
		for (int j=0;j<numC; j++)
			tabuTable[i][j] = 0;
	iteration = 0;
	//
	penaltyDepot = 1;
	for (int i=0;i<numL;i++)
		s->location[i].penalty = penaltyExcessLocation(i, s->location[i].remainInven);
	//
//	s->outputSolution();
	while(1){
		if (data->stopCondition(s->fit)) return;
		min_delta = Max;
		nodeU = NULL;NodeDepot *loc = NULL;
		for (int i=0;i<numL; i++){// to adjust some customers
			if (!s->location[i].used || data->equalTwoVar(s->location[i].penalty , 0))continue;// Skip unused depots and depots with feasible inventory.
			for (int j=0;j<numL;j++){
				if (i == j || !s->location[j].used)continue;
				for (int k=0;k<(int)data->overlap_cus[i][j].size();k++){
					Node *canNode = &s->client[data->overlap_cus[i][j][k]];
					//
					if(canNode->covered_loc == &s->location[i]){
						delta = (penaltyExcessLocation(i, s->location[i].remainInven - canNode->dem) + penaltyExcessLocation(j, s->location[j].remainInven + canNode->dem))
								- (s->location[i].penalty + s->location[j].penalty);
						if (delta < min_delta){
							min_delta = delta;
							nodeU = canNode;
							loc = &s->location[j];
						}
					}
					// swap a method

				}
			}
		}
		if (min_delta < 0){
			NodeDepot * loc2 = nodeU->covered_loc;
			for (int i=0;i<(int)nodeU->covered_loc->in_range.size();i++)
				if (nodeU->covered_loc->in_range[i].second == nodeU){
					nodeU->covered_loc->in_range.erase(nodeU->covered_loc->in_range.begin()+i);
					break;
				}
			nodeU->covered_loc = loc;
			loc->in_range.push_back({data->D[nodeU->cour][loc->cour], nodeU});
			s->updateCoveredInfor(loc->cour);
			s->updateCoveredInfor(loc2->cour);
			s->updateLocationInfor(loc->cour);
			s->updateLocationInfor(loc2->cour);
			//
			s->location[loc->cour - numV].penalty = penaltyExcessLocation(loc->cour-numV, s->location[loc->cour-numV].remainInven);
			s->location[loc2->cour - numV].penalty = penaltyExcessLocation(loc2->cour - numV, s->location[loc2->cour-numV].remainInven);

	//		if (data->iteration == 549)
	//		s->outputSolution();
		}
		else
			break;
	}
	int loopID = 1;
	bool isFirst;
	while(1){
		if (data->stopCondition(s->fit)) return;
		min_delta = Max;
		for (int i=0;i<numL;i++)
			overCap[i] = std::max(s->location[i].remainInven - s->location[i].inventory, 0);
		for (int i=0;i<numL;i++){
			if (s->location[i].remainInven > s->location[i].inventory){
				for (int j=0; j<s->location[i].maxVisit; j++){
					if (!s->location[i].depots[j].route->used)continue;
					nodeU = s->location[i].depots[j].next;
					while(!nodeU->isDepot){
						for (int posV = 0; posV<(int)data->edgeNode[nodeU->cour].size(); posV++){
							if (data->edgeNode[nodeU->cour][posV] < numV){
								nodeV = &s->client[data->edgeNode[nodeU->cour][posV]];
								if (nodeV->covered_loc != NULL)continue;
								//
								if (!nodeV->isUsed)continue;
								if (nodeV->route->whichLocation == nodeU->route->whichLocation)continue;
								setLocalVariableRouteU();
								setLocalVariableRouteV();
								//
								Relocate_one_depot();
								Relocate_four_depot();
							}
						}
						nodeU = nodeU->next;
					}
				}
			}
		}
		
		for (int i=0;i<numL;i++){
			if (s->location[i].remainInven > s->location[i].inventory){
				for (int j=0; j<s->location[i].maxVisit; j++){
					if (!s->location[i].depots[j].isUsed)continue;
					nodeU = s->location[i].depots[j].next;
					while(!nodeU->isDepot){
						for (int k=0;k<numL;k++){
							if (k == i || !s->location[k].used)continue;
							for (int n=0;n<s->location[k].maxVisit;n++){
								if (s->location[k].depots[n].route->used)continue;
								nodeV = &s->location[k].depots[n];
								isFirst = true;
								while(!nodeV->isDepot || isFirst){
									//
									setLocalVariableRouteU();
									setLocalVariableRouteV();
									//
									Relocate_one_depot();
									if (!nodeV->isDepot)
										Relocate_four_depot();
									nodeV = nodeV->next;
									isFirst = false;
								}
							}
						}
						nodeU = nodeU->next;
					}
				}
			}
		}
		if (min_delta == Max)
			return;
		NodeDepot * loc1 = nodeUb->route->whichLocation;
		NodeDepot * loc2 = nodeVb->route->whichLocation;

		updateTheMove();
		s->updateLocationInfor(loc1->cour);
		s->updateLocationInfor(loc2->cour);
		//
		loc1->penalty = penaltyExcessLocation(loc1->cour-numV, loc1->remainInven);
		loc2->penalty = penaltyExcessLocation(loc2->cour-numV, loc2->remainInven);

	//	if (iteration > 100) break;// using the last remedy strategy to save the solution
		if (iteration > numV *10) return;// if the solution cannot repair within fixed steps, discard it.

		iteration++;
		if (iteration > loopID*numV){
			penaltyVeh = penaltyVeh*10;
			penaltyDepot = penaltyDepot*10;
			updateThePenalty(-1, NULL);
			loopID ++;
		}
	//	s->outputSolution();
	}
}
void RepairProcedure::emptyEjectionList(){
	Node *p;
	for (int i=0;i<(int)ejection_list.size();i++){
		p = ejection_list[i].first;
		p->isEjection = false;
	}
	//
}
bool RepairProcedure::ejection_move(int dem_locU_out, int dem_locV_out){
	ejection_list.clear();
	emptyEjectionList();
	Node *p;NodeDepot *loc;
	int cumLocU,cumLocV;
	// for the out source
//	if (locU->remainInven - dem_locU_out + dem_locV_out > locU->inventory){
		for (int i=0;i<numL;i++)cumLoad[i] = 0;
		for (int i=0;i<numL;i++){
			if (s->location[i].used && i != locU->cour - numV){
				for (int j=0;j<(int)data->overlap_cus[i][locU->cour - numV].size();j++){
					p = &s->client[data->overlap_cus[i][locU->cour - numV][j]];
					if (p->isEjection)continue;
					if (locV->cour == i+numV){
						if (p->covered_loc == locV){
							cumLocV = std::max(0, locV->remainInven + dem_locU_out - dem_locV_out - p->dem + cumLoad[locV->cour-numV] - locV->inventory);
							cumLocU = std::max(0, locU->remainInven - dem_locU_out + dem_locV_out + p->dem + cumLoad[locU->cour-numV] - locU->inventory);
							if (cumLocV + cumLocU < overCap[locU->cour - numV] + overCap[locV->cour - numV]){
								ejection_list.push_back({p, locU});
								p->isEjection = true;
								cumLoad[locV->cour-numV] -= p->dem;
								cumLoad[locU->cour-numV] += p->dem;
								return true;
							}
						}
					}
					else if (p->covered_loc == &s->location[i]){

							loc = &s->location[i];
							cumLocV = std::max(0, loc->remainInven + dem_locU_out - dem_locV_out - p->dem + cumLoad[loc->cour-numV] - loc->inventory);
							cumLocU = std::max(0, locU->remainInven - dem_locU_out + dem_locV_out + p->dem + cumLoad[locU->cour-numV] - locU->inventory);
							if (cumLocV + cumLocU < overCap[locU->cour - numV] + overCap[loc->cour - numV]){
								ejection_list.push_back({p, locU});
								p->isEjection = true;
								cumLoad[loc->cour - numV] -= p->dem;
								cumLoad[locU->cour-numV] += p->dem;
								return true;
							}
						}

				}
			}
		}
	return false;
//	}
/*	// for the in source
	if (locV->remainInven - dem_locV_out + dem_locU_out > locV->inventory){
		for (int i=0;i<numL;i++)cumLoad[i] = 0;
		indicate = false;
		for (int i=0;i<numL;i++){
			if (s->location[i].used && i != locV->cour - numV){
				for (int j=0;j<(int)data->overlap_cus[i][locV->cour - numV].size();j++){
					p = &s->client[data->overlap_cus[i][locV->cour - numV][j]];
					if (p->isEjection)continue;
					if (p->covered_loc == locV){
						if (locU->cour == i+numV){
							cumLocV = locV->remainInven + dem_locU_out - dem_locV_out + p->dem + cumLoad[locV->cour-numV] - locV->inventory;
							cumLocU = locU->remainInven - dem_locU_out + dem_locV_out - p->dem + cumLoad[locU->cour-numV] - locU->inventory;

							if (locU->remainInven + dem_locV_out - dem_locU_out + p->dem + cumLoad[locU->cour-numV] <= locU->inventory){
								ejection_list.push_back({p, locU});
								p->isEjection = true;
								cumLoad[locU->cour - numV] += p->dem;
							}
						}
						else{
							loc = &s->location[i];
							if (loc->remainInven + p->dem + cumLoad[loc->cour-numV] < loc->inventory){
								ejection_list.push_back({p, loc});
								p->isEjection = true;
								cumLoad[loc->cour-numV] += p->dem;
							}
						}
					}
				}
			}
		}
	}
	*/
}

void RepairProcedure::Relocate_one_depot(){

	if (tabuTable[routeV->cour][nodeU->cour] > iteration) return;

	if (data->useMoveEjection && data->Range > 0){
		ejection_move(nodeU->dem, 0);
	}

	//
	delta = (penaltyExcessLocation(routeU->whichLocation->cour-numV, routeU->whichLocation->remainInven + cumLoad[locU->cour-numV] - nodeU->dem)
			+ penaltyExcessLocation(routeV->whichLocation->cour-numV, routeV->whichLocation->remainInven + cumLoad[locV->cour-numV] + nodeU->dem))
			- (routeU->whichLocation->penalty + routeV->whichLocation->penalty);
	//
	double changeRouteU = data->D[nodeUPrevIndex][nodeXIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeUIndex][nodeXIndex];
	double changeRouteV = data->D[nodeVIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVIndex][nodeYIndex];
	delta += changeRouteU + changeRouteV;
//	delta += penaltyExcessDuration(routeU->dis + changeRouteU) - routeU->penaltyDis
//			+ penaltyExcessDuration(routeV->dis + changeRouteV) - routeV->penaltyDis;
	//
	if (delta < min_delta){
		ejection_list_best = ejection_list;
		whichMove = 1;
		nodeUb = nodeU;
		nodeVb = nodeV;
		min_delta = delta;
	}
}
void RepairProcedure::Relocate_four_depot(){

	if (tabuTable[routeV->cour][nodeU->cour] > iteration && tabuTable[routeU->cour][nodeV->cour] > iteration) return;

	if (data->useMoveEjection && data->Range > 0){
		ejection_move(nodeU->dem, 0);
	}
	//
	delta = (penaltyExcessLocation(routeU->whichLocation->cour-numV, routeU->whichLocation->remainInven + cumLoad[locU->cour-numV] - nodeU->dem +nodeV->dem)
			+ penaltyExcessLocation(routeV->whichLocation->cour-numV, routeV->whichLocation->remainInven + cumLoad[locV->cour-numV] + nodeU->dem - nodeV->dem))
			-routeU->whichLocation->penalty + routeV->whichLocation->penalty;
	//
	double changeRouteU = data->D[nodeUPrevIndex][nodeVIndex]+data->D[nodeVIndex][nodeXIndex]-data->D[nodeUPrevIndex][nodeUIndex]-data->D[nodeUIndex][nodeXIndex];
	double changeRouteV = data->D[nodeVPrevIndex][nodeUIndex]+data->D[nodeUIndex][nodeYIndex]-data->D[nodeVPrevIndex][nodeVIndex]-data->D[nodeVIndex][nodeYIndex];
	delta += changeRouteU + changeRouteV;
//	delta += penaltyExcessDuration(routeU->dis + changeRouteU) - routeU->penaltyDis
//			+ penaltyExcessDuration(routeV->dis + changeRouteV) - routeV->penaltyDis;
	if (delta < min_delta){
		ejection_list_best = ejection_list;
		whichMove = 4;
		min_delta = delta;
		nodeUb = nodeU;
		nodeVb = nodeV;
	}
}
void RepairProcedure::repairForInitialSolution(Individual *s){
	this->s = s;
//	s->outputSolution();
	loadSolution();
	loadInventory();
	this->penaltyDis = data->penaltyDis;
	this->penaltyDepot = data->penaltyDepot;
	this->penaltyVeh = data->penaltyVeh;
	if(checkInfeasible())
		return;// check the in-feasibility
	if (selectedLocationInventoryInfeasible())// repair the capacity constraints for the location
		repairLocation();
	if(checkInfeasible())
		return;// check the in-feasibility
	int loopID = 1;
	bool inFeasible = updateThePenalty(-1, NULL);
	for (int i=0;i<data->maxVnum * data->numL;i++)
		for (int j=0;j<numC; j++)
			tabuTable[i][j] = 0;
	iteration = 0;
	while(1){
		if (data->stopCondition(s->fit)) return;
		min_delta = Max;
		for (int i=0;i<numL; i++){// to adjust some customers
			if (!s->location[i].used)continue;// the location's inventory is feasible
			for (int j=0; j<s->location[i].maxVisit; j++){
				if (s->location[i].depots[j].route->dis <= data->maxLength && s->location[i].depots[j].route->load <= data->vehCap)continue;
				inFeasible = true;
				nodeU = s->location[i].depots[j].next;
				while(!nodeU->isDepot){
					for (int posV = 0; posV<(int)data->edgeNode[nodeU->cour].size(); posV++){
						if (data->edgeNode[nodeU->cour][posV] < numV){
							nodeV = &s->client[data->edgeNode[nodeU->cour][posV]];
							if (nodeV->covered_loc != NULL)continue;
							if (nodeV->route == nodeU->route)continue;
							setLocalVariableRouteU();
							setLocalVariableRouteV();
							//
							Relocate_one();
							Relocate_four();
							// Trying moves that insert nodeU directly after the depot
							if (nodeV->pre->isDepot){
								nodeV = nodeV->pre;
								setLocalVariableRouteV();
								Relocate_one();
							}
						}
						else{
							if (data->edgeNode[nodeU->cour][posV] >= numV && s->location[data->edgeNode[nodeU->cour][posV] - numV].used){
								nodeV = s->route[s->location[data->edgeNode[nodeU->cour][posV] - numV].emptyRoutes[0]].depot;
								setLocalVariableRouteU();
								setLocalVariableRouteV();
								Relocate_one();
							}
						}
					}
					// adding a new route
					nodeV = s->route[nodeU->route->whichLocation->emptyRoutes[0]].depot;
					setLocalVariableRouteU();
					setLocalVariableRouteV();
					Relocate_one();
					nodeU = nodeU->next;
				}
			}
		}
		if (inFeasible && min_delta == Max){
			for (int i=0;i<numL; i++){// to adjust some customers
				for (int j=0; j<s->location[i].maxVisit; j++){
					if (s->location[i].depots[j].route->load <= data->vehCap && s->location[i].depots[j].route->dis <= data->maxLength)continue;
					inFeasible = true;
					nodeU = s->location[i].depots[j].next;
					while(!nodeU->isDepot){
						for (int posV = 0; posV<(int)data->nearCity[nodeU->cour].size(); posV++){
							if (data->nearCity[nodeU->cour][posV] < numV){
								nodeV = &s->client[data->nearCity[nodeU->cour][posV]];
								if (nodeV->covered_loc != NULL)continue;
								if (nodeV->route == nodeU->route)continue;
								setLocalVariableRouteU();
								setLocalVariableRouteV();
								//
								Relocate_one();
								Relocate_four();
								// Trying moves that insert nodeU directly after the depot
								if (nodeV->pre->isDepot){
									nodeV = nodeV->pre;
									setLocalVariableRouteV();
									Relocate_one();
								}
							}
							else{
								if (data->nearCity[nodeU->cour][posV] >= numV && s->location[data->nearCity[nodeU->cour][posV] - numV].used){
									nodeV = s->route[s->location[data->nearCity[nodeU->cour][posV] - numV].emptyRoutes[0]].depot;
									setLocalVariableRouteU();
									setLocalVariableRouteV();
									Relocate_one();
								}
							}
						}
						// adding a new route
						nodeV = s->route[nodeU->route->whichLocation->emptyRoutes[0]].depot;
						setLocalVariableRouteU();
						setLocalVariableRouteV();
						Relocate_one();
						nodeU = nodeU->next;
					}
				}
			}
		}
		if (min_delta == Max )
			return;
		updateTheMove();

		iteration++;
		if (iteration > loopID*numV){
			penaltyVeh = penaltyVeh*10;
			penaltyDepot = penaltyDepot*10;
			penaltyDis = penaltyDis *10;

			updateThePenalty(-1, NULL);
			loopID ++;
		}
	}
}
