/*
 * RepairProcedure.h
 *
 *  Created on: Aug 25, 2021
 *      Author: pengfei
 */

#ifndef REPAIRPROCEDURE_H_
#define REPAIRPROCEDURE_H_
#include "Individual.h"
#include "popManager.h"
class RepairProcedure {
public:
	RepairProcedure(read_data * data, popManager * popman);
	virtual ~RepairProcedure();
	void repairForInitialSolution(Individual *s);
	bool selectedLocationInventoryInfeasible();
	void repairLocation();
	void Relocate_one_depot();
	void Relocate_four_depot();

	//
	void repairCapacityConstraint(Individual *subPop,double penaltyDepot, double penaltyVeh);
	double penaltyLocationFunction(Node *p, int loc);
	double penaltyExcessLocation(int loc, int inventory);
	double penaltyExcessRoute(int load);
	double penaltyExcessDuration(double dis);
	bool updateThePenalty(int iden, Route *rou);
	//
	void setLocalVariableRouteU();
	void setLocalVariableRouteV();
	double compute(bool istrue, double value);
	void Relocate_one();//  0-1 insert
	void Relocate_four();
//	void Relocate_nine();
//	void Relocate_ten();
	void updateTheMove();
	void swapNode(Node *U, Node *V);
	void insertNode(Node *U, Node *V);
	//

	bool checkInfeasible();
	void loadInventory();
	void loadSolution();
	//
	void emptyEjectionList();
	bool ejection_move(int dem_locU_out, int dem_locV_out);
	void move_ejection_list();

private:
	int numV;
	int numL;
	int numC;
	read_data *data;
	Individual *s;
	int sizeSubPop;
	double penaltyDepot;
	double penaltyVeh;
	double penaltyDis;
	//
	int *checkCus;
	int **tabuTable;
	int iteration;
	Node *nodeU;
	Node *nodeX;
	Node *nodeUb, *nodeVb;
	Node *nodeV;
	Node *nodeY;
	Route *routeU;
	Route *routeV;
	NodeDepot *locU;
	NodeDepot *locV;
	int nodeUPrevIndex, nodeUIndex, nodeXIndex, nodeXNextIndex ;
	int nodeVPrevIndex, nodeVIndex, nodeYIndex, nodeYNextIndex ;
	int loadU, loadX, loadV, loadY;
	double min_delta, delta;
	int whichMove;
	//
	int tabu_length = 30;
	//
	std::vector<std::pair<Node*, NodeDepot*>>ejection_list;
	std::vector<std::pair<Node*, NodeDepot*>>ejection_list_best;
	std::vector<int>cumLoad;
	std::vector<int>overCap;


	popManager * popman;
};

#endif /* REPAIRPROCEDURE_H_ */



