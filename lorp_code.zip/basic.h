#ifndef BASIC_H_
#define BASIC_H_
#include <algorithm>
#include <vector>
#include <set>
#include <unordered_set>
#include <list>
#include <math.h>
#include <iostream>
#include <time.h>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
///////////////////////////////////////////////////////////////////////////////
#define Max 100000000
#define Min 1.0e-7
#define usingDepotConfiguration 0
#define usingMoveEjection true
#define usingMAB false
#define regular true
#endif /* BASIC_H_ */
