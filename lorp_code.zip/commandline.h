#ifndef COMMANDLINE_H_
#define COMMANDLINE_H_
#include "basic.h"
class CommandLine{
public:
	std::string pathInstance;
	std::string pathDepotCon;
	std::string pathSolution;
	int maxLength;
	int range;
	int timeLimit=Max;
	int iterLimit;
	int seed=0;
	double bestDis;
	double directServiceFactor=0.0;
	double routingFactor=1.0;
	int isOptimal;
	bool useCapacitatedDepot=false;
	bool useMoveEjection=usingMoveEjection;
	int numPromisingDepotConfigurations=5;
	int initialFilterParameter=10;
	int popMin=30;
	CommandLine(int argc, char* argv[]){
		if (argc < 10 || argc > 18){
			std::cout << "the input parameters in configuration are wrong" <<std::endl;
			std::cout << "Usage: lorp instance [depotConfig] solution maxLength range bestDis isOptimal timeLimit iterLimit seed [directFactor] [routingFactor] [capacitatedDepot] [useEjection] [gamma] [initialFilter] [popMin]" << std::endl;
			exit(0);
		}
		pathInstance=std::string(argv[1]);
		int offset = 0;
		if (argc >= 11 && !is_integer(argv[3])){
			pathDepotCon=std::string(argv[2]);
			pathSolution=std::string(argv[3]);
			offset = 1;
		}
		else{
			pathDepotCon = "NULL";
			pathSolution=std::string(argv[2]);
		}
		sscanf(argv[3 + offset],"%d",&maxLength);
		sscanf(argv[4 + offset],"%d",&range);
		sscanf(argv[5 + offset],"%lf",&bestDis);
		sscanf(argv[6 + offset],"%d",&isOptimal);
		sscanf(argv[7 + offset],"%d",&timeLimit);
		sscanf(argv[8 + offset],"%d",&iterLimit);
		sscanf(argv[9 + offset],"%d",&seed);
		if (argc > 10 + offset) sscanf(argv[10 + offset],"%lf",&directServiceFactor);
		if (argc > 11 + offset) sscanf(argv[11 + offset],"%lf",&routingFactor);
		if (argc > 12 + offset){
			int capFlag = 0;
			sscanf(argv[12 + offset],"%d",&capFlag);
			useCapacitatedDepot = (capFlag != 0);
		}
		if (argc > 13 + offset){
			int ejectionFlag = 1;
			sscanf(argv[13 + offset],"%d",&ejectionFlag);
			useMoveEjection = (ejectionFlag != 0);
		}
		if (argc > 14 + offset) sscanf(argv[14 + offset],"%d",&numPromisingDepotConfigurations);
		if (argc > 15 + offset) sscanf(argv[15 + offset],"%d",&initialFilterParameter);
		if (argc > 16 + offset) sscanf(argv[16 + offset],"%d",&popMin);
		display_infor();
	}
	void display_infor(){
		std::cout<<"Starting The Algorithm"<<std::endl;
		std::cout<<"The Instance is "<<pathInstance<<" && The maximum length is "<<maxLength<<" && The radius is: "<<range<<std::endl;
		std::cout<<"Direct service factor: "<<directServiceFactor<<" && Routing factor: "<<routingFactor
			<<" && Capacitated depots: "<<useCapacitatedDepot<<" && Ejection: "<<useMoveEjection
			<<" && Gamma: "<<numPromisingDepotConfigurations
			<<" && Initial filter: "<<initialFilterParameter<<" && PopMin: "<<popMin<<std::endl;
	}
private:
	bool is_integer(const char *value){
		if (value == NULL || *value == '\0') return false;
		int i = (value[0] == '-' || value[0] == '+') ? 1 : 0;
		if (value[i] == '\0') return false;
		for (; value[i] != '\0'; i++)
			if (value[i] < '0' || value[i] > '9') return false;
		return true;
	}
};
#endif
