#include"crossover.h"
crossover::crossover(read_data * data,  popManager * popman) {
	this->data=data;
	this->popman=popman;
	this->numV = data->numV;
	this->numL = data->numL;
	this->numC = data->numC;
	//
	weight_remove = new double [numberDestoryOperator];
	score_remove = new double [numberDestoryOperator];
	num_remove = new int [numberDestoryOperator];
	cum_prob_remove = new double [numberDestoryOperator];

	weight_repair_depot = new double [numberRepairDepotOperator];
	score_repair_depot = new double [numberRepairDepotOperator];
	num_repair_depot= new int [numberRepairDepotOperator];
	cum_prob_repair_depot = new double [numberRepairDepotOperator];

	weight_repair = new double [numberRepairOperator];
	score_repair =  new double [numberRepairOperator];
	num_repair = new int [numberRepairOperator];
	cum_prob_repair = new double [numberRepairOperator];

	update_weight();
}
crossover::~crossover() {
	delete [] weight_remove;
	delete [] score_remove;
	delete [] cum_prob_remove;
	delete [] num_remove ;

	delete [] weight_repair_depot;
	delete [] score_repair_depot ;
	delete [] num_repair_depot;
	delete [] cum_prob_repair_depot;

	delete [] weight_repair;
	delete [] score_repair;
	delete [] num_repair;
	delete [] cum_prob_repair;
}
void crossover::loadLocation(){
	numLocUsed.clear();
	for (int i=0;i<numL;i++)
		if(s->location[i].used)
			numLocUsed.push_back(i);
	listRemoveDepots.clear();// whatever remove which one, the two list should be empty
	listRemove.clear();
	random_shuffle(numLocUsed.begin(), numLocUsed.end());
}
void crossover::loadNodesVisitedRoutes(){
	nodess.clear();
	for (int i=0;i<numV;i++){
		if (s->client[i].covered_loc == NULL){
			nodess.push_back(i);
			s->client[i].isUsed = true;
		}
		else
			s->client[i].isUsed = false;
	}
}
void crossover::randomRemoveNodes(){
	int seed;
	//  loadLocation();// load all used depots
	if (nodess.empty()) return;
	random_shuffle(nodess.begin(), nodess.end());
	//  random_shuffle(numLocUsed.begin(), numLocUsed.end());
	double perturbLength = ceil(shock_length * (double)nodess.size());// determining the length of shock length
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		seed=rand()%(int)nodess.size();
		listRemove.push_back(nodess[seed]);
		nodess.erase(nodess.begin()+seed);
	}
	Node *p = NULL;
	Node *pre = NULL, *next = NULL;
	Route *route;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		route = p->route;
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
		p->route = NULL;
		s->updateRouteInfor(route->cour, -1);
	}
}
bool crossover::decideNecessaryDepots(int loc){
	for (int i=0;i<numV;i++){
		for (int j=0;j<(int)data->customerToLoc[i].size();j++){
			if (data->customerToLoc[i][j] == loc)
				continue;
			if (data->D[i][data->customerToLoc[i][j]] * 2 < data->maxLength && s->location[data->customerToLoc[i][j]-numV].used){
				return false;
			}
		}
	}
	return true;
}
void crossover::randomRemoveDepots(){
	int seed;
	listRemoveDepots.clear();
	if (numLocUsed.empty()) return;
	double perturbLength = ceil(shock_length * (double)numLocUsed.size());// determining the length of shock length
	if (perturbLength == 0)perturbLength = 1;
	int loop = 1;
	while((int)listRemoveDepots.size() < perturbLength && !numLocUsed.empty()){//select more 1/3 depots and select randomly
		seed=rand()%(int)numLocUsed.size();
		//
		if(decideNecessaryDepots(numLocUsed[seed] + numV)){
			loop++;
			listRemoveDepots.push_back(numLocUsed[seed]);
			s->location[numLocUsed[seed]].used = false;
			numLocUsed.erase(numLocUsed.begin()+seed);
		}
		else
			loop++;
		if (loop > 5* (int)numLocUsed.size())
			break;
	}
	Node *p = NULL;
	Node *pre = NULL, *next = NULL;
	for (int i=0;i<(int)listRemoveDepots.size();i++){
		pastSelectedLocation.push_back(listRemoveDepots[i]);
		NodeDepot *loc = &s->location[listRemoveDepots[i]];
		Node *p;
		for (int j=0;j<(int)loc->in_range.size();j++){
			listRemove.push_back(loc->in_range[j].second->cour);
		}
		loc->in_range.clear();
		for (int j=0;j<loc->maxVisit;j++){
			p = &loc->depots[j];
			p = p->next;
			while(!p->isDepot){
				listRemove.push_back(p->cour);
				p = p->next;
			}
			loc->depots[j].next = &loc->endDepots[j];
			loc->endDepots[j].pre = &loc->depots[j];
			s->updateRouteInfor(loc->depots[j].route->cour, 0);
		}
		s->updateLocationInfor(loc->cour);
	}
	Route *route;
	for (int i=0;i<(int)listRemove.size();i++){
		if (s->client[listRemove[i]].covered_loc != NULL){
			s->client[listRemove[i]].covered_loc = NULL;
			continue;
		}
		p = &s->client[listRemove[i]];
		route = p->route;
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
		s->updateRouteInfor(route->cour, -1);// update all customers in routes
	}
}
void crossover::ratioToCostRemoveDepot(){
	//
	std::vector<std::pair<double, int>>ratioCostDepot;
	for (int i=0;i<(int)numLocUsed.size();i++){
		double servedDemand = std::max(1, s->location[numLocUsed[i]].remainInven);
		ratioCostDepot.push_back(std::make_pair((s->location[numLocUsed[i]].costPerLoc / servedDemand),numLocUsed[i]));
	}
	if (ratioCostDepot.empty()) return;
	std::sort(ratioCostDepot.begin(),ratioCostDepot.end());
	/**********************************/
	double perturbLength = ceil(shock_length * (double)numLocUsed.size());// determining the length of shock length
	if (perturbLength == 0)
		perturbLength = 1;
	int loop = 1;
	while((int)listRemoveDepots.size() < perturbLength && !ratioCostDepot.empty()){//select more 1/3 depots and select randomly
		int iter = (int)ratioCostDepot.size();
		double y=double(rand()%10000/10000.0);
		int rank=int(pow(y,data->determine_para)*iter);
		if (rank >= iter) rank = iter - 1;

		if(decideNecessaryDepots(ratioCostDepot[rank].second + numV)){
			listRemoveDepots.push_back(ratioCostDepot[rank].second);
			ratioCostDepot.erase(ratioCostDepot.begin() + rank);
			loop++;
		}
		else loop++;
		if (loop > 5* (int)numLocUsed.size())
			break;
	}
	Node *p = NULL;
	Node *pre = NULL, *next = NULL;
	for (int i=0;i<(int)listRemoveDepots.size();i++){
		pastSelectedLocation.push_back(listRemoveDepots[i]);
		NodeDepot *loc = &s->location[listRemoveDepots[i]];
		Node *p;
		for (int j=0;j<(int)loc->in_range.size();j++){
			listRemove.push_back(loc->in_range[j].second->cour);
		}
		loc->in_range.clear();
		for (int j=0;j<loc->splitTime;j++){
			p = &loc->depots[j];
			p = p->next;
			while(!p->isDepot){
				listRemove.push_back(p->cour);
				p = p->next;
			}
			loc->depots[j].next = &loc->endDepots[j];
			loc->endDepots[j].pre = &loc->depots[j];
			s->updateRouteInfor(loc->depots[j].route->cour, 0);
		}
		s->updateLocationInfor(loc->cour);
	}
	Route *route;
	for (int i=0;i<(int)listRemove.size();i++){
		if (s->client[listRemove[i]].covered_loc != NULL){
			s->client[listRemove[i]].covered_loc = NULL;
			continue;
		}
		p = &s->client[listRemove[i]];
		route = p->route;
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
		s->updateRouteInfor(route->cour, -1);// update all customers in routes
	}
}
void crossover::shawRemoval(){
	// the first step is to select customers
	if (nodess.empty()) return;
	int seed;
	if (nodess.size() == 1)
		seed = nodess[0];
	else
		seed=nodess[rand()%(nodess.size()-1)+1];
	listRemove.push_back(seed); s->client[seed].isUsed = false;
	double perturbLength = ceil(shock_length * (double)nodess.size());// determining the length of shock length
	int iter;double y;int rank;
	std::vector<int>cityRank;
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		seed=rand()%(int)listRemove.size();
		iter=0;cityRank.clear();
		for (int i=0;i<numV;i++){
			if (data->nearCity[listRemove[seed]][i] < numV && s->client[data->nearCity[listRemove[seed]][i]].isUsed){
				cityRank.push_back(data->nearCity[listRemove[seed]][i]);
				iter++;
			}
		}
		y=double(rand()%10000/10000.0);
		if (iter == 0) break;
		rank=int(pow(y,data->determine_para)*iter);
		if (rank >= iter) rank = iter - 1;
		listRemove.push_back(cityRank[rank]);
		s->client[cityRank[rank]].isUsed = false;
	}
	//the second step is to remove customers
	Node *p = NULL;
	Node *pre = NULL, *next = NULL;
	Route *route;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		route = p->route;
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
		s->updateRouteInfor(route->cour, -1);
	}
}
void crossover::worstRemove(){
	double y;int rank; Node *p; double saving;
	listRemove.clear();
	std::vector<std::pair<double, Node*>>worst_seq;
	for (int i=0;i<numV;i++){
		if (s->client[i].covered_loc != NULL)continue;
		p = &s->client[i];
		saving = data->D[p->pre->cour][p->cour] + data->D[p->cour][p->next->cour] - data->D[p->pre->cour][p->next->cour];
		worst_seq.push_back(std::make_pair(- saving, p));
	}
	sort(worst_seq.begin(), worst_seq.end());
	double perturbLength = ceil(shock_length * (double)nodess.size());// determining the length of shock length
	while((int)listRemove.size() < perturbLength && !worst_seq.empty()){//select more 1/3 cities and select randomly
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para)*(int)worst_seq.size());
		if (rank >= (int)worst_seq.size()) rank = (int)worst_seq.size() - 1;
		listRemove.push_back(worst_seq[rank].second->cour);
		worst_seq.erase(worst_seq.begin() + rank);
	}
	//the second step is to remove customers
	Node *pre = NULL, *next = NULL;
	Route *route;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		route = p->route;
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
		s->updateRouteInfor(route->cour, -1);
	}
}
void crossover::crossRemove(){//propose a new destroy operator, to construct the solution
	// the first step is to identify cross point or other
	std::vector<std::pair<int, Node*>>nearby_seq;
	int count;double y;int rank;
	for (int i=0;i<numV;i++){
		if (s->client[i].route == NULL)continue;
		count = 0;
		for (int j=0; j<(int)data->edgeNode[i].size() / 2; j++){
			if (data->edgeNode[i][j] < numV && s->client[i].route != s->client[data->edgeNode[i][j]].route){
				count++;
			}
		}
		nearby_seq.push_back(std::make_pair(-count, &s->client[i]));
	}
	sort(nearby_seq.begin(), nearby_seq.end());
	double perturbLength = ceil(shock_length * (double)nodess.size());// determining the length of shock length
	while((int)listRemove.size() < perturbLength && !nearby_seq.empty()){//select more 1/3 cities and select randomly
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para)*(int)nearby_seq.size());
		if (rank >= (int)nearby_seq.size()) rank = (int)nearby_seq.size() - 1;
		listRemove.push_back(nearby_seq[rank].second->cour);
		nearby_seq.erase(nearby_seq.begin() + rank);
	}
	//the second step is to remove customers
	Node *pre = NULL, *next = NULL, *p;
	Route *route;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		route = p->route;
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
		s->updateRouteInfor(route->cour, -1);
	}
}
void crossover::updateLocation(){
	for (int i=0;i<numL;i++)
		if (s->location[i].used)
			s->updateLocationInfor(s->location[i].cour);
}
/*************************************************************************/
/*************************************************************************/
void crossover::strategyOneInsertDepot(){
	priorityDepots.clear();

	std::set<int>existCus;
	for (int i = 0; i < numL; i++) {
		if (s->location[i].used) {
			for (int j = 0; j < (int)data->covered_cus_depot[i].size(); j++) {
				existCus.insert(data->covered_cus_depot[i][j]);
			}
		}
	}
	//
	std::vector<std::pair<double, int>>listCandidateLoc;
	std::vector<std::pair<double, int>>localRatio1;
	while (existCus.size() != numV){
		listCandidateLoc.clear();
		localRatio1.clear();
		for (int i=0;i<numL;i++){
			if (!s->location[i].used){
				std::set<int>existCus1 = existCus;
				for (int j=0;j<(int)data->covered_cus_depot[i].size();j++){
					existCus1.insert(data->covered_cus_depot[i][j]);
				}
				double coveredDenom = std::max(1, (int)existCus.size());
				listCandidateLoc.push_back({-((double)(existCus1.size()-existCus.size())/(double)coveredDenom),i});// the first value (negative) should be as big as possible
				localRatio1.push_back({data->locRatio[i].first, i});// the first value should be as small as possible
			}
		}
		if (listCandidateLoc.empty()) break;
		std::sort(listCandidateLoc.begin(),listCandidateLoc.end());// the average covered ratio
		std::sort(localRatio1.begin(),localRatio1.end());// the rouge cost
		//decide the rank, each index is weighted with 1/2
		std::vector<std::pair<double, int>>weight_rank;
		for (int i=0;i<(int)listCandidateLoc.size();i++){
			int loc = listCandidateLoc[i].second;
			int rank2 = -1;
			for (int j=0;j<(int)localRatio1.size();j++){
				if (localRatio1[j].second == loc){
					rank2 = j;
					break;
				}
			}
			if (rank2 == -1)std::cout<<"There is an error when generating weighted rank of each candidate location"<<std::endl;
			double weightRank = (i+1)*0.5 + (rank2+1)*0.5;
			weight_rank.push_back({weightRank,loc});
		}
		std::sort(weight_rank.begin(), weight_rank.end());
		//select depot from weight_rank;
		double y=double(rand()%10000/10000.0);
		int rank=int(pow(y,data->determine_para)*(int)weight_rank.size());
		if (rank >= (int)weight_rank.size()) rank = (int)weight_rank.size() - 1;
		int tarLoc = weight_rank[rank].second;
		// update locations' information
		s->location[tarLoc].used = true;
		priorityDepots.push_back(tarLoc);
		capUsedLoc += s->location[tarLoc].inventory;
		for (int i=0;i<(int)data->covered_cus_depot[tarLoc].size();i++){
			existCus.insert(data->covered_cus_depot[tarLoc][i]);
		}
	}
	// insert all customers in range.
	Node *pp;
	NodeDepot *loc;
	for (int i=0;i<(int)priorityDepots.size();i++)
		s->location[priorityDepots[i]].used = true;
	//
	for (int j=(int)listRemove.size()-1;j>=0;j--){// inserted customers into depots as fair as possible.
		pp = &s->client[listRemove[j]];
		if (pp->covered_loc != NULL) continue;// the node is not covered by other location
		if (pp->pre != NULL) continue;// the node is not visited by routes
		for (int k=0;k<(int)data->includedDeopt[pp->cour].size();k++){
			loc = &s->location[data->includedDeopt[pp->cour][k] - numV];
			if (loc->used && loc->remainInven + pp->dem <= loc->inventory){// the capacity constraint
				loc->in_range.push_back({data->D[pp->cour][loc->cour], pp});
				loc->remainInven += pp->dem;
				s->updateLocationInfor(loc->cour);// update the information
				s->updateCoveredInfor(loc->cour);
				listRemove.erase(listRemove.begin()+j);
				break;
			}
		}
	}
}
void crossover::strategyTwoInsertDepot(){
	std::set<int>existCus;
	for (int i = 0; i < numL; i++) {
		if (s->location[i].used) {
			for (int j = 0; j < (int)data->covered_cus_depot[i].size(); j++)
				existCus.insert(data->covered_cus_depot[i][j]);
		}
	}
//	s->outputSolution();
	int capUsedLoc = 0;
	for (int i=0;i<numL;i++)
		if (s->location[i].used)
			capUsedLoc += s->location[i].inventory;
	/*******************/
	priorityDepots.clear();
	//
	std::vector<int>canDepot;
	for (int i = 0; i < numL; i++) {
		if (!s->location[i].used) {
			canDepot.push_back(i);
		}
	}
	//
	random_shuffle(canDepot.begin(), canDepot.end());
	while(existCus.size() != numV && !canDepot.empty()){
		priorityDepots.push_back(canDepot[0]);
		for (int i = 0; i < (int)data->covered_cus_depot[canDepot[0]].size(); i++) {
			existCus.insert(data->covered_cus_depot[canDepot[0]][i]);
		}
		canDepot.erase(canDepot.begin());
	}
	//
	// insert all customers in range.
	Node *pp;
	NodeDepot *loc;
	for (int i=0;i<(int)priorityDepots.size();i++)
		s->location[priorityDepots[i]].used = true;
	//
	for (int j=(int)listRemove.size()-1;j>=0;j--){// inserted customers into depots as fair as possible.
		pp = &s->client[listRemove[j]];
		if (pp->covered_loc != NULL) continue;// the node is not covered by other location
		if (pp->pre != NULL) continue;// the node is not visited by routes
		for (int k=0;k<(int)data->includedDeopt[pp->cour].size();k++){
			loc = &s->location[data->includedDeopt[pp->cour][k] - numV];
			if (loc->used && loc->remainInven + pp->dem <= loc->inventory){// the capacity constraint
				loc->in_range.push_back({data->D[pp->cour][loc->cour], pp});
				loc->remainInven += pp->dem;
				s->updateLocationInfor(loc->cour);// update the information
				s->updateCoveredInfor(loc->cour);
				listRemove.erase(listRemove.begin()+j);
				break;
			}
		}
	}
}
/*************************************************************************/
/*************************************************************************/
void crossover::insertNode(Node *U, Node *V){
	Node *V_next = V->next;
	V->next = U;
	U->pre = V;
	U->next = V_next;
	V_next->pre = U;
	U->route = V->route;
	U->isUsed = true;
}
Node * crossover::decisionInsertAfterDepot(Node *node, int loc, double & delta){
	double deltaa, min_delta = Max;
	Node *nodeU = NULL;
	for (int j=0;j<s->location[loc].splitTime + 1 && j < s->location[loc].maxVisit; j++){
		if (s->location[loc].depots[j].route->used){
			deltaa = data->D[loc+numV][node->cour] + data->D[node->cour][s->location[loc].depots[j].next->cour] - data->D[loc+numV][s->location[loc].depots[j].next->cour];
			if (s->location[loc].depots[j].route->load + node->dem >data->vehCap) deltaa = Max;
			if (deltaa + s->location[loc].depots[j].route->dis > data->maxLength) deltaa = Max;
		}
		else if (s->location[loc].used)
			deltaa = data->D[loc+numV][node->cour] * 2 + data->usingCostVeh;// the fixed cost of each vehicle
		else{
			deltaa = data->D[loc+numV][node->cour] * 2 + data->usingCostVeh + data->openCostLoc[loc+numV];//
		}
		if (min_delta > deltaa){
			nodeU = &s->location[loc].depots[j];
			min_delta = deltaa;
		}
		if (j == s->location[loc].splitTime)break;
		if (!s->location[loc].used)
			break;
	}
	delta = min_delta;
	return nodeU;
}
void crossover::greedyInsert(){//
	random_shuffle(listRemove.begin(), listRemove.end());// randomize all removed customers
	double delta, min_delta;
	Node *node, *nodeU, *pos;
	while ((int)listRemove.size() != 0){
	  min_delta = Max; //listRemove // insert the minimum route firstly
	  pos = NULL;
	  node = &s->client[listRemove[0]];
	  // the first step to check whether the node can be covered by new locations
	  for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
		  if (data->edgeNode[node->cour][i] >= numV){
			  if (data->D[s->location[data->edgeNode[node->cour][i] - numV].cour][node->cour] * 2 <= data->maxLength
				  && s->location[data->edgeNode[node->cour][i] - numV].remainInven + node->dem <= s->location[data->edgeNode[node->cour][i] - numV].inventory){
				  nodeU = decisionInsertAfterDepot(node, data->edgeNode[node->cour][i] - numV, delta);
				  if (delta < min_delta){
					  pos = nodeU;
					  min_delta = delta;
				  }
			  }
			  continue;
		  }
		  //&& s->client[data->edgeNode[node->cour][i]].covered_loc == NULL
		  if (s->client[data->edgeNode[node->cour][i]].isUsed){// visited by routes
			  nodeU = &s->client[data->edgeNode[node->cour][i]];
			  delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
			  if (nodeU->route->dis + delta > data->maxLength || nodeU->route->load + node->dem > data->vehCap || nodeU->route->whichLocation->remainInven + node->dem > nodeU->route->whichLocation->inventory)
				  continue;
			  if (delta < min_delta){
				  pos = nodeU;
				  min_delta = delta;
			  }
		  }
	  }
	  // remedy strategy
	  if (min_delta == Max){
		  for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
			  if (data->nearCity[node->cour][i] >= numV ){
				  if (s->location[data->nearCity[node->cour][i] - numV].used){
					  if (data->D[s->location[data->nearCity[node->cour][i] - numV].cour][node->cour] * 2 <= data->maxLength
						  && s->location[data->nearCity[node->cour][i] - numV].remainInven + node->dem <= s->location[data->nearCity[node->cour][i] - numV].inventory){
						  nodeU = decisionInsertAfterDepot(node, data->nearCity[node->cour][i] - numV, delta);
						  if (delta < min_delta){
							  pos = nodeU;
							  min_delta = delta;
						  }
					  }
				  }
				  continue;
			  }
			  else if ( s->client[data->nearCity[node->cour][i]].isUsed){
				  nodeU = &s->client[data->nearCity[node->cour][i]];
				  delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				  if (nodeU->route->load +node->dem > data->vehCap || nodeU->route->whichLocation->remainInven + node->dem > nodeU->route->whichLocation->inventory)continue;
				  if (nodeU->route->dis + delta > data->maxLength)continue;
				  if (delta < min_delta){
					  pos = nodeU;
					  min_delta = delta;
				  }
			  }
		  }
	  }
	  if (min_delta == Max){
		  for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
			  if (data->nearCity[node->cour][i] >= numV)continue;
			  nodeU = &s->client[data->nearCity[node->cour][i]];
			  if (nodeU->covered_loc != NULL || !nodeU->isUsed)continue;
			  //
			  delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
			  //if (nodeU->route->load +node->dem > data->vehCap)continue;
			  //if (nodeU->route->dis + delta > data->maxLength)continue;
			  pos = nodeU;
			  break;
		  }
	  }
	  if (pos == NULL) {
		  std::cout << "The greedy insert operator is wrong" << std::endl;
		  return;
	  }
	  insertNode(node,pos);
	  listRemove.erase(listRemove.begin());
	  s->updateRouteInfor(pos->route->cour,-1);
	  s->updateLocationInfor(pos->route->whichLocation->cour);
   }
}
void crossover::greedyInsertBlink(){// for the shortest route
	random_shuffle(listRemove.begin(), listRemove.end());// randomize all removed customers
	double delta, min_delta;
	Node *node, *nodeU, *pos;
	while ((int)listRemove.size() != 0){
		min_delta = Max; //listRemove
		pos = NULL;
		node = &s->client[listRemove[0]];
		for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
			if (data->edgeNode[node->cour][i] >= numV){
				if (data->D[s->location[data->edgeNode[node->cour][i] - numV].cour][node->cour] * 2 <= data->maxLength
					&& s->location[data->edgeNode[node->cour][i] - numV].remainInven + node->dem <= s->location[data->edgeNode[node->cour][i] - numV].inventory){
					nodeU = decisionInsertAfterDepot(node, data->edgeNode[node->cour][i] - numV, delta);
					if(rand()%10000/10000.0<(1 - gama_accept_prob_greedy_heuristic)){
						if (delta < min_delta){
							pos = nodeU;
							min_delta = delta;
						}
					}
				}
				continue;
			}
			if (s->client[data->edgeNode[node->cour][i]].isUsed && s->client[data->edgeNode[node->cour][i]].covered_loc == NULL){
				nodeU = &s->client[data->edgeNode[node->cour][i]];
				if (nodeU->route->load + node->dem > data->vehCap || nodeU->route->whichLocation->remainInven + node->dem > nodeU->route->whichLocation->inventory)
					continue;
				delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				if (nodeU->route->dis + delta > data->maxLength)continue;//违反距离约束条件
				//
				if(rand()%10000/10000.0<(1 - gama_accept_prob_greedy_heuristic)){
					if (delta < min_delta){
						pos = nodeU;
						min_delta = delta;
					}
				}
			}
		}
		// remedy strategy
		if (min_delta == Max){
			for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
				if (data->nearCity[node->cour][i] >= numV){
					if ( s->location[data->nearCity[node->cour][i] - numV].used){
						if (data->D[s->location[data->nearCity[node->cour][i] - numV].cour][node->cour] * 2 <= data->maxLength
							&& s->location[data->nearCity[node->cour][i] - numV].remainInven + node->dem <= s->location[data->nearCity[node->cour][i] - numV].inventory){
							nodeU = decisionInsertAfterDepot(node, data->nearCity[node->cour][i] - numV, delta);
							if (delta < min_delta){
								pos = nodeU;
								min_delta = delta;
							}
						}
					}
					continue;
				}
				if (s->client[data->nearCity[node->cour][i]].isUsed && s->client[data->nearCity[node->cour][i]].covered_loc == NULL){
					nodeU = &s->client[data->nearCity[node->cour][i]];
					if (nodeU->route->load + node->dem > data->vehCap || nodeU->route->whichLocation->remainInven + node->dem > nodeU->route->whichLocation->inventory)
						continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (nodeU->route->dis + delta > data->maxLength)continue;//违反距离约束条件
					if(rand()%10000/10000.0<(1 - gama_accept_prob_greedy_heuristic)){
						if (delta < min_delta){
							pos = nodeU;
							min_delta = delta;
						}
					}
				}
			}
		}
		if (pos == NULL) {
		//	std::cout << "The greedy blink insert operator is wrong" << std::endl;
			return;
		}
		insertNode(node,pos);
		s->updateRouteInfor(pos->route->cour,-1);
		s->updateLocationInfor(pos->route->whichLocation->cour);
		listRemove.erase(listRemove.begin());
	}
}
void crossover::regretInsert(){
	random_shuffle(listRemove.begin(), listRemove.end());// randomize all removed customers
	std::set<std::pair<double, Node *>>regret_values;
	double delta;
	Node *node, *nodeU, *pos;
	while ((int)listRemove.size() != 0){
		regret_values.clear();
		/*****************************************************************/
		pos = NULL;
		node = &s->client[listRemove[0]];
		for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
			if (data->edgeNode[node->cour][i] >= numV){
				if (!s->location[data->edgeNode[node->cour][i] - numV].used)continue;
				if (data->D[s->location[data->edgeNode[node->cour][i] - numV].cour][node->cour] * 2 <= data->maxLength
					&& s->location[data->edgeNode[node->cour][i] - numV].remainInven + node->dem <= s->location[data->edgeNode[node->cour][i] - numV].inventory){
					nodeU = decisionInsertAfterDepot(node, data->edgeNode[node->cour][i] - numV, delta);
					regret_values.insert({delta, nodeU});
				}
				continue;
			}
			if (s->client[data->edgeNode[node->cour][i]].isUsed){
				nodeU = &s->client[data->edgeNode[node->cour][i]];
				if (nodeU->route->load + node->dem > data->vehCap || nodeU->route->whichLocation->remainInven + node->dem > nodeU->route->whichLocation->inventory)continue;
				delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				if (nodeU->route->dis + delta > data->maxLength)continue;
				regret_values.insert({delta, nodeU});
			}
		}
		// remedy strategy
		if (regret_values.empty()){
			for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
				if (data->nearCity[node->cour][i] >= numV && s->location[data->nearCity[node->cour][i] - numV].used){
					if (data->D[s->location[data->nearCity[node->cour][i] - numV].cour][node->cour] * 2 <= data->maxLength
						&& s->location[data->nearCity[node->cour][i] - numV].remainInven + node->dem <= s->location[data->nearCity[node->cour][i] - numV].inventory){
						nodeU = decisionInsertAfterDepot(node, data->nearCity[node->cour][i] - numV, delta);
						regret_values.insert({delta, nodeU});
					}
					continue;
				}
				else if (data->nearCity[node->cour][i] < numV && s->client[data->nearCity[node->cour][i]].isUsed){
					nodeU = &s->client[data->nearCity[node->cour][i]];
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (nodeU->route->load +node->dem > data->vehCap || nodeU->route->whichLocation->remainInven + node->dem > nodeU->route->whichLocation->inventory)continue;
					if (nodeU->route->dis + delta > data->maxLength)continue;
					regret_values.insert({delta, nodeU});
				}
			}
		}
		if (regret_values.size() == 0) {
		//	std::cout << "The regret insert operator is wrong" << std::endl;
			return;
		}
		if (pos == NULL){
			auto it = regret_values.begin();
			if (regret_values.size() == 1)
				pos = it->second;
			else{
				it++;
				pos = it->second;
			}
		}
		insertNode(node,pos);
		s->updateRouteInfor(pos->route->cour,-1);
		s->updateLocationInfor(pos->route->whichLocation->cour);
		listRemove.erase(listRemove.begin());
		if (data->iteration == 28)
			s->outputSolution();
	}
}
void crossover::selectAndApplyDestoryOperator(){
	pastSelectedLocation.clear();
	loadNodesVisitedRoutes();//load all nodes visited by routes
	int which_operator = numberDestoryOperator - 1;
	if (regular){
		double prob=rand()%10000/10000.0;
		for (int i=0;i<numberDestoryOperator;i++){
			if (i==0 && prob<=cum_prob_remove[0]){
				which_operator=0;
				break;
			}
			if (i > 0 && prob>cum_prob_remove[i-1] && prob<=cum_prob_remove[i]){
				which_operator=i;
				break;
			}
		}
	}
	if (nodess.size() <= 1){
		if (rand()%2 == 0)
			which_operator = 2;
		else
			which_operator = 3;
	}
	if (random_destory){
		which_operator = rand() % (numberDestoryOperator);
	}
	switch (which_operator){
    	case 0:{
    		shawRemoval();
    		current_remove=0;
    		num_remove[0]++;
    		break;
    	}
    	case 1:{
    		randomRemoveNodes();
    		current_remove=1;
    		num_remove[1]++;
    		break;
    	}
    	case 2:{
    		randomRemoveDepots();
    		current_remove=2;
    		num_remove[2]++;
    		break;
    	}
    	case 3:{
    		current_remove=3;
    		ratioToCostRemoveDepot();
    		num_remove[3]++;
    		break;
    	}
    	case 4:{
    		worstRemove();
    		current_remove=4;
    		num_remove[4]++;
    		break;
    	}
    	case 5:{
    		crossRemove();
    		current_remove=5;
    		num_remove[5]++;
    		break;
    	}
	}
}
void crossover::insertCoveredCusToLocation(){
	Node *p;NodeDepot *loc;
	for (int i=(int)listRemove.size()-1; i>=0 ;i--){
		p = &s->client[listRemove[i]];
		for (int k=0;k<(int)data->includedDeopt[p->cour].size();k++){
			loc = &s->location[data->includedDeopt[p->cour][k] - numV];
			if (loc->used && loc->remainInven + p->dem <= loc->inventory){
				loc->in_range.push_back({data->D[p->cour][loc->cour], p});
				p->covered_loc = loc;
				loc->remainInven += p->dem;
				s->updateLocationInfor(loc->cour);// update the information
				s->updateCoveredInfor(loc->cour);
				listRemove.erase(listRemove.begin()+i);
				break;
			}
		}
	}
}
void crossover::selectAndApplyRepairOperatorDepot(){
	capUsedLoc = 0;
	for (int i=0;i<numL;i++)
		if (s->location[i].used)
			capUsedLoc += s->location[i].inventory;
	bool isNeedRepairDepotCapacity = false;
	if (capUsedLoc > data->totalDemand) {
		current_repair_depot = -1;
		isNeedRepairDepotCapacity = false;
	}
	else isNeedRepairDepotCapacity = true;
	//
	bool isNeedRepairDepot = true;
	for (int j = 0; j < (int)listRemove.size(); j++) {
		isNeedRepairDepot = true;
		for (int i = 0; i < numL; i++) {
			if (s->location[i].used) {
				if (data->D[i + numV][listRemove[j]] * 2 < data->maxLength) {
					isNeedRepairDepot = false; break;
				}
			}
		}
		if (isNeedRepairDepot)break;//意味着有一个顾客没有被覆盖
	}
	if (!isNeedRepairDepot && !isNeedRepairDepotCapacity)return;//不需要修复depot
	//
	int which_operator = numberRepairDepotOperator - 1;
	if (regular){
		double prob=rand()%10000/10000.0;
		for (int i=0;i<numberRepairDepotOperator;i++){
			if (i==0 &&prob<=cum_prob_repair_depot[0]){
				which_operator=0;
				break;
			}
			if (i > 0 && prob>cum_prob_repair_depot[i-1] && prob<=cum_prob_repair_depot[i]){
				which_operator=i;
				break;
			}
		}
	}
	if (random_destory){
		which_operator = rand() % (numberRepairDepotOperator);
	}
	switch (which_operator){
    	case 0:{
    		strategyOneInsertDepot();
    		current_repair_depot = 0;
    		num_repair_depot[0]++;
    		break;
    	}
    	case 1:{
    		strategyTwoInsertDepot();
    		current_repair_depot = 1;
    		num_repair_depot[1]++;
    		break;
    	}
	}
}
void crossover::selectAndApplyRepairOperator(){
	int which_operator = numberRepairOperator - 1;
	if (regular){
		double prob=rand()%10000/10000.0;
		for (int i=0;i<numberRepairOperator;i++){
			if (i==0 && prob<=cum_prob_repair[0]){
				which_operator=0;
				break;
			}
			if (i > 0 && prob>cum_prob_repair[i-1] && prob<=cum_prob_repair[i]){
				which_operator=i;
				break;
			}
		}
	}
	if (random_destory){
		which_operator = rand() % (numberRepairOperator);
	}
	switch (which_operator){
    	case 0:{
    		greedyInsert();
    		current_repair=0;
    		num_repair[0]++;
    		break;
    	}
    	case 1:{
    		greedyInsertBlink();
    		current_repair=1;
    		num_repair[1]++;
    		break;
    	}
    	case 2:{
    		regretInsert();
    		current_repair=2;
    		num_repair[2]++;
    		break;
    	}
	}
	//
	if (listRemove.size() > 0) {//存在约束条件导致存在customers无法插入到当前解中。
		Node *node, *nodeU, *pos =NULL;
		while (listRemove.size() > 0){
			 node = &s->client[listRemove[0]];
			for (int i = 0; i < (int)data->nearCity[node->cour].size(); i++) {
				if (data->nearCity[node->cour][i] >= numV)continue;
				nodeU = &s->client[data->nearCity[node->cour][i]];
				if (nodeU->covered_loc != NULL || !nodeU->isUsed)continue;
				//
				double delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				pos = nodeU;
				break;
			}
			insertNode(node, pos);
			s->updateRouteInfor(pos->route->cour, -1);
			s->updateLocationInfor(pos->route->whichLocation->cour);
			listRemove.erase(listRemove.begin());
		}
	}
}
void crossover::updateScore(double updateScore){
	if (s->fit + Min < global->fit){
		score_remove[current_remove] += delta_global_best;
		if (current_repair_depot > -1)
			score_repair_depot[current_repair_depot] += delta_global_best;
		score_repair[current_repair] += delta_global_best;
		return;
	}
	if (s->fit + Min < updateScore){
		score_remove[current_remove] += delta_improve;
		if (current_repair_depot > -1)
			score_repair_depot[current_repair_depot] += delta_improve;
		score_repair[current_repair] += delta_improve;
		return;
	}
	if (s->fit + Min > updateScore){
		score_remove[current_remove] += delta_accept;
		if (current_repair_depot > -1)
			score_repair_depot[current_repair_depot] += delta_accept;
		score_repair[current_repair] += delta_accept;
		return;
	}
}
void crossover::update_weight(){
	double sum = 0;
	if (segment==0){
		segment++;
		for (int i=0;i<numberDestoryOperator;i++){weight_remove[i]=1;num_remove[i]=0; score_remove[i]=0;}
		for (int i=0;i<numberRepairDepotOperator;i++){weight_repair_depot[i]=1;num_repair_depot[i]=0; score_repair_depot[i]=0;}
		for (int i=0;i<numberRepairOperator;i++){weight_repair[i]=1;num_repair[i]=0; score_repair[i]=0;}
		//calculate the inital temperature
//		double xx = std::log(p_accept);
//		Initial_temperature=-wwww*initial_solution_fit/xx;
	//	last_temperature=1;
//		double cccc=1.0/(data->re_start * data->episod);
//		data->cool_rate=pow((last_temperature/Initial_temperature),cccc);
		for (int i=0;i<numberDestoryOperator;i++)
			sum += weight_remove[i];
		for (int i=0;i<numberDestoryOperator;i++){
			if (i==0)cum_prob_remove[i] = weight_remove[i]/sum;
			else cum_prob_remove[i]=cum_prob_remove[i-1]+weight_remove[i]/sum;
		}
		sum = 0;
		for (int i=0;i<numberRepairDepotOperator;i++)
			sum += weight_repair_depot[i];
		for (int i=0;i<numberRepairDepotOperator;i++){
			if (i==0)cum_prob_repair_depot[i]=weight_repair_depot[i]/sum;
			else cum_prob_repair_depot[i]=cum_prob_repair_depot[i-1]+weight_repair_depot[i]/sum;
		}
		//
		sum=0;
		for (int i=0;i<numberRepairOperator;i++)
			sum += weight_repair[i];
		for (int i=0;i<numberRepairOperator;i++){
			if (i==0)cum_prob_repair[i]=weight_repair[i]/sum;
			else cum_prob_repair[i] = cum_prob_repair[i-1] + weight_repair[i]/sum;
		}
	}
	else{
		segment++;
		for (int i=0;i<numberDestoryOperator;i++){
			if (num_remove[i]!=0)
				weight_remove[i]=weight_remove[i]*(1-gamama)+gamama*(score_remove[i]/double(num_remove[i]));
			num_remove[i]=0;
			score_remove[i]=0;
		}
		sum=0;
		for (int i=0;i<numberDestoryOperator;i++)sum+=weight_remove[i];
		for (int i=0;i<numberDestoryOperator;i++){
			if (i==0)cum_prob_remove[i]=weight_remove[i]/sum;
			else cum_prob_remove[i]=cum_prob_remove[i-1]+weight_remove[i]/sum;
		}
		//
		for (int i=0;i<numberRepairDepotOperator;i++){
			if (num_repair_depot[i]!=0)
				weight_repair_depot[i]=weight_repair_depot[i]*(1-gamama)+gamama*(score_repair_depot[i]/double(num_repair_depot[i]));
			score_repair_depot[i]=0;
			num_repair_depot[i]=0;
		}
		sum = 0;
		for (int i=0;i<numberRepairDepotOperator;i++)sum+=weight_repair_depot[i];
		for (int i=0;i<numberRepairDepotOperator;i++){
			if (i==0)cum_prob_repair_depot[i]=weight_repair_depot[i]/sum;
			else cum_prob_repair_depot[i]=cum_prob_repair_depot[i-1]+weight_repair_depot[i]/sum;
		}
		//
		for (int i=0;i<numberRepairOperator;i++){
			if (num_repair[i]!=0)
				weight_repair[i]=weight_repair[i]*(1-gamama)+gamama*(score_repair[i]/double(num_repair[i]));
			score_repair[i]=0;
			num_repair[i]=0;
		}
		sum=0;
		for (int i=0;i<numberRepairOperator;i++)sum+=weight_repair[i];
		for (int i=0;i<numberRepairOperator;i++){
			if (i==0)cum_prob_repair[i]=weight_repair[i]/sum;
			else cum_prob_repair[i]=cum_prob_repair[i-1]+weight_repair[i]/sum;
		}
	}
}
bool crossover::shock_procedure(Individual *off){
	this->s = off;
	double locBest = s->fit;
	off->isRight();
	loadLocation();
	if (data->iteration == -1)
		off->outputSolution();
	selectAndApplyDestoryOperator();
	//
	updateLocation();
	if (data->iteration == -1)
		off->outputSolution();
	selectAndApplyRepairOperatorDepot();
	if (data->iteration == -1)
		off->outputSolution();
	insertCoveredCusToLocation();// aims to insert customers into covered location as many as possible
	if (data->iteration == -1)
		off->outputSolution();
	selectAndApplyRepairOperator();
	//
	if (data->iteration == -1)
		off->outputSolution();
	repair->repairForInitialSolution(off);
	off->evaluationDis();
	if (data->iteration == -1)
		off->outputSolution();
	off->isRight();
	updateScore(locBest);
	if (data->iteration % data->episod == 0)
		update_weight();
	return true;
}
