#ifndef CROSSOVER_H_
#define CROSSOVER_H_
#include "Individual.h"
#include "read_data.h"
#include "popManager.h"
#include "RepairProcedure.h"
class crossover {
public:
	crossover(read_data * data,  popManager * popman);
	virtual ~crossover();
	bool shock_procedure(Individual *sol);
	void loadLocation();
	popManager * popman;
	RepairProcedure *repair;
	int segment = 0;
	Individual *global;
private:
	read_data *data;
	int numL;
	int numV;
	int numC;
	Individual *s;
	//parameters
	double shock_length = 0.2;// ceiling to integer
	double gama_accept_prob_greedy_heuristic = 0.01;
	std::vector<int>numLocUsed;
	bool isDeoptMove;
	std::vector<int>nodess;// visited by routes
	std::vector<int>listRemove;// save the nodes which should be removed
	std::vector<int>listRemoveDepots;// save the depots which are selected to be removed
	std::vector<int> priorityDepots;//

	std::vector<int> pastSelectedLocation;

	//
	int current_remove;
	int current_repair_depot;
	int current_repair;
	int numberDestoryOperator = 6;
	int numberRepairDepotOperator = 2;
	int numberRepairOperator = 3;
	/**/
	double* weight_remove;
	double* score_remove;
	int* num_remove;
	double* cum_prob_remove;
	//
	double* weight_repair_depot;
	double* score_repair_depot;
	int* num_repair_depot;
	double* cum_prob_repair_depot;

	double* weight_repair;
	double* score_repair;
	int* num_repair;
	double* cum_prob_repair;

	///////////////////
	double gamama = 0.1;
	bool random_destory = false;
	int capUsedLoc;

	/*********************/
	double delta_global_best = 10;
	double delta_improve = 5;
	double delta_accept = 3;
	//methods for destroy and repair solutions
	void selectAndApplyRepairOperator();
	void selectAndApplyRepairOperatorDepot();
	void selectAndApplyDestoryOperator();

	void loadNodesVisitedRoutes();
	//
	void randomRemoveNodes();
	void randomRemoveDepots();
	void ratioToCostRemoveDepot();
	void shawRemoval();
	void worstRemove();
	void crossRemove();
	void updateLocation();
	/**************************/
	void strategyOneInsertDepot();
	void strategyTwoInsertDepot();
//	void insertDepot();//the first method is to determine whether need to insert depots into current solution
	void insertCoveredCusToLocation();
	bool decideNecessaryDepots(int loc);
	/**************************/
	Node* decisionInsertAfterDepot(Node *node, int loc, double &delta);
	void greedyInsert();
	void insertNode(Node *U, Node *V);
	void greedyInsertBlink();
	void regretInsert();
	//
	void update_weight();
	void updateScore(double updateScore);
};

#endif /* CROSSOVER_H_ */

