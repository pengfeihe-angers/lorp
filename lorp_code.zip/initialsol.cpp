#include "basic.h"
#include "initialsol.h"
initial_sol::initial_sol(read_data * data, RepairProcedure *repair){
	this->repair = repair;
	this->data=data;
	this->numV = data->numV;
	this->numL = data->numL;
	this->numC = data->numC;
	customer=new int [numV];
	for (int i=0;i<numV;i++)
		sque.push_back(i);
	locUsed = new bool [numC];
	cusUsed = new bool [numV];
}
initial_sol::~initial_sol() {
	delete [] customer;
	delete [] locUsed;
	delete [] cusUsed;
}
void initial_sol::insertClient(Node *U, Node *V){
	if (!V->route->used){// insert into a empty route;
		V->pre->pre = U;// to locate the endDepot
		V->next = U;
		U->pre = V;
		U->next = V->pre;
	}
	else{
		V->next->pre = U;
		U->pre = V;
		U->next = V->next;
		V->next = U;
	}
	U->route = V->route;
	U->isUsed = true;
	remainDem = remainDem - U->dem;
}
bool initial_sol::select_depots(){
	remainDem = data->totalDemand;
	for (int i=numV; i<numC;i++) locUsed[i] = false;
	int tarLoc = -1;
	// selecting locations
	selected_loc.clear();
	std::vector<int>listLoc1;
	int currentDem = 0;
	std::set<int>existCus;
	for (int i=0;i<numL;i++)
		if (!locUsed[data->locRatio[i].second])
			listLoc1.push_back(data->locRatio[i].second);
	//
	double y = double(double(rand()%10000)/10000.0);
	int rank = int(pow(y,data->determine_para)*(int)listLoc1.size());
	if (rank >= (int)listLoc1.size()) rank = (int)listLoc1.size() - 1;
	tarLoc = listLoc1[rank];
	locUsed[tarLoc] = true;
	selected_loc.push_back(tarLoc);
	currentDem += s->location[tarLoc - numV].inventory;
	for (int i=0;i<(int)data->covered_spanning_cus[tarLoc-numV].size();i++){
		existCus.insert(data->covered_spanning_cus[tarLoc-numV][i]);
	}
	std::vector<std::pair<double, int>>listCandidateLoc;
	std::vector<std::pair<double, int>>localRatio1;
	std::set<int>covered_cus;
	while(1){
		if (data->stopCondition(Max)) return false;
		listCandidateLoc.clear();
		localRatio1.clear();
		for (int i=numV;i<numC;i++){
			if (!locUsed[i]){
				std::set<int>existCus1 = existCus;
				for (int j=0;j<(int)data->covered_spanning_cus[i-numV].size();j++){
					existCus1.insert(data->covered_spanning_cus[i-numV][j]);
				}
				double coveredDenom = std::max(1, (int)existCus.size());
				listCandidateLoc.push_back({-((double)(existCus1.size()-existCus.size())/(double)coveredDenom),i});// the first value (negative) should be as big as possible
				localRatio1.push_back({data->locRatio[i-numV].first, i});// the first value should be as small as possible
			}
		}
		std::sort(listCandidateLoc.begin(),listCandidateLoc.end());// the average covered ratio
		std::sort(localRatio1.begin(),localRatio1.end());// the rouge cost
		//decide the rank, each index is weighted with 1/2
		std::vector<std::pair<double, int>>weight_rank;
		for (int i=0;i<(int)listCandidateLoc.size();i++){
			int loc = listCandidateLoc[i].second;
			int rank2 = -1;
			for (int j=0;j<(int)localRatio1.size();j++){
				if (localRatio1[j].second == loc){
					rank2 = j;
					break;
				}
			}
			if (rank2 == -1)std::cout<<"There is an error when generating weighted rank of each candidate location"<<std::endl;
			double weightRank = (i+1)*0.5 + (rank2+1)*0.5;
			weight_rank.push_back({weightRank,loc});
		}
		if (weight_rank.size() == 0)break;
		std::sort(weight_rank.begin(), weight_rank.end());
		//select depot from weight_rank;
		y=double(rand()%10000/10000.0);
		//rank=int(pow(y,data->determine_para)*(int)weight_rank.size());
		rank = rand() % (int)weight_rank.size();
		tarLoc = weight_rank[rank].second;
		// update locations' information
		locUsed[tarLoc] = true;
		selected_loc.push_back(tarLoc);
		//
		for (auto it = data->locIncCus[tarLoc-numV].begin(); it!= data->locIncCus[tarLoc-numV].end(); it++) {
			covered_cus.insert(*it);
		}
		if (covered_cus.size() == data->numV)break;
		//
		currentDem += s->location[tarLoc-numV].inventory;
		for (int i=0;i<(int)data->covered_spanning_cus[tarLoc-numV].size();i++){
			existCus.insert(data->covered_spanning_cus[tarLoc-numV][i]);
		}
	}
	// check
	bool ismax;
	for (int j=0;j<numV;j++){
		ismax = true;
		for (int i=0;i<(int)selected_loc.size();i++){
			if (data->D[selected_loc[i]][j] * 2 <= data->maxLength){
				ismax = false;
				break;
			}
		}
		if (ismax)
			return false;
	}
	return true;
}
void initial_sol::newGreedyInsert(){
	s->initilization();
	for (int i=0;i<numC;i++) locUsed[i] = false;
	for (int i=0;i<numV;i++) cusUsed[i] = false;
//	while(1){
//		if(select_depots())
//			break;
//	}
	double y;
	int rank;
	int tarLoc;
	selected_loc.clear();
	if (rankPop < static_cast<int>(data->compactLocConfigure.size())) {
		for (auto it = data->compactLocConfigure[rankPop].begin(); it != data->compactLocConfigure[rankPop].end(); it++) {
			selected_loc.push_back(*it);
		}
	}
	else {
		select_depots();
	}
	//
	random_shuffle(selected_loc.begin(),selected_loc.end());
	for (int i=0;i<(int)selected_loc.size();i++){
		s->location[selected_loc[i]-numV].used = true;
		locUsed[selected_loc[i]] = true;
	}
	/**************************************************************************/
	NodeDepot *loc;Node *pp;
	remainDem = data->totalDemand;
	for (int j=0;j<numV;j++){// inserted customers into depots as fair as possible.
		pp = &s->client[j];
		for (int k=0;k<(int)data->includedDeopt[j].size();k++){
			loc = &s->location[data->includedDeopt[j][k] - numV];
			if (loc->used && loc->remainInven + pp->dem <= loc->inventory){// the capacity constraint
				loc->in_range.push_back({data->D[j][loc->cour], pp});
				pp->covered_loc = loc;
				loc->remainInven += pp->dem;
				cusUsed[pp->cour] = true;
				remainDem = remainDem - pp->dem;
				s->updateLocationInfor(loc->cour);// update the information
				s->updateCoveredInfor(loc->cour);
				break;
			}
		}
	}
	// insert all non-covered customers
	int iteration = 0;
	std::vector<int>used_loc;
	while(remainDem != 0){
		if (data->stopCondition(s->fit)) return;
		// extract all locations which are not fulled
		std::vector<int>location_insert_customers;
		for (int i=0;i<(int)selected_loc.size();i++){
			auto it = find(used_loc.begin(),used_loc.end(), selected_loc[i]);
			if (s->location[selected_loc[i]-numV].inventory - s->location[selected_loc[i]-numV].remainInven > data->minDemand
					&& it == used_loc.end()){// this location may has potential to insert customers
				location_insert_customers.push_back(selected_loc[i]);
				
			}
		}
		/****************************************/
		if (location_insert_customers.empty())break;
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para)*(int)location_insert_customers.size());
		if (rank >= (int)location_insert_customers.size()) rank = (int)location_insert_customers.size() - 1;
		tarLoc = location_insert_customers[rank];
		locUsed[tarLoc] = true;
		for (int i = 0; i < (int)selected_loc.size(); i++) {
			if (selected_loc[i] == tarLoc) {
				selected_loc.erase(selected_loc.begin() + i);
				 break;
			}
		}
		//
		insertCusToLoc(tarLoc);
		used_loc.push_back(tarLoc);
		iteration++;
		if (iteration > 20)break;
		//
	}
	int rescueIteration = 0;
	while(remainDem != 0){
		if (data->stopCondition(s->fit)) return;
		int previousRemainDem = remainDem;
		int usedInventory = 0;
		std::vector<int>location;
		for (int i=0;i<numL;i++)
			if (locUsed[i+numV]) {
				usedInventory += s->location[i].inventory;
				location.push_back(i + numV);
			}
		if (usedInventory < data->totalDemand) {
			int extraLoc = -1;
			for (int i=0;i<(int)data->locRatio.size();i++) {
				int candidateLoc = data->locRatio[i].second;
				if (!locUsed[candidateLoc]) {
					extraLoc = candidateLoc;
					break;
				}
			}
			if (extraLoc != -1) {
				locUsed[extraLoc] = true;
				s->location[extraLoc-numV].used = true;
				usedInventory += s->location[extraLoc-numV].inventory;
				location.push_back(extraLoc);
				insertCusToLoc(extraLoc);
				rescueIteration++;
				if (remainDem != previousRemainDem)
					continue;
			}
		}
		if (usedInventory >= data->totalDemand && remainDem != 0){// the most key method to guarantee the feasible
			remedyTheSolution(location);
		}
		if (remainDem == previousRemainDem) {
			s->isFeasible = false;
			return;
		}
		rescueIteration++;
		if (rescueIteration > numL + numV) {
			s->isFeasible = false;
			return;
		}
	}
}
void initial_sol::insertCusToLoc(int loc){
	random_shuffle(data->edgeLocVec[loc-numV].begin(),data->edgeLocVec[loc-numV].end());
	Node *p, *nodeU, *nodeV, *pos = NULL; bool isFirst,consider;
	double delta, min_delta;
	for (int i=0;i<(int)data->edgeLocVec[loc-numV].size();i++){
		if (data->stopCondition(s->fit)) return;
		p = &s->client[data->edgeLocVec[loc-numV][i]];
		if (!cusUsed[p->cour]){
			min_delta = Max;
			for (int j=0;j<s->location[loc-numV].maxVisit;j++){
				if (data->D[p->cour][loc] * 2 > data->maxLength)break;
				if (s->location[loc-numV].depots[j].route->load + p->dem <= data->vehCap && s->location[loc-numV].remainInven + p->dem <= s->location[loc-numV].inventory){
					nodeU = &s->location[loc-numV].depots[j];
					isFirst = true;
					while(isFirst || !nodeU->isDepot){
						delta = data->D[nodeU->cour][p->cour] + data->D[p->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
						if (delta < min_delta && delta + nodeU->route->dis < data->maxLength){
							min_delta = delta;
							pos = nodeU;
						}
						isFirst = false;
						nodeU = nodeU->next;
					}
				}
			}
			if (min_delta == Max)continue;// the customer cannot be inserted into the solution
			insertClient(p, pos);
			s->updateRouteInfor(pos->route->cour,-1);
			s->updateLocationInfor(pos->route->whichLocation->cour);
			cusUsed[p->cour] = true;
			//
			while(1){
				if (data->stopCondition(s->fit)) return;
				consider = false;
				for (int j=0;j<(int)data->edgeNode[p->cour].size();j++){
					if (data->edgeNode[p->cour][j] >= numV)continue;
					nodeV = &s->client[data->edgeNode[p->cour][j]];
					if (!cusUsed[nodeV->cour]){
						if (p->route->load + nodeV->dem <= data->vehCap && p->route->whichLocation->remainInven + nodeV->dem <= p->route->whichLocation->inventory
								&& p->route->dis + data->D[p->cour][nodeV->cour] + data->D[nodeV->cour][p->next->cour] - data->D[p->cour][p->next->cour] <= data->maxLength){
							consider = true;
							insertClient(nodeV, p);
							s->updateRouteInfor(p->route->cour,-1);
							s->updateLocationInfor(p->route->whichLocation->cour);
							cusUsed[nodeV->cour] = true;
							p = nodeV;
							break;
						}
						else if (p->route->whichLocation->remainInven + nodeV->dem <= p->route->whichLocation->inventory
							&& data->D[nodeV->cour][loc] * 2 <= data->maxLength) {
							consider = true;
							nodeU = &s->location[loc-numV].depots[s->location[loc-numV].splitTime];
							insertClient(nodeV, nodeU);
							s->updateRouteInfor(nodeU->route->cour,-1);
							s->updateLocationInfor(nodeU->route->whichLocation->cour);
							cusUsed[nodeV->cour] = true;
							p = nodeV;
							break;
						}
					}
				}
				if (! consider || remainDem == 0) break;
			//	s->outputSolution();
			}
		}
	}
	// is there any customer can be inserted into the location
	for (int i=0;i<(int)data->nearCityLoca[loc-numV].size();i++){
		if (data->stopCondition(s->fit)) return;
		p = &s->client[data->nearCityLoca[loc-numV][i]];
		if (cusUsed[p->cour])continue;
		if (s->location[loc-numV].remainInven + p->dem > s->location[loc-numV].inventory)continue;
		min_delta = Max;
		for (int j=0;j<s->location[loc-numV].maxVisit;j++){
			if (s->location[loc-numV].depots[j].route->load + p->dem <= data->vehCap && s->location[loc-numV].remainInven + p->dem <= s->location[loc-numV].inventory){
				nodeU = &s->location[loc-numV].depots[j];
				isFirst = true;
				while(isFirst || !nodeU->isDepot){
					delta = data->D[nodeU->cour][p->cour] + data->D[p->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (delta < min_delta && nodeU->route->dis + delta <= data->maxLength){
						min_delta = delta;
						pos = nodeU;
					}
					isFirst = false;
					nodeU = nodeU->next;
				}
			}
		}
		if (min_delta == Max)return;// the customer cannot be inserted into the solution
		insertClient(p, pos);
		s->updateRouteInfor(pos->route->cour,-1);
		s->updateLocationInfor(pos->route->whichLocation->cour);
		cusUsed[p->cour] = true;
	}
}
void initial_sol::remedyTheSolution(std::vector<int> location){// to use the infeasible framework to restore the solution.
	int remainCap, tarLoc;
	std::vector<int>can_depot;
	Node *p, *pos = NULL;
	Node *fallbackPos = NULL;
	double delta, min_delta, fallbackDelta;
	bool isFirst;
	for (int i=0;i<numV;i++){
		if (data->stopCondition(s->fit)) return;
		if (!cusUsed[i]){// adjust customers in locations and insert the customer i in targeted locations.
			remainCap = 0;
			tarLoc = -1;
			can_depot.clear();
			for (int i = 0; i < (int)location.size(); i++) {
				can_depot.push_back(location[i] - numV);
			}
			if (can_depot.size() == 0) { 
				std::cout << "there is a wrong problem" << std::endl; exit(0); 
			}
			min_delta = Max;
			fallbackDelta = Max;
			pos = NULL;
			fallbackPos = NULL;
			for (int k = 0; k < can_depot.size(); k++) {
				tarLoc = can_depot[k];
				for (int j = 0; j < s->location[tarLoc].maxVisit; j++) {
					p = &s->location[tarLoc].depots[j];
					isFirst = true;
					while (isFirst || !p->isDepot) {
						delta = data->D[p->cour][i] + data->D[i][p->next->cour] - data->D[p->cour][p->next->cour];
						if (delta < fallbackDelta) {
							fallbackDelta = delta;
							fallbackPos = p;
						}
						if (p->route->load + s->client[i].dem <= data->vehCap) {
							if (delta < min_delta && p->route->dis + delta <= data->maxLength) {
								min_delta = delta;
								pos = p;
							}
						}
						p = p->next;
						isFirst = false;
					}
				}
				if (min_delta < Max)break;
			}
			if (pos == NULL)
				pos = fallbackPos;
			if (pos == NULL)
				std::cout << "The remedy of algorithm when generating initial solution is wrong" << std::endl;
			if (pos == NULL) {
				s->isFeasible = false;
				return;
			}
			p = &s->client[i];
			insertClient(p, pos);
			s->updateRouteInfor(pos->route->cour,-1);
			s->updateLocationInfor(pos->route->whichLocation->cour);
			cusUsed[p->cour] = true;
		//	s->outputSolution();
		}
	}
}
void initial_sol::initial_solution(Individual* s, int rank){
	this->s=s;
	this->rankPop = rank;
	newGreedyInsert();
	if (!s->isFeasible) return;
	if (data->stopCondition(s->fit)) return;
//	if (rank == 3)
//		s->outputSolution();
	repair->repairForInitialSolution(s);
	if (data->stopCondition(s->fit)) return;
	s->evaluationDis();
//	if (rank == 4)
//		s->outputSolution();
	s->isRight();
//	s->outputSolution();
}

