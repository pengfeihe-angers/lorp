#include "popManager.h"
popManager::popManager(read_data *data) {
	// TODO Auto-generated constructor stub
	this->data=data;
	this->numV = data->numV;
	this->numL = data->numL;
	this->numC = data->numC;
	order = new int [numV];
	popula = std::vector <std::vector<Individual*>>(max_number_popu+1);
	avgCostPop = new double [max_number_popu+1];
	for (int i=0;i<max_number_popu+1;i++)
		avgCostPop[i] = 0;
}
popManager::~popManager() {
	// TODO Auto-generated destructor stub
	for (int i = 0; i < (int)feasibleSubpopulation.size(); i++)
		delete feasibleSubpopulation[i];
	delete [] order;
	for (int i=0;i < data->numLocConfiguration +1;i++){
		for (Individual * indiv : popula[i]) delete indiv;
		popula[i].clear();
	}
	delete [] avgCostPop;
}
void popManager:: copyAllData(Individual * s,Individual *ss){
	Node *nodeU;
	/*initialize solution s*/
	for (int i=0;i<numV; i++){
		s->client[i].pre = NULL;
		s->client[i].next = NULL;
		s->client[i].route = NULL;
		s->client[i].covered_loc = NULL;
	}
	for (int i=0;i<numL;i++){
		s->location[i].emptyRoutes.clear();
		for (int j=0;j<s->location[i].maxVisit;j++){
			s->location[i].depots[j].next = &s->location[i].endDepots[j];
			s->location[i].endDepots[j].pre = &s->location[i].depots[j];
			s->updateRouteInfor(s->location[i].depots[j].route->cour, -1);
		}
	//	s->updateLocationInfor(i + numV);
		s->location[i].used=false;
		s->location[i].emptyRoutes.clear();
		s->location[i].in_range.clear();
	}
	//
	int count;
	Route * routeU;
	for (int i=numV; i<numC;i++){
		if (!ss->location[i-numV].used){
			s->updateLocationInfor(i);
			continue;
		}
		// copy all customers covered by locations
		for (int j=0;j<(int)ss->location[i-numV].in_range.size();j++){
			s->location[i-numV].in_range.push_back({data->D[i][ss->location[i-numV].in_range[j].second->cour],
				&s->client[ss->location[i-numV].in_range[j].second->cour]});
			s->client[ss->location[i-numV].in_range[j].second->cour].covered_loc = &s->location[i-numV];
		}
		s->updateCoveredInfor(i);
		//
		for (int j=0;j<ss->location[i-numV].maxVisit;j++){
			if (ss->location[i-numV].depots[j].route->used){
				count = 0;
				nodeU = ss->location[i-numV].depots[j].next;
				while(!nodeU->isDepot){
					order[count] = nodeU->cour;
					count++;
					nodeU=nodeU->next;
				}
				s->location[i-numV].depots[j].route->used = true;
				routeU = s->location[i-numV].depots[j].route;
				nodeU = &s->client[order[0]];
				nodeU->pre = routeU->depot;
				nodeU->route = routeU;
				routeU->depot->next = nodeU;
				for (int k=1; k<count; k++){
					s->client[order[k]].pre = nodeU;
					nodeU->next = &s->client[order[k]];
					s->client[order[k]].route = routeU;
					nodeU = &s->client[order[k]];
				}
				nodeU->next = routeU->endDepot;
				routeU->endDepot->pre = nodeU;
				s->updateRouteInfor(routeU->cour,-1);
			}
			else{
				s->location[i-numV].depots[j].next = &s->location[i-numV].endDepots[j];
				s->location[i-numV].endDepots[j].pre = &s->location[i-numV].depots[j];
				s->updateRouteInfor(s->location[i-numV].depots[j].route->cour,-1);
			}
		}
		s->updateLocationInfor(i);
	}
	s->dis=ss->dis;
	s->fit=ss->fit;
	s->biasedFit=ss->biasedFit;
	s->isFeasible=ss->isFeasible;
	s->evaluationDis();
}
void popManager::insertSolution(Individual *indiv, int rankPop){
	SubPopulation & subpop = popula[rankPop];
	//
	for (Individual * myIndividual : subpop)// no clone individuals
		if (myIndividual->fit + Min > indiv->fit && myIndividual->fit - Min < indiv->fit)
			return;

	Individual * myIndividual = new Individual();

	myIndividual->define(data);
	myIndividual->initilization();
	copyAllData(myIndividual, indiv);
	for (Individual * myIndividual2 : subpop){
		double myDistance = myIndividual->brokenPairsDistance(myIndividual2);
		myIndividual2->indivsPerProximity.insert({ myDistance, myIndividual });
		myIndividual->indivsPerProximity.insert({ myDistance, myIndividual2 });
	}
	//
	int place = (int)subpop.size();
	while (place > 0 && subpop[place - 1]->fit > indiv->fit - Min) place--;
	subpop.emplace(subpop.begin() + place, myIndividual);

//	if (data->iteration == 110)
//		delete myIndividual;
	//
	if (indiv->fit + Min < bestIndivRestart->fit){
		indiv->isRight();
		bestIndivRestart->initilization();
		copyAllData(bestIndivRestart, indiv);
		data->meetBestTime = (double)clock()/(double)CLOCKS_PER_SEC;
		data->nbIterNonImpro=0;
		if (indiv->fit + Min < global->fit){
			global->initilization();
			copyAllData(global, indiv);
			data->meetBestTime = float((double)clock()/(double)CLOCKS_PER_SEC);
		}
	}
	int iter = 0;
	if ((int)subpop.size() == data->popMax ){
		while ((int)subpop.size() > data->popMin){
			iter++;
			removeWorstBiasedFitness(subpop);
		}
	}
	//updating the best and average values
}
int popManager::identifyDepotConfiguration(){
	bool same;
	for (int i=0;i<(int)list_depots.size();i++){
		same  = true;
		for (int j=0;j<(int)list_depots[i].size();j++){
			if (list_depot[j] != list_depots[i][j]){
				same = false;
				break;
			}
		}
		if (same) return i;
	}
	return (int)list_depots.size();
}
int popManager::addIndividual(Individual *indiv, int rankPOP){
	//
	if (!indiv->isFeasible)return -2;
	int rank;
	list_depot.clear();
	for (int j=0;j<numL;j++){
		if (indiv->location[j].used)
			list_depot.push_back(1);
		else
			list_depot.push_back(0);
	}
	if ((int)list_depots.size() < data->numLocConfiguration){
		rank= identifyDepotConfiguration();
		if (rank < (int)list_depots.size()){
			insertSolution(indiv, rank);
		}
		else{
			insertSolution(indiv, rank);
			list_depots.push_back(list_depot);
//			best_results_popu.push_back({indiv->fit,rank});
		}
	}
	else{
		rank = identifyDepotConfiguration();
		if (rank == (int)list_depots.size()){
			insertSolution(indiv, (int)list_depots.size());// the last subpopulation
		}
		else{
			insertSolution(indiv, rank);
		}
	}
	return rank;
}
void popManager::selectionParentSolution(int rankPop, Individual *off){
	SubPopulation & subpop = popula[rankPop];
	updateBiasedFitnesses(subpop);

	int rand1,rand2;
	Individual *target = NULL;
	if (subpop.size() == 1){
		target = subpop[0];
	}
	if (target == NULL){
		while(1){
			rand1=rand()%(int)subpop.size();
			rand2=rand()%(int)subpop.size();
			while(rand1 == rand2)
				rand2=rand()%(int)subpop.size();
			//if (subpop[rand1]->biasedFit < subpop[rand2]->biasedFit)
			if (subpop[rand1]->biasedFit < subpop[rand2]->biasedFit)
				target=subpop[rand1];
			else
				target=subpop[rand2];
			if (target != NULL)
				break;
		}
	}
	//
	off->initilization();
	copyAllData(off, target);
}
void popManager::reStart(){
	std::cout<<"----Restart and create a new population----"<<std::endl;
	for (int i=0;i<data->numLocConfiguration + 1;i++){
		for (Individual * indiv : popula[i]) delete indiv ;
		popula[i].clear();
	}
	data->nbIterNonImpro=0;
	bestIndivRestart->fit = Max;
}
double popManager::averagePop(){
	if (feasibleSubpopulation.empty())
		return Max;
	double fit=0;
	for (Individual * indiv : feasibleSubpopulation)
		fit += indiv->fit;
	fit = fit/(double)feasibleSubpopulation.size();
	return fit;
}
double popManager::usedDepots(){
	std::set<int>locations;
	for (Individual * indiv : feasibleSubpopulation){
		for (int i=0;i<numL;i++){
			if (indiv->location[i].used)
				locations.insert(i);
		}
	}
	int ss = (int)locations.size();
	return(double(ss) / double(numL));
}
void popManager::removeWorstBiasedFitness(SubPopulation & pop){
	updateBiasedFitnesses(pop);
	if (pop.size() <= 1) throw std::string("Eliminating the best individual: this should not occur in the algorithm");

	Individual * worstIndividual = NULL;
	int worstIndividualPosition = -1;
	bool isWorstIndividualClone = false;
	double worstIndividualBiasedFitness = -1.e30;
	for (int i = 0; i < (int)pop.size(); i++){
		bool isClone = (pop[i]->averageBrokenPairsDistanceClosest(1) < Min); // A distance equal to 0 indicates that a clone exists
		if ((isClone && !isWorstIndividualClone) || (isClone == isWorstIndividualClone && pop[i]->biasedFit > worstIndividualBiasedFitness)){
			worstIndividualBiasedFitness = pop[i]->biasedFit;
			isWorstIndividualClone = isClone;
			worstIndividualPosition = i;
			worstIndividual = pop[i];
		}
	}

	pop.erase(pop.begin() + worstIndividualPosition); // Removing the individual from the population
	for (Individual * myIndividual2 : pop) myIndividual2->removeProximity(worstIndividual); // Cleaning its distances from the other individuals in the population
	delete worstIndividual; // Freeing memory
	worstIndividual=NULL;
}

void popManager::updateBiasedFitnesses(SubPopulation & pop){
	// Ranking the individuals based on their diversity contribution (decreasing order of distance)
	std::vector <std::pair <double, int> > ranking;
	for (int i = 0 ; i < (int)pop.size(); i++)
		ranking.push_back({-pop[i]->averageBrokenPairsDistanceClosest(data->nbClost),i});
	std::sort(ranking.begin(), ranking.end());

	// Updating the biased fitness values
	if (pop.size() == 1)
		pop[0]->biasedFit = 0;
	else{
		for (int i = 0; i < (int)pop.size(); i++){
			double divRank = (double)i / (double)(pop.size() - 1); // Ranking from 0 to 1
			double fitRank = (double)ranking[i].second / (double)(pop.size() - 1);
			if ((int)pop.size() <= data->nbElite) // Elite individuals cannot be smaller than population size
				pop[ranking[i].second]->biasedFit = fitRank;
			else
				pop[ranking[i].second]->biasedFit = fitRank + (1.0 - (double)data->nbElite / (double)pop.size()) * divRank;
		}
	}
}
void popManager::removeEmptySubPop(){

}
void popManager::reduceHalfSubPop(){
	if ((int)popula.size() < 3)return;
	std::vector<std::pair<double, int>>averageCost;
	double avgCost;
	for (int i=0;i< max_number_popu;i++){
		avgCost = 0;
		for (int j=0;j<(int)popula[i].size();j++){
			avgCost += popula[i][j]->fit;
			if (std::abs(bestIndivRestart->fit - popula[i][j]->fit) < 0.000001)
				avgCost = -Max;
		}
		if ((int)popula[i].size() == 0)
			avgCost = Max;
		else
			avgCost = avgCost / (double)popula[i].size();
		averageCost.push_back({avgCost, i});
	}
}
