#ifndef POPMANAGER_H_
#define POPMANAGER_H_
#include "read_data.h"
#include "Individual.h"
typedef std::vector <Individual*> SubPopulation ;
typedef std::vector <std::vector<Individual*>> Population ;
class popManager {
public:
	popManager(read_data * data);
	virtual ~popManager();
	void reduceHalfSubPop();
	void removeEmptySubPop();
	//
	void copyAllData(Individual * s,Individual *ss);
	int addIndividual(Individual *indiv, int rankPOP);
	void reStart();
	//
	void removeWorstBiasedFitness(SubPopulation & pop);
	void updateBiasedFitnesses(SubPopulation & pop);
	/////////////
	void selectionParentSolution(int rankPop, Individual *off);
	double averagePop();
	double usedDepots();
	//variables;
	Individual *global;
	Individual *bestIndivRestart;
	std::vector <std::vector<Individual*>> popula;
	int max_number_popu = 100;
	double *avgCostPop;
private:
	//variables
	read_data *data;
	SubPopulation feasibleSubpopulation;			// Feasible subpopulation, kept ordered by increasing penalized cost
	int numV;
	int numL;
	int numC;
	int *order;
	//
	std::vector<std::pair<double, int>>best_results_popu;
	std::vector<std::pair<double, int>>average_results_popu;
	std::vector<std::vector<int>> list_depots;
	std::vector<int>list_depot;
	//
	void insertSolution(Individual *indiv, int rankPop);
	int identifyDepotConfiguration();
};
#endif /* POPMANAGER_H_ */
