#include "read_data.h"
#include "basic.h"
#include "Individual.h"
read_data::read_data() {
}
read_data::~read_data() {
	for (int i=0;i<numC;i++)
		delete [] D[i];
	delete [] D;
	delete [] x;
	delete [] y;
	delete [] demCus;
	delete [] invLoc;
	delete [] openCostLoc;
}
void read_data::define(){
	D=new double *[numC];
	for (int i=0;i<numC;i++) D[i]=new double [numC];
	x=new double [numC];
	y=new double [numC];
	demCus=new int [numV];
	invLoc = new int [numC];
	openCostLoc = new double [numC];
	edgeNode = std::vector< std::vector < int > >(numV);
	customerToLoc = std::vector< std::vector < int > >(numV);
	edgeLocVec = std::vector < std::vector < int > > (numL);
	nearCity = std::vector< std::vector < int > >(numV);
	nearCityLoca = std::vector< std::vector < int > >(numL);
	//
	conflictLoc = new int* [numL];
	for (int i = 0; i < numL; i++) conflictLoc[i] = new int[numL];
	for (int i = 0; i < numL; i++)
		for (int j = 0; j < numL; j++)
			conflictLoc[i][j] = 0;
	locIncCus = std::vector<std::set<int>>(numL);
}
void read_data::read_fun(std::string pathInstance,std::string pathDepotCon,std::string pathSolution, int maxLength, int range, double bestDis, int isOptimal, int timeLimit,int iterLimit, double directServiceFactor, double routingFactor, bool useCapacitatedDepot, bool useMoveEjection, int numPromisingDepotConfigurations, int initialFilterParameter, int popMin){
	/****imput information*******/
	this->timeLimit=timeLimit;
	this->iterLimit=iterLimit;
	this->bestDis = bestDis;
	this->isOptimal=isOptimal;
	this->pathSolution=pathSolution;
	this->pathDepotCon=pathDepotCon;
	this->pathInstance=pathInstance;
	this->maxLength = maxLength;
	this->Range = range;
	this->directServiceFactor = directServiceFactor;
	this->routingFactor = routingFactor;
	this->useCapacitatedDepot = useCapacitatedDepot;
	this->useMoveEjection = useMoveEjection;
	this->numPromisingDepotConfigurations = numPromisingDepotConfigurations;
	if (initialFilterParameter > 0)
		this->initial_fliter_parameter = initialFilterParameter;
	if (popMin > 0) {
		this->popMin = popMin;
		this->popMax = popMin + 30;
	}
	//
	this->isFleetLimited = isFleetLimited;
	/*********************************************************/
	std::ifstream inputFile(pathInstance);
//	std::cout<<pathInstance<<std::endl;
	if (inputFile.is_open()){
		inputFile >> numV;  // the first var is the number of customers
		inputFile >> numL;  // the second var is the number of locations
		numC = numV + numL; // the total number of vertices
		//
		inputFile >> vehCap; // the third var is the capacity of vehicle
		double var = -1;
		inputFile >> usingCostVeh; // the fourth is the fixed cost of each vehicle 
		usingCostVeh = 0.0; // Exclude vehicle usage cost from objective and move evaluations.
		inputFile >> var;
		inputFile >> var;
		inputFile >> var;
		inputFile >> var;
		/************/
		define();
		for (int i=0; i< numV; i++){
			inputFile >> var;
			inputFile >> x[i];
			inputFile >> y[i];
			inputFile >> demCus[i];
		}
		for (int i=numV;i<numC;i++){
			inputFile >> var;
			inputFile >> x[i];
			inputFile >> y[i];
			inputFile >> openCostLoc[i];
			inputFile >> invLoc[i];
			inputFile >> var;
		}
	}
	else {
		std::cout<<"Wrong when opening file"<<std::endl;
		exit(0);}
	inputFile.close();
	//determine the capacity of depots
	if (!useCapacitatedDepot) {
		for (int i = numV; i < numC; i++) {
			invLoc[i] = Max;
		}
	}
//	readDepotConfigurations();
	totalDemand=0;
	int maxDemand=0;
	for (int i=0; i < numV; i++){
		if (demCus[i] > maxDemand)
			maxDemand=demCus[i];
		if (minDemand > demCus[i])
			minDemand = demCus[i];
		totalDemand+=demCus[i];
	}
	normalizaPara = double(numV) / double(totalDemand);
	avgDemand = double(totalDemand) / double(numV);
	//
	int numOfVeh;
	maxVnum=0;
	for (int i=0;i<numL;i++){
		numOfVeh = (int)ceil(1.2*totalDemand/vehCap)+5;
		maxVnum = maxVnum + (int)std::min((double)numOfVeh, 3.*(double)ceil((double)invLoc[i+numV]/(double)vehCap));
	}
	maxVnum = numV;
	// process the initial data
	isConstraintLoc = false;
	for (int i=numV;i<numC;i++){
		if (invLoc[i] <= totalDemand){
			isConstraintLoc = true;
			break;
		}
	}
	/***********************************************************************************************/
	/*give the distance matrix*/
	double maxDist = 0;
	for (int i=0;i<numV;i++){
		for (int j=0;j<numV;j++){
			D[i][j]=(sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])));
			if (D[i][j] > maxDist)
				maxDist = D[i][j];
		}
	}
	for (int i=0; i < numV;i++){
		for (int j=numV; j<numC; j++){
			D[i][j] = (sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])));
			D[j][i] = D[i][j];
			if (D[i][j] > maxDist)
				maxDist = D[i][j];
		}
	}
	for (int i=numV; i<numC; i++)
		for (int j=numV; j<numC; j++)
			D[i][j] = 0;

	//set the length of maximum arc equals to 100/****************************************/
	double cc = maxDist / 100.; 
	for (int i=0;i<numV;i++){
		for (int j=0;j<numV;j++){
			D[i][j] = D[i][j]/cc;
		}
	}		
	for (int i=0; i < numV;i++){
		for (int j=numV; j<numC; j++){
			D[i][j] = D[i][j] / cc;
			D[j][i] = D[i][j];
		}
	}
	/*********************/
	range_cus = std::vector<std::vector<int>>(numC);
	for (int i=numV;i<numC;i++){
		for (int j=0;j<numV;j++){
			if (D[i][j] <= Range)// customers can be covered by the location
				range_cus[i].push_back(j);
		}
		covered_spanning_cus.push_back(range_cus[i]);
	}
	includedDeopt = std::vector<std::vector<int>>(numV);
	std::vector<std::pair<double, int>>order(numV);
	for (int i=0;i<numV;i++){
		order.clear();
		for (int j=numV;j<numC;j++){
			if (D[i][j] <= Range)
				order.push_back({D[i][j],j});
		}
		sort(order.begin(),order.end());
		for (int j=0;j<(int)order.size();j++)
			includedDeopt[i].push_back(order[j].second);
	}

/*	if (realOrInteger == 0)
		for (int i=0;i<numC;i++)
			for (int j=0;j<numC;j++)
				D[i][j] = (int)(ceil(D[i][j]*100));
	// the most key element to decide promising depot configurations.*/
	/* construct sparse graph****************/
	std::vector < std::set < int > > setCorrelatedVertices = std::vector < std::set <int> >(numC);
	std::vector < std::pair <double, int> > orderProximity;
	for (int i = 0; i <numV; i++){
		orderProximity.clear();
		for (int j = 0; j <numC; j++)
			if (i != j) orderProximity.push_back(std::pair <double, int>(D[i][j], j));

		sort(orderProximity.begin(), orderProximity.end());
		for (int j = 0; j < std::min<int>(alpha, numV - 2);  j++){
			setCorrelatedVertices[i].insert(orderProximity[j].second);
			setCorrelatedVertices[orderProximity[j].second].insert(i);
		}
		for (int j=0;j < (int)orderProximity.size();j++)
			nearCity[i].push_back(orderProximity[j].second);
	}
	// Filling the vector of correlated vertices
	for (int i = 0; i <numV; i++)
		for (int x : setCorrelatedVertices[i])
			edgeNode[i].push_back(x);
	// to control the number of locations closed to customers.
	for (int i = 0; i< numV; i++){
		for (int j=0; j<(int)nearCity[i].size(); j++){
			if (nearCity[i][j] >= numV){
				customerToLoc[i].push_back(nearCity[i][j]);
			}
		}
	}
	//
	std::vector < std::set < int > > setCorrelatedLocation = std::vector < std::set <int> >(numL);
	for (int i=0; i < numL; i++){
		orderProximity.clear();
		for (int j = 0; j <numV; j++)
			orderProximity.push_back(std::pair <double, int>(D[j][i+numV], j));
		sort(orderProximity.begin(), orderProximity.end());
		for (int j = 0; j < std::min<int>(alpha, numV - 2);  j++)
				setCorrelatedLocation[i].insert(orderProximity[j].second);
		for (int j=0;j < (int)orderProximity.size();j++)
			nearCityLoca[i].push_back(orderProximity[j].second);
	}
	for (int i = 0; i <numL; i++)
		for (int x : setCorrelatedLocation[i])
			edgeLocVec[i].push_back(x);
	/****************************************************///
	//decide whether used extra depot configurations
	analyzeLocation();
	//
	covered_cus_depot = std::vector<std::vector<int>>(numL);
	for (int i=0;i<numL;i++)
		for (int j=0;j<numV;j++)
			if (D[i + numV][j] * 2 <= maxLength) {
				covered_cus_depot[i].push_back(j);
			}
}
//
bool read_data::stopCondition(double dis){
	if ((double)(clock() - startTime)/(double)CLOCKS_PER_SEC > timeLimit)
		return true;
	if (iteration > iterLimit)
		return true;
	if (meetOptimal && bestDis > dis +Min){
		timeToTarget = (double)clock()/(double)CLOCKS_PER_SEC;
		meetOptimal = false;
	}
	if (std::abs(bestDis - dis) < 0.01){
		if (isOptimal)return true;
	}
	return false;
}
bool read_data::equalTwoVar(double A, double B){
	if (abs(A-B) < Min)return true;
	else return false;
}
void read_data::analyzeLocation(){
	//using MST to evaluate the rouge cost of each location
	spanningTreeForLoc();
//	std::sort(locRatio.begin(),locRatio.end());
	// 
	findCandidateDepotConfigurations();
}
void read_data::spanningTreeForLoc(){
	std::vector<int>cus_out;//not covered by the location
	std::vector<int>cus_in;
	//////////////the following is the spanning tree method
	double total_dis_loc;
	int total_dem;
	for (int l = 0; l < numL; l++) {
		total_dem = 0;//能够被覆盖的总需求
		total_dis_loc = 0;
		cus_out.clear();
		for (int i = 0; i < numV; i++){
			if (D[l + numV][i] <= Range) {
				total_dem += demCus[i];// if the customer is covered by the location, then the demand should be reduce
				locIncCus[l].insert(i);
				total_dis_loc += directServiceFactor * D[l + numV][i];
			}
			else
				cus_out.push_back(i);
		}
		cus_in.clear();
		cus_in.push_back(l+numV);
		while(1){//
			double min_cost= Max;
			int index = -1;/// using to save the customer which should be added into the MST
			for (int i=0;i<(int)cus_in.size();i++){
				for (int j=0;j<(int)cus_out.size();j++){
					if (D[l+numV][cus_out[j]] * 2 > maxLength)
						continue;
					else if(D[cus_out[j]][cus_in[i]] < min_cost ){
						min_cost = D[cus_out[j]][cus_in[i]];
						index = j;
					}
				}
			}
			if (index == -1)break;//MST没有找打可以被拓展的customer
			total_dem += demCus[cus_out[index]];
				total_dis_loc += routingFactor * min_cost;
			cus_in.push_back(cus_out[index]);
			cus_out.erase(cus_out.begin()+index);
		}
		int numVehicle = (int)ceil(total_dem/vehCap);
		double cost_loc = openCostLoc[l + numV] + total_dis_loc + numVehicle * usingCostVeh;
//		cost_loc = cost_loc / invLoc[l+numV];///////the unit cost per demand should be used to evaluate each loation
		locRatio.push_back({(double)cost_loc, l+numV});
		//
		cus_in.erase(cus_in.begin());// remove the first node,,the depot
		//
		for (int i=0;i<(int)cus_in.size();i++)
			locIncCus[l].insert(cus_in[i]);
		//
		covered_cus.push_back(cus_in);
		for (int i=0;i<(int)covered_cus[l].size();i++){
			covered_spanning_cus[l].push_back(covered_cus[l][i]);
		}
	}

	overlap_cus = std::vector<std::vector<std::vector<int>>>(numL,std::vector<std::vector<int>>(numL));
	for (int i=0;i<numL;i++){
		std::vector<int>cus1;
		std::vector<int>cus2;
		for (int j=0;j<numV;j++)
			if (D[i+numV][j] <= Range)
				cus1.push_back(j);
		for (int j=0;j<i;j++){
			for (int k=0;k<numV;k++)
				if (D[j+numV][k] <= Range)
					cus2.push_back(k);
			//
			std::vector<int>cusO;
			for (int k=0;k<(int)cus1.size();k++){
				auto it = std::find(cus2.begin(),cus2.end(), cus1[k]);
				if (it != cus2.end()){
					cusO.push_back(cus1[k]);
				}
			}
			overlap_cus[i][j] = cusO;
			overlap_cus[j][i] = cusO;
		}
	}
}
void read_data::findCandidateDepotConfigurations() {
	int min_depot = Max;
	int max_depot = 0;
	for (int i = numV; i < numC; i++) {
		if (min_depot > invLoc[i])
			min_depot = invLoc[i];
		if (max_depot < invLoc[i])
			max_depot = invLoc[i];
	}
	if (min_depot > totalDemand) {//这里是指每个depot的容量无穷大，应该换一种策略设计
		constructedDepotConfigurations();
		if (LocConfigure.size() == 0) {
			std::cout << "Cannot Find a Feasible Depot Configuration" << std::endl;
			exit(0);
		}
		std::sort(locRatio.begin(), locRatio.end());
		return;
	}
	//考虑depot容量约束
	constructedDepotConfigurations();
	std::cout << "The number of Depot Configurations is: " << (int)LocConfigure.size() << std::endl;
	std::sort(LocConfigure.begin(), LocConfigure.end());
	std::cout << "finishing the depot configurations" << std::endl;
	std::sort(locRatio.begin(), locRatio.end());
}

void read_data::constructedDepotConfigurations() {
	//the line function to estimate the coverRatio
	double min_coverRatio = 0.1;
	double max_coverRatio = 0.6;
	double kParameter = max_coverRatio - min_coverRatio;
	//
	solutionTabu = new int[dimension];
	for (int i = 0; i < dimension; i++)
		solutionTabu[i] = 0;
	int seed;
	double coverRatio = 0.2;// assuming the covering ratio is 50%
	double costDepotConf;
	int countOver;
	int iter;
	int totalDem;
	std::set<int>coverVertex;
	std::vector<std::pair<double, int>>priorityOrder;// the first is the ratio of overlaping vertices and the second is the order of depot
	std::set<int>sol;
	std::vector<int>depot;
	std::vector<std::pair<double, int>>orderDepots;
	std::set<int>array;
	int iteration = 0;
	int no_get = 0;
	bool isUsed;
	isUsed = true;
	while (1) {
		sol.clear();
		depot.clear();
		coverVertex.clear();
		for (int i = 0; i < numL; i++)depot.push_back(i);
		seed = rand() % numL;
		costDepotConf = locRatio[seed].first;//贪婪选取
		sol.insert(seed);
		totalDem = invLoc[seed + numV];
		depot.erase(depot.begin() + seed);//
		//
		auto it = locIncCus[seed].begin();
		for (; it != locIncCus[seed].end(); it++) coverVertex.insert(*it);
		if (totalDem < Max) {
			while (1) {// select other depots
				priorityOrder.clear();
				for (int i = 0; i < (int)depot.size(); i++) {//deicde the overlapping vertices
					countOver = 0; iter = 0;
					auto it1 = locIncCus[depot[i]].begin();
					for (; it1 != locIncCus[depot[i]].end(); it1++) {
						auto it2 = coverVertex.find(*it1);
						if (it2 != coverVertex.end()) {
							countOver++;
						}
						iter++;
					}
					double var = iter > 0 ? (double)countOver / (double)iter : 1.0;
					priorityOrder.push_back({ var, depot[i] });
				}
				sort(priorityOrder.begin(), priorityOrder.end());
				orderDepots.clear();
				if ((int)orderDepots.size() == 0) {
					if (priorityOrder.size() == 0) {
						std::cout << "cannot find feasilbe depot configurations" << std::endl;
						return;
					}
					for (int i = 0; i <= (int)priorityOrder.size() / 2; i++) {
						orderDepots.push_back({ priorityOrder[i].first,priorityOrder[i].second });
					}
				}
				sort(orderDepots.begin(), orderDepots.end());
				double y = double(rand() % 10000 / 10000.0);
				int rank = int(pow(y, determine_para) * (int)orderDepots.size());
				if (rank >= (int)orderDepots.size()) rank = (int)orderDepots.size() - 1;
				seed = orderDepots[rank].second;
				auto it1 = locIncCus[seed].begin();
				for (; it1 != locIncCus[seed].end(); it1++)
					coverVertex.insert(*it1);
				int index;
				for (int i = 0; i < (int)depot.size(); i++)
					if (depot[i] == seed) {
						index = i; break;
					}
				depot.erase(depot.begin() + index);
				sol.insert(seed);
				costDepotConf += locRatio[seed].first;
				totalDem += invLoc[seed + numV];
				if (totalDem >= totalDemand && coverVertex.size() == numV)
					break;
			}
		}
		else {
			while (1) {// select other depots
				if (coverVertex.size() == numV) break;
				priorityOrder.clear();
				for (int i = 0; i < (int)depot.size(); i++) {//deicde the overlapping vertices
					countOver = 0; iter = 0;
					auto it1 = locIncCus[depot[i]].begin();
					for (; it1 != locIncCus[depot[i]].end(); it1++) {
				//		array2.insert(*it1);
						auto it2 = coverVertex.find(*it1);
						if (it2 != coverVertex.end()) {
							countOver++;
						}
						iter++;
					}
					double var = iter > 0 ? (double)countOver / (double)iter : 1.0;
					priorityOrder.push_back({ var, depot[i] });//越大越好
				}
				sort(priorityOrder.begin(), priorityOrder.end());
				orderDepots.clear();
				if ((int)orderDepots.size() == 0) {
					if (priorityOrder.size() == 0) {
						std::cout << "cannot find feasilbe depot configurations" << std::endl;
						return;
					}
					for (int i = 0; i <= (int)priorityOrder.size() / 2; i++) {
						orderDepots.push_back({ priorityOrder[i].first,priorityOrder[i].second });
					}
				}
				sort(orderDepots.begin(), orderDepots.end());
				double y = double(rand() % 10000 / 10000.0);
				int rank = int(pow(y, determine_para) * (int)orderDepots.size());
				if (rank >= (int)orderDepots.size()) rank = (int)orderDepots.size() - 1;
				seed = orderDepots[rank].second;
				auto it1 = locIncCus[seed].begin();
				for (; it1 != locIncCus[seed].end(); it1++)
					coverVertex.insert(*it1);
				int index;
				for (int i = 0; i < (int)depot.size(); i++)
					if (depot[i] == seed) {
						index = i; break;
					}
				depot.erase(depot.begin() + index);
				sol.insert(seed);
				costDepotConf += locRatio[seed].first;
				if (coverVertex.size() == numV) break;
			}
		}
		if (orderDepots.size() == 0) {
			no_get++;
			iteration++;
			continue;
		}
		it = sol.begin();
		array.clear();
		long long int binaryVal = 0;
		for (; it != sol.end(); it++) {
			array.insert(*it + numV);
			binaryVal += (long long int)pow(2, *it);
		}
		// solution based
		if (solutionTabu[binaryVal % dimension] == 0) {
			solutionTabu[binaryVal % dimension] = 1;
			//
			LocConfigure.push_back({ costDepotConf,array });
			if ((int)LocConfigure.size() > numLocConfiguration) {
				std::sort(LocConfigure.begin(), LocConfigure.end());
				std::cout << "finishing construction depots configurations" << std::endl;
				break;
			}
			no_get = 0;
		}
		else no_get++;
		if (no_get > 1000) {
			std::sort(LocConfigure.begin(), LocConfigure.end());
			std::cout << "finishing construction depots configurations" << std::endl;
			std::cout << "time consuming  " << float((double)clock() / (double)CLOCKS_PER_SEC) << std::endl;
			break;
		}
		iteration++;
		//	std::cout<<iteration<<"   "<<(int)LocConfigure.size()<<std::endl;
	}
	delete[] solutionTabu;
}
