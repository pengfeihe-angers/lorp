#ifndef READ_DATA_H_
#define READ_DATA_H_
#include <time.h>
#include "basic.h"
class read_data {
public:
	//general variables for recording some information
	int loopp;
	double probFixedCost;
	int iteration;
	int nbIterNonImpro;
	int isFleetLimited;
	clock_t startTime;
	int timeLimit;
	int iterLimit;
	int totalDemand;
	double avgDemand;
	bool isConstraintLoc;
	bool useCapacitatedDepot=false;
	bool useMoveEjection=usingMoveEjection;
	int episod = 100;
	// parameters used in population
	int nbClost=5;
	int nbElite=4;
	//parameters used in the shaw operator
	int nearest_pop_parameter=3;
	double determine_para=6;    // determinism parameter p_d suggested by Ropke and Pisinger (2006) TS
	/*parameters needed to be calibrated used in this paper*/
	/********************************************************************************************************/
	int initial_fliter_parameter = 10;
	int alpha=20;
	int popMin=30;//30
	int popMax=popMin+30;//30
	int popElit = 30;
	int mutationProb=85;
	double ratioPerturbLength=0.25;
	int maxIterNonProd=70000;
	/********************************************************************************************************/
	double penaltyDis = 10.0;
	double penaltyDepot = 10.0;
	double penaltyVeh = 10.0;
	double normalizaPara;
	/***********************************************************************************/
	//parameters for reading each instance
	std::vector < std::vector < int > > edgeNode;
	std::vector < std::vector < int > > customerToLoc;
	std::vector < std::vector < int > > nearCity;
	std::vector < std::vector < int > > nearCityLoca;
	std::vector < std::vector < int > > edgeLocVec;
	int numV;
	int numL;
	int numC;// the total number of vertices
	int vehCap;
	int maxVnum;
	int minDemand = Max;
	double ** D;// distance between all cities
	double *x;// the coordinate
	double *y;// the coordinate
	int *demCus;// the demand of each customers
	int *invLoc;// the inventory of depots,后面的为库存
	double *openCostLoc;
	double usingCostVeh;
	double directServiceFactor=0.0;
	double routingFactor=1.0;
	int realOrInteger = 0;

	int *dimTabu1;
	int *dimTabu2;
/****************************************************************************/
	read_data();
	virtual ~read_data();
	void define();// read information from .txt files including the number of customers
	void read_fun(std::string pathInstance, std::string pathDepotCon,std::string pathSolution, int maxLength, int Range, double bestDis, int isOptimal, int timeLimit,int iterLimit, double directServiceFactor, double routingFactor, bool useCapacitatedDepot, bool useMoveEjection, int numPromisingDepotConfigurations, int initialFilterParameter, int popMin);
	bool equalTwoVar(double A, double B);
	bool stopCondition(double dis);

/************************************************************************************/
	std::string pathSolution;     // used to file name of output best solution
	std::string pathDepotCon;
	std::string pathInstance;		// the name of instance
	double bestDis;					// record the best result from literature.
	int isOptimal;
	bool meetOptimal=true;
	double timeToTarget=Max;		// record the time when the algorithm meets the best results in literature
	double meetBestTime;
	/// 
	int maxLength;//车辆旅行长度
	int Range;
	std::vector<std::vector<int>> range_cus;
	std::vector<std::vector<int>> includedDeopt;//indicates the customer is covered by which location
/************************************************************************************/
	//variables for analyzing promising depot configurations
	std::vector<std::pair<double, int>>locRatio;
	std::vector<std::vector<int>>covered_cus;
	std::vector<std::vector<int>>covered_spanning_cus;
	std::vector<std::vector<std::vector<int>>>overlap_cus;

	std::vector<std::vector<int>>covered_cus_depot;//能够被depot覆盖的点
	int numLocConfiguration = 1000;
	std::vector<std::set<int>> compactLocConfigure;
	std::vector<std::set<int>>locIncCus;//each location includes which customer.
	std::vector<std::pair<double, std::set<int>>> LocConfigure;
	int numPromisingDepotConfigurations = 5;
private://用于获得promising depot configurations
	void analyzeLocation();
	void spanningTreeForLoc();
	void findCandidateDepotConfigurations();
	void constructedDepotConfigurations();
	//
	int ** conflictLoc;
	int * solutionTabu;
	int dimension = 10000000;
	
};
#endif /* READ_DATA_H_ */