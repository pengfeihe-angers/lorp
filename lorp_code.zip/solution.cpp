#include "basic.h"
#include "solution.h"
#include "initialsol.h"
#include "LS.h"
#include "crossover.h"
using namespace std;
solution::solution(read_data * data, crossover *cross, initial_sol *initialSol,LS *ls,  popManager *popman, RepairProcedure *repair,mutation *mutationOperator) {
	this->data=data;
	this->cross=cross;
	cross->repair = repair;
	this->initialSol=initialSol;
	this->ls=ls;
	this->popman=popman;
	this->repair=repair;
	this->mutationOperator=mutationOperator;
	//
	temIndiv=new Individual();
	temIndiv->define(data);
	global=new Individual();
	global->define(data);
	global->initilization();
	loc_best = new Individual();
	loc_best->define(data);
	loc_best->initilization();
	bestIndivRestart=new Individual();
	bestIndivRestart->define(data);
	bestIndivRestart->initilization();
	off=new Individual();
	off->define(data);
	off->initilization();
	//
	popman->global=global;
	popman->bestIndivRestart = bestIndivRestart;
	cross->global = global;
	int sizeSubPop=100;//
	subPop=new Individual[sizeSubPop];//
	for (int i=0;i<sizeSubPop;i++){
		subPop[i].define(data);
		subPop[i].initilization();
	}
	global->fit=Max;
	bestIndivRestart->fit=Max;
}
solution::~solution(){
	delete temIndiv;
	delete global;
	delete bestIndivRestart;
	delete [] subPop;
	delete loc_best;
	delete off;
}
void solution::preprocessingLocationConfiguration() {
	data->compactLocConfigure.clear();
	int initalNumDepots = std::min(500, (int)data->LocConfigure.size());      // the key parameters// 100
	if ((int)data->LocConfigure.size() < initalNumDepots)
		initalNumDepots = (int)data->LocConfigure.size();
	for (int i = 0; i < initalNumDepots; i++)
		data->compactLocConfigure.push_back(data->LocConfigure[i].second);
	//
	std::vector<std::pair<double, int>>averageCost;
	double avgCost, bestCost = Max;
	double global_cost = Max;
	int evaluatedCount;
	for (int i = 0; i < initalNumDepots; i++) {// an extra subPop
		if (data->stopCondition(global->fit)) break;
		avgCost = 0; bestCost = Max; evaluatedCount = 0;
		for (int j = 0; j < data->initial_fliter_parameter; j++) {
			if (data->stopCondition(global->fit)) break;
		//	std::cout << j << std::endl;
			initialSol->initial_solution(temIndiv, i);
			if (data->stopCondition(global->fit)) break;
			if (!temIndiv->isFeasible) continue;
			ls->local_search_run(temIndiv);
			if (!temIndiv->isFeasible) continue;
			evaluatedCount++;
			avgCost += temIndiv->fit;
			if (bestCost > temIndiv->fit)
				bestCost = temIndiv->fit;
			if (temIndiv->fit < global_cost) {
				// to record the best solution given each depot configuration
				global_cost = temIndiv->fit;
				loc_best->initilization();
				popman->copyAllData(loc_best, temIndiv);// record the best solution given the current depot configuration.
			}
		}
		if (evaluatedCount > 0)
			avgCost = avgCost / (double)(evaluatedCount);// in this place, we use the best solution
		//	averageCost.push_back({avgCost, i});
		averageCost.push_back({ bestCost, i });
		std::cout << i << "   tries   " << bestCost << std::endl;
	}
	std::sort(averageCost.begin(), averageCost.end());
	if (global_cost < Max - Min)
		loc_best->evaluationDis();
	//
	data->numLocConfiguration = data->numPromisingDepotConfigurations;
	data->compactLocConfigure.clear();
	for (int i = 0; i < std::min(data->numLocConfiguration, initalNumDepots); i++)
		data->compactLocConfigure.push_back(data->LocConfigure[averageCost[i].second].second);
	data->numLocConfiguration = std::min(data->numLocConfiguration, initalNumDepots);
	// add the best solution of each depot configuration in the elite subpop.
//	loc_best->outputBestSolution();
//	popman->addIndividual(loc_best, data->numLocConfiguration, true);// insert the local best solution to elite pop
	std::cout << "Finishing initial filter" << std::endl;
}
void solution::initialPop() {
	popman->popula.erase(popman->popula.begin() + data->numLocConfiguration + 1, popman->popula.end());
	int i;
	for (i = 0; i < data->numLocConfiguration + 1; i++) {// an extra subPop
		if (data->stopCondition(global->fit)) break;
		std::cout << i << " th ";
		std::cout << (double)clock() / (double)CLOCKS_PER_SEC << std::endl;
		generation_population(i, true);
		int count = 0;
		if ((int)popman->popula[i].size() <= 1)
			continue;
	//	while (count < data->maxIterationPerLoc)
	//		evolvePop(i, count);
	}
	std::cout << "Finishing constructing number of initial population" << std::endl;
}
void solution::generation_population(int rankPop, bool isInitial){
	double bestFit=Max;
	for (int i = 0; i < data->popMin*4; i++){
		if (data->stopCondition(global->fit)) break;
		initialSol->initial_solution(temIndiv, rankPop);
		if (data->stopCondition(global->fit)) break;
		if (!temIndiv->isFeasible)continue;
		ls->local_search_run(temIndiv);
		popman->addIndividual(temIndiv,rankPop);
		if (bestFit>temIndiv->fit)
			bestFit=temIndiv->fit;
	//	std::cout<<i<<"  The fitness is   "<< temIndiv->fit<<std::endl;
		data->iteration ++;
	}
	std::cout<<"The best fit is    "<<bestFit<<"  The time consuming  "<<(double)clock()/(double)CLOCKS_PER_SEC<<std::endl;
}
void solution::outputprocess(Individual *indiv){
	std::cout<<"It: "<<data->iteration<<"--G-Fit: "<<std::setiosflags(ios::fixed)<<std::setprecision(2)<<float(global->fit);
	std::cout<<"  --R-Fit: "<<bestIndivRestart->fit;
//	std::cout<<"    Avg F "<<float(popman->averagePop())<<std::setprecision(2);
	std::cout<<"  Curr Sol--"<<float(indiv->fit)<<std::setprecision(2);
	std::cout<<"  IT NoImpro--"<<data->nbIterNonImpro;
	std::cout<<"  Time comsuming--"<<float((double)clock()/(double)CLOCKS_PER_SEC)<<std::setprecision(2);
	std::cout<<std::endl;
	data->loopp = 0;
}
void solution::computingSubpopulation(int whichSubpop){
	if (whichSubpop == -1){
		for (int i=0;i<data->numLocConfiguration + 1; i++){// including the e lite population
			double fit = 0;
			for (int j=0;j<(int)popman->popula[i].size();j++)
				fit += popman->popula[i][j]->fit;
			if (popman->popula[i].empty())
				fit = Max;
			else
				fit = fit / (double)popman->popula[i].size();
			popman->avgCostPop[i] = fit;
		}
	}
	else if (whichSubpop > -1){
		double fit = 0;
		for (int j=0;j<(int)popman->popula[whichSubpop].size();j++)
			fit += popman->popula[whichSubpop][j]->fit;
		if (popman->popula[whichSubpop].empty())
			fit = Max;
		else
			fit = fit / (double)popman->popula[whichSubpop].size();
		popman->avgCostPop[whichSubpop] = fit;
	}
}
int solution::selectsubPop(int subpop1){
	int rand1,rand2;
	int target;
	std::vector<int>locConf;
	for (int i=0; i < data->numLocConfiguration + 1; i++)// including the e lite population
		if ((int)popman->popula[i].size() > 0)
			locConf.push_back(i);
	if (locConf.empty())
		return -1;
	while(1){
		rand1 = rand() % (int)locConf.size();
		rand2 = rand() % (int)locConf.size();
		if ((int)locConf.size() <= 3 )return locConf[rand1];
		while(rand1 == rand2)
			rand2=rand() % (int)locConf.size();//data->numLocConfiguration;
		if (popman->avgCostPop[locConf[rand1]] < popman->avgCostPop[locConf[rand2]])
			target = locConf[rand1];
		else
			target=locConf[rand2];
		if (target == subpop1 && (int)popman->popula[target].size() > 2)break;
		if (target != subpop1)break;
		if ((int)locConf.size() == 2){
			if (locConf[0] == subpop1)
				target = locConf[1];
			else
				target = locConf[0];
			break;
		}
	}
	return target;
}
void solution::main_loop(){
	data->iteration = 1;
	preprocessingLocationConfiguration();
	std::cout<<"---- Start the search----"<<std::endl;
	data->loopp = 0;
	data->nbIterNonImpro=1;
	int subPop;
	initialPop();
	if (global->fit >= Max - Min){
		std::cout << "No feasible solution was produced before the stopping condition." << std::endl;
		return;
	}
	computingSubpopulation(-1);
	data->iteration = 1;
	std::vector<int>depot;
	while(1){
		// phase 2: shock the solution selected from the current solution
		//select the solution
		subPop = selectsubPop(-1);
		if (subPop < 0) {
			std::cout << "No eligible subpopulation is available for selection." << std::endl;
			return;
		}
		popman->selectionParentSolution(subPop, off);
		//enter the shock procedure
		cross->shock_procedure(off);

		if (!off->isFeasible)continue;
		ls->local_search_run(off);
		subPop = popman->addIndividual(off, -1);
		if (subPop >= 0)
			computingSubpopulation(subPop);// update the average value of each subPopulation
		data->iteration++;
		if (data->iteration % 500 == 0)
			outputprocess(off);
		/*re-start procedure*/
		if (data->nbIterNonImpro >data->maxIterNonProd){
			popman->reStart();
			cross->segment = 0;
			initialPop();
			data->nbIterNonImpro = 0;
		}
		data->nbIterNonImpro++;
		if (data->stopCondition(global->fit)){
			global->outputSolution();
			global->isRight();
			global->outputBestSolution();
			std::cout<<global->fit<<std::endl; 
			std::cout<<"----The memetic algorithm is finished, time spends: "<<(double)clock()/(double)CLOCKS_PER_SEC<<std::endl;
			return;
		}
	}
}
